import loaderGif from './images/loading-load.gif';
import defaultProductImage from './images/newNavy.png';

export const icons = {
  info: '',
  defaultProduct: defaultProductImage,
  loaderGif: loaderGif,
  addNewLogo: '',
};
