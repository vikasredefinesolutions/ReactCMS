export interface _StoreReturnType {
  storeId: null | number;
  layout: null | string;
  pageType: string;
  pathName: string;
  code: string;
  isAttributeSaparateProduct: boolean;
}
