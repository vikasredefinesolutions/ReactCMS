import { headerInfo } from '../mock/header.mock';

export type _Header = typeof headerInfo;
