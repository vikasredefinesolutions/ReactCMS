import bannerMock from '../mock/banner.mock';

export type _ProductListBanner = typeof bannerMock;
