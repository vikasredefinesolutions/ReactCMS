export interface _Config {
  api: {
    URL: string;
  };
  CLIENT_ID: string;
  mediaBaseUrl: string;
  CMS: string;
}
