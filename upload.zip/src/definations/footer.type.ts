import { footer } from '../mock/footer.mock';

export type _Footer = typeof footer;
