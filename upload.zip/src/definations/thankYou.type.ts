import thankYouOrder from '../mock/thankYou.mock';

export type _ThankYouOrder = typeof thankYouOrder;
