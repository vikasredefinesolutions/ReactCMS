export const _Store = {
  type1: 'cg',
  type2: 'gamedaygear.com',
  type3: 'pk',
  type4: 'drivingi',
};

export const _StoreDomains = {
  domain1: 'corporategear',
  domain2: 'gamedaygear.com',
  domain3: 'pk',
  domain4: 'drivingi',
};

export const _SeName = {
  hundred: '"100th-anniversary-challenge-coin"',
  nike: 'Nike-Men-s-Club-Fleece-Sleeve-Swoosh-Pullover-Hoodie',
};
