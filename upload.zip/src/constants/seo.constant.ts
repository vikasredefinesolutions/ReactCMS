export const BrandList = {
  title: 'Personalized Brands Apperal',
  description: 'Personalized Brands Apperal',
  keywords: 'Gear',
}

export const CartPage = {
  title: 'Cart',
  description: 'Cart Page',
  keywords: 'Cart',
}

export const CheckoutPage = {
  title: 'Checkout',
  description: 'Checkout Page',
  keywords: 'Checkout',
}