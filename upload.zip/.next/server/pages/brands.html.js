"use strict";
(() => {
var exports = {};
exports.id = 8855;
exports.ids = [8855,6089,4623,7142,1733,6868,892,3011,529,1097,8018];
exports.modules = {

/***/ 7027:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);


const SeoHead = (props)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                children: props.title
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "description",
                content: props.description
            }, "desc"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "keywords",
                content: props.keywords
            })
        ]
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SeoHead);


/***/ }),

/***/ 7031:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "V": () => (/* binding */ CartPage),
/* harmony export */   "dn": () => (/* binding */ BrandList),
/* harmony export */   "uU": () => (/* binding */ CheckoutPage)
/* harmony export */ });
const BrandList = {
    title: "Personalized Brands Apperal",
    description: "Personalized Brands Apperal",
    keywords: "Gear"
};
const CartPage = {
    title: "Cart",
    description: "Cart Page",
    keywords: "Cart"
};
const CheckoutPage = {
    title: "Checkout",
    description: "Checkout Page",
    keywords: "Checkout"
};


/***/ }),

/***/ 8221:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _services_brand_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2449);
/* harmony import */ var helpers_common_helper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4822);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_brand_service__WEBPACK_IMPORTED_MODULE_0__, helpers_common_helper__WEBPACK_IMPORTED_MODULE_1__]);
([_services_brand_service__WEBPACK_IMPORTED_MODULE_0__, helpers_common_helper__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (async ()=>{
    const brands = await (0,_services_brand_service__WEBPACK_IMPORTED_MODULE_0__/* .FetchBrands */ .O)("4");
    const alphabets = [];
    const sorted = brands.data.sort(function(a, b) {
        alphabets.push(a.brandName[0].toLowerCase());
        if (a.brandName > b.brandName) {
            return 1;
        } else if (a.brandName < b.brandName) {
            return -1;
        }
        return 0;
    });
    const nonDuplicates = (0,helpers_common_helper__WEBPACK_IMPORTED_MODULE_1__/* .removeDuplicates */ .R1)(sorted);
    const filtered_alphabets = alphabets.filter((item, index)=>alphabets.indexOf(item) === index);
    return {
        props: {
            brands: nonDuplicates,
            alphabets: filtered_alphabets
        }
    };
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2198:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* reexport safe */ _getServerSideProps__WEBPACK_IMPORTED_MODULE_8__["default"])
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var appComponents_Screen_Layout_Head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7027);
/* harmony import */ var constants_seo_constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7031);
/* harmony import */ var constants_store_constant__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _BrandController__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6502);
/* harmony import */ var _Components_Store1Layout__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7466);
/* harmony import */ var _Components_Store2Layout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2185);
/* harmony import */ var _getServerSideProps__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8221);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_BrandController__WEBPACK_IMPORTED_MODULE_5__, _Components_Store1Layout__WEBPACK_IMPORTED_MODULE_6__, _getServerSideProps__WEBPACK_IMPORTED_MODULE_8__]);
([_BrandController__WEBPACK_IMPORTED_MODULE_5__, _Components_Store1Layout__WEBPACK_IMPORTED_MODULE_6__, _getServerSideProps__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const Brands = (props)=>{
    let layout = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
    const { storeLayout  } = (0,_BrandController__WEBPACK_IMPORTED_MODULE_5__["default"])();
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_3__/* ._Store.type1 */ .up.type1) {
        layout = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Components_Store1Layout__WEBPACK_IMPORTED_MODULE_6__["default"], {
            ...props
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_3__/* ._Store.type2 */ .up.type2) {
        layout = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Components_Store2Layout__WEBPACK_IMPORTED_MODULE_7__["default"], {});
    }
    // if (storeLayout === _Store.type3) {
    //   return (
    //
    //   );
    // }
    // if (storeLayout === _Store.type4) {
    //   return (
    //
    //   );
    // }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_Screen_Layout_Head__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                ...constants_seo_constant__WEBPACK_IMPORTED_MODULE_2__/* .BrandList */ .dn
            }),
            layout
        ]
    });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Brands);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 7564:
/***/ ((module) => {

module.exports = import("chalk");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3598,1313,1664,9483,6183,6502,2185,7466], () => (__webpack_exec__(2198)));
module.exports = __webpack_exports__;

})();