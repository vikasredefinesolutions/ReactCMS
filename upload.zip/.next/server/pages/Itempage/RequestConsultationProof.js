"use strict";
(() => {
var exports = {};
exports.id = 3482;
exports.ids = [3482,6089,6509,4623,7142,1733,6868,892,3011,8018];
exports.modules = {

/***/ 8879:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ RequestConsultation_RequestConsultationForm)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "formik"
var external_formik_ = __webpack_require__(2296);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "yup"
var external_yup_ = __webpack_require__(5609);
// EXTERNAL MODULE: ./src/constants/paths.constant.ts
var paths_constant = __webpack_require__(3125);
;// CONCATENATED MODULE: ./src/Components/RequestConsultation/RequestInput.tsx



const RequestInput = ({ name , placeHolder , value , onChange , type , required , className ,  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                    type: type,
                    id: name,
                    name: name,
                    placeholder: `${placeHolder} ${required ? "*" : ""}`,
                    value: value,
                    onChange: onChange,
                    className: className
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(external_formik_.ErrorMessage, {
                    name: name
                })
            ]
        })
    });
};
/* harmony default export */ const RequestConsultation_RequestInput = (RequestInput);

;// CONCATENATED MODULE: ./src/Components/RequestConsultation/RequestSelect.tsx



const RequestSelect = ({ name , options , onChange , required , placeHolder , value ,  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("select", {
                className: "form-input",
                id: name,
                onChange: onChange,
                value: value,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("option", {
                        value: "",
                        children: `${placeHolder} ${required ? "*" : ""}`
                    }),
                    options.map((option)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                            value: option.id,
                            children: option.name
                        }, option.id))
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_formik_.ErrorMessage, {
                name: name
            })
        ]
    });
};
/* harmony default export */ const RequestConsultation_RequestSelect = (RequestSelect);

;// CONCATENATED MODULE: ./src/Components/RequestConsultation/RequestConsultationForm.tsx








const _RequestConsulationSchema = external_yup_.object().shape({
    firstName: external_yup_.string().required("Enter your first name."),
    lastName: external_yup_.string().required("Enter your Last name."),
    companyName: external_yup_.string().required("Enter your Last name."),
    email: external_yup_.string().required("Enter your email."),
    phone: external_yup_.string().required("Enter your Phone."),
    preferedContactMethod: external_yup_.string().required("Please Select Contact Method."),
    desiredQty: external_yup_.string().required("Enter desired quantity."),
    inHandDate: external_yup_.string(),
    message: external_yup_.string()
});
const _RequestConsultationInitials = {
    firstName: "",
    lastName: "",
    companyName: "",
    email: "",
    phone: "",
    preferedContactMethod: "",
    desiredQty: "",
    inHandDate: "",
    message: ""
};
const RequestConsultationForm = ()=>{
    const router = (0,router_.useRouter)();
    const { 0: showLogo , 1: setShowLogo  } = (0,external_react_.useState)(false);
    const { 1: setFileToUpload  } = (0,external_react_.useState)(null);
    const submitHandler = ()=>{};
    const fileReader = (event)=>{
        var ref;
        if (((ref = event.currentTarget) === null || ref === void 0 ? void 0 : ref.files) === null) return;
        const file = {
            name: event.currentTarget.files[0].name,
            type: event.currentTarget.files[0].type,
            previewURL: URL.createObjectURL(event.currentTarget.files[0])
        };
        setFileToUpload(file);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-full lg:w-4/12 px-3",
        children: /*#__PURE__*/ jsx_runtime_.jsx(external_formik_.Formik, {
            initialValues: _RequestConsultationInitials,
            onSubmit: submitHandler,
            validationSchema: _RequestConsulationSchema,
            children: ({ values , handleChange , setFieldValue  })=>{
                return /*#__PURE__*/ jsx_runtime_.jsx(external_formik_.Form, {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-wrap -mx-3 gap-y-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full px-3",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "bg-gray-100 flex flex-wrap items-center justify-between p-2",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "",
                                            children: "Contact Information"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-red-500 text-xs",
                                            children: "All fields marked * are required."
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full px-3",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(RequestConsultation_RequestInput, {
                                    placeHolder: "First Name",
                                    name: "firstName",
                                    value: values.firstName,
                                    onChange: handleChange,
                                    type: "text",
                                    required: true,
                                    className: "form-input"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full px-3",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(RequestConsultation_RequestInput, {
                                    placeHolder: "Last Name",
                                    name: "lastName",
                                    value: values.lastName,
                                    onChange: handleChange,
                                    type: "text",
                                    required: true,
                                    className: "form-input"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full px-3",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(RequestConsultation_RequestInput, {
                                    placeHolder: "Company",
                                    name: "companyName",
                                    value: values.companyName,
                                    onChange: handleChange,
                                    type: "text",
                                    required: true,
                                    className: "form-input"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full px-3",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(RequestConsultation_RequestInput, {
                                    placeHolder: "Email",
                                    name: "email",
                                    value: values.email,
                                    onChange: handleChange,
                                    type: "text",
                                    required: true,
                                    className: "form-input"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full px-3",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(RequestConsultation_RequestInput, {
                                    placeHolder: "Phone",
                                    name: "phone",
                                    value: values.phone,
                                    onChange: handleChange,
                                    type: "text",
                                    required: true,
                                    className: "form-input"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full px-3",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(RequestConsultation_RequestSelect, {
                                    placeHolder: "Select Prefered Contact Method",
                                    name: "preferedContactMethod",
                                    value: values.preferedContactMethod,
                                    options: [
                                        {
                                            id: "phone",
                                            name: "Phone"
                                        },
                                        {
                                            id: "email",
                                            name: "Email"
                                        }, 
                                    ],
                                    onChange: (event)=>setFieldValue("preferedContactMethod", event.target.value),
                                    required: true
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full px-3",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(RequestConsultation_RequestInput, {
                                    placeHolder: "Desired Quantity",
                                    name: "desiredQty",
                                    value: values.desiredQty,
                                    onChange: handleChange,
                                    type: "text",
                                    required: true,
                                    className: "form-input"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full px-3",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "bg-gray-100 flex flex-wrap items-center justify-between p-2",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "",
                                        children: "Optional Information"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full px-3",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-wrap items-center justify-between",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "",
                                            children: "In Hand Date"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(RequestConsultation_RequestInput, {
                                                placeHolder: "MM/DD/YYYY",
                                                name: "inHandDate",
                                                value: values.inHandDate,
                                                onChange: handleChange,
                                                type: "text",
                                                required: false,
                                                className: "form-input"
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "w-full px-3",
                                "x-data": "{ open:false}",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex flex-wrap items-center justify-between",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "",
                                                children: "Provide Logo (Optional)"
                                            }),
                                            !showLogo && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: "text-anchor",
                                                    type: "button",
                                                    onClick: ()=>setShowLogo(true),
                                                    children: "+ Add Logo"
                                                })
                                            })
                                        ]
                                    }),
                                    showLogo && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "bg-gray-100 p-2 mt-2 border border-gray-300",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex flex-wrap items-center justify-between",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "",
                                                        children: "First Logo"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            className: "text-anchor",
                                                            type: "button",
                                                            onClick: ()=>setShowLogo(false),
                                                            children: "X Remove"
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "mt-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                        htmlFor: "logo",
                                                        children: "Select your logo"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            type: "file",
                                                            name: "logo",
                                                            id: "logo",
                                                            // value={undefined}
                                                            className: "form-input",
                                                            onChange: fileReader,
                                                            accept: "image/*"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full px-3",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                                        placeholder: "Message here",
                                        className: "form-input",
                                        name: "message",
                                        value: values.message,
                                        onChange: handleChange
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "w-full px-3 text-center",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        type: "submit",
                                        className: "btn btn-xl btn-secondary !block text-center mb-4",
                                        children: "SUBMIT"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        type: "button",
                                        className: "text-center text-anchorr",
                                        onClick: ()=>router.push(paths_constant/* paths.PRODUCT */.H.PRODUCT),
                                        children: "Cancel"
                                    })
                                ]
                            })
                        ]
                    })
                });
            }
        })
    });
};
/* harmony default export */ const RequestConsultation_RequestConsultationForm = (RequestConsultationForm);


/***/ }),

/***/ 4393:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const RequestFeatures = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full lg:w-4/12 px-3",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "bg-gray-100 p-5 max-w-sm ml-auto h-2/3 max-h-96 flex flex-col items-center justify-center",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "border-b last:border-b-0 border-gray-300 w-full text-center p-3",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "material-icons text-3xl",
                            children: "local_shipping"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mt-1",
                            children: "FREE SHIPPING ORDERS OVER $4K"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "border-b last:border-b-0 border-gray-300 w-full text-center p-3",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "material-icons text-3xl",
                            children: "style"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mt-1",
                            children: "1ST LOGO FREE UP TO 10,000 STITCHES"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "border-b last:border-b-0 border-gray-300 w-full text-center p-3",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "material-icons text-3xl",
                            children: "verified"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mt-1",
                            children: "FREE PROOF ON ALL ORDERS"
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RequestFeatures);


/***/ }),

/***/ 723:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$": () => (/* binding */ FetchProductDetails)
/* harmony export */ });
/* harmony import */ var helpers_global_console__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3650);
/* harmony import */ var services_product_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2433);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([helpers_global_console__WEBPACK_IMPORTED_MODULE_0__, services_product_service__WEBPACK_IMPORTED_MODULE_1__]);
([helpers_global_console__WEBPACK_IMPORTED_MODULE_0__, services_product_service__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////// SERVER SIDE FUNCTIONS ---------------------------------------
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
const FetchProductDetails = async (payload)=>{
    const expectedProps = {
        productColors: null,
        productDetails: null,
        doNotExist: null
    };
    try {
        var ref, ref1;
        expectedProps.productDetails = await (0,services_product_service__WEBPACK_IMPORTED_MODULE_1__/* .FetchProductById */ .f)({
            // Request - 1
            seName: `""`,
            storeId: payload.storeId,
            productId: payload.productId
        });
        if (((ref = expectedProps.productDetails) === null || ref === void 0 ? void 0 : ref.id) === null) {
            expectedProps.doNotExist = expectedProps.productDetails.productDoNotExist;
            expectedProps.productDetails = null;
        }
        if ((ref1 = expectedProps.productDetails) === null || ref1 === void 0 ? void 0 : ref1.id) {
            expectedProps.productColors = await (0,services_product_service__WEBPACK_IMPORTED_MODULE_1__/* .FetchColors */ .jW)({
                // Request - 2 based on 1
                storeId: payload.storeId,
                isAttributeSaparateProduct: payload.isAttributeSaparateProduct,
                productId: expectedProps.productDetails.id
            });
        }
    } catch (error) {
        (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_0__/* .highLightError */ .Eg)({
            error,
            component: `Request Consultation Controller`
        });
    }
    return {
        details: expectedProps.productDetails,
        colors: expectedProps.productColors,
        doNotExist: expectedProps.doNotExist
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3125:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "E": () => (/* binding */ queryParam),
/* harmony export */   "H": () => (/* binding */ paths)
/* harmony export */ });
const queryParam = {
    TEAM: "team",
    INDIVIDUAL: "individual"
};
const paths = {
    HOME: "/home",
    PRODUCT: "/product",
    SPECIAL_REQUEST: "/special_request",
    PRODUCT_LISTING: "/product-list",
    NOT_FOUND: "/not-found",
    CHECKOUT: "/checkout",
    MY_ACCOUNT: "/my-account",
    SIGN_UP: "/CreateAccount/SignUp",
    THANK_YOU: "/thank-you",
    CART: "/cart.html",
    BRAND: "/brands.html",
    WISHLIST: "/wishlist",
    WRITE_A_REVIEW: "/writereview/writereview",
    REQUEST_CONSULTATION: "/itempage/RequestConsultationProof",
    CUSTOMIZE_LOGO: "/customize",
    PRODUCT_COMPARE: "/compare"
};


/***/ }),

/***/ 9485:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2337);
/* harmony import */ var Components_RequestConsultation_RequestConsultationForm__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8879);
/* harmony import */ var Components_RequestConsultation_RequestFeatures__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4393);
/* harmony import */ var constants_paths_constant__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3125);
/* harmony import */ var Controllers_RequestConsultationController__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(723);
/* harmony import */ var Controllers_AppController__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(405);
/* harmony import */ var helpers_common_helper__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4822);
/* harmony import */ var helpers_global_console__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3650);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var page_config__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3521);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var show_config__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2118);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([Controllers_RequestConsultationController__WEBPACK_IMPORTED_MODULE_5__, Controllers_AppController__WEBPACK_IMPORTED_MODULE_6__, helpers_common_helper__WEBPACK_IMPORTED_MODULE_7__, helpers_global_console__WEBPACK_IMPORTED_MODULE_8__]);
([Controllers_RequestConsultationController__WEBPACK_IMPORTED_MODULE_5__, Controllers_AppController__WEBPACK_IMPORTED_MODULE_6__, helpers_common_helper__WEBPACK_IMPORTED_MODULE_7__, helpers_global_console__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














const RequestConsultation = ({ product , color  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_10__.useRouter)();
    (0,react__WEBPACK_IMPORTED_MODULE_12__.useEffect)(()=>{
        if (product !== null && product.doNotExist) {
            router.push(product.doNotExist.retrunUrlOrCategorySename || "/");
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    if (product === null) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: "Product Page Loading... "
    });
    if (product === null || product.details === null || color === null) {
        router.push("/");
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: "container mx-auto border border-gray-300 p-3",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex flex-wrap items-center -mx-3",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "w-full lg:w-4/12 px-3 text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                src: (color === null || color === void 0 ? void 0 : color.imageUrl) || null,
                                alt: product.details.name,
                                className: ""
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "text-lg md:text-xl lg:text-small-title font-small-title",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_9___default()), {
                                href: constants_paths_constant__WEBPACK_IMPORTED_MODULE_4__/* .paths.PRODUCT */ .H.PRODUCT,
                                children: product.details.name
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_RequestConsultation_RequestConsultationForm__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_RequestConsultation_RequestFeatures__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RequestConsultation);
const getServerSideProps = async (context)=>{
    let expectedProps = {
        store: null,
        product: null,
        color: null
    };
    try {
        var ref, ref1, ref2;
        const domain = (0,helpers_common_helper__WEBPACK_IMPORTED_MODULE_7__/* .domainToShow */ .M_)({
            domain: (ref = context.req) === null || ref === void 0 ? void 0 : ref.rawHeaders[1],
            showProd: page_config__WEBPACK_IMPORTED_MODULE_11__/* .__domain.isSiteLive */ .Pq.isSiteLive
        });
        const query = {
            productId: (ref1 = context.query) === null || ref1 === void 0 ? void 0 : ref1.productid,
            colorName: (ref2 = context.query) === null || ref2 === void 0 ? void 0 : ref2.Color
        };
        if (typeof query.productId === "string") {
            query.productId = +query.productId; // to number;
            expectedProps.store = await Controllers_AppController__WEBPACK_IMPORTED_MODULE_6__/* .FetchStoreDetails */ .ii(domain, "");
            if (expectedProps.store) {
                var ref3, ref4;
                expectedProps.product = await Controllers_RequestConsultationController__WEBPACK_IMPORTED_MODULE_5__/* .FetchProductDetails */ .$({
                    storeId: expectedProps.store.storeId,
                    productId: query.productId,
                    isAttributeSaparateProduct: expectedProps.store.isAttributeSaparateProduct
                });
                expectedProps.color = ((ref3 = expectedProps.product) === null || ref3 === void 0 ? void 0 : (ref4 = ref3.colors) === null || ref4 === void 0 ? void 0 : ref4.find((color)=>{
                    return color.name === query.colorName;
                })) || null;
            }
        }
    // const pathNames = context.req.url?.split('/')!;
    // const seName =  pathNames ? pathNames[pathNames?.length - 1] : null;
    } catch (error) {
        (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_8__/* .highLightError */ .Eg)({
            error,
            component: `Request Consultation page`
        });
    }
    (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_8__/* .conditionalLog */ .wH)({
        show: show_config__WEBPACK_IMPORTED_MODULE_13__/* ._showConsoles.requestConsultation */ .YH.requestConsultation,
        data: expectedProps,
        type: "NEXTJS PROPS",
        name: show_config__WEBPACK_IMPORTED_MODULE_13__/* .__fileNames.requestConsultation */ .eg.requestConsultation
    });
    return {
        props: {
            product: expectedProps.product,
            color: expectedProps.color
        }
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2296:
/***/ ((module) => {

module.exports = require("formik");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 7564:
/***/ ((module) => {

module.exports = import("chalk");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3598,1313,1664,5675,9483,2337,405,2433], () => (__webpack_exec__(9485)));
module.exports = __webpack_exports__;

})();