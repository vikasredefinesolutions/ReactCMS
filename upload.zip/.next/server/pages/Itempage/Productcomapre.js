"use strict";
(() => {
var exports = {};
exports.id = 8635;
exports.ids = [8635,6089,4623,7142,1733,6868,892,3011,2164,529,1097,8018];
exports.modules = {

/***/ 5994:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2337);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6183);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_2__]);
hooks__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const AllColors = ({ color , index , seName  })=>{
    const { showCompareImage  } = (0,hooks__WEBPACK_IMPORTED_MODULE_2__/* .useActions */ .ol)();
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        if (color !== null) {
            if (typeof color === "string") {
                showCompareImage({
                    index,
                    label: "",
                    url: "-",
                    attibuteOptionId: 0,
                    seName: "/"
                });
                return;
            }
            showCompareImage({
                index: index,
                label: color[0].name,
                url: color[0].imageUrl,
                seName: seName,
                attibuteOptionId: color[0].attributeOptionId
            });
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    if (color === null) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
            className: "",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "p-2",
                children: "-"
            })
        }, index);
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
        className: "",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "p-2",
            children: color.map((color)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    onClick: ()=>showCompareImage({
                            index,
                            label: color.name,
                            url: color.imageUrl,
                            attibuteOptionId: color.attributeOptionId,
                            seName: seName
                        }),
                    className: "w-10 h-10 border border-gray-300 bg-gray-100 flex justify-center items-center",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        src: color.imageUrl,
                        alt: color.name,
                        className: ""
                    })
                }, index))
        })
    }, index);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AllColors);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3256:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6183);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_1__]);
hooks__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const AllSizes = ({ sizes , index  })=>{
    const selectedImages = (0,hooks__WEBPACK_IMPORTED_MODULE_1__/* .useTypedSelector */ .ix)((state)=>state.compare.selectedImages);
    if (selectedImages) {
        if (sizes.colorAttributeOptionId === selectedImages[index].attibuteOptionId) {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                className: "",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "p-2 flex flex-wrap gap-2",
                    children: sizes.sizeArr.map((size, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-10 h-10 border border-gray-300 bg-gray-100 flex justify-center items-center",
                            children: size
                        }, index))
                })
            });
        }
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AllSizes);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2502:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2337);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6183);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_2__]);
hooks__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const DisplayCompareImage = ()=>{
    const images = (0,hooks__WEBPACK_IMPORTED_MODULE_2__/* .useTypedSelector */ .ix)((state)=>state.compare.selectedImages);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
        className: "divide-x divide-x-gray-300",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                className: "",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-96 p-2 relative"
                })
            }),
            images === null || images === void 0 ? void 0 : images.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                    href: item.seName || "/",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                            src: item.url,
                            alt: item.label,
                            className: ""
                        }, item.index)
                    })
                }, index))
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DisplayCompareImage);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7309:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "o": () => (/* binding */ FetchProductsDetail)
/* harmony export */ });
/* harmony import */ var _services_product_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2433);
/* harmony import */ var helpers_global_console__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3650);
/* harmony import */ var show_config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2118);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_product_service__WEBPACK_IMPORTED_MODULE_0__, helpers_global_console__WEBPACK_IMPORTED_MODULE_1__]);
([_services_product_service__WEBPACK_IMPORTED_MODULE_0__, helpers_global_console__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



const FetchProductsDetail = async (params)=>{
    const expectedProps = {
        productsDetail: null,
        productsColor: null,
        productInventory: null
    };
    try {
        expectedProps.productsDetail = await (0,_services_product_service__WEBPACK_IMPORTED_MODULE_0__/* .FetchProductsBySKUs */ .rX)({
            storeId: params.storeId,
            SKUs: params.skus
        });
        if (expectedProps.productsDetail && expectedProps.productsDetail.length > 0) {
            const colorsToFetch = await expectedProps.productsDetail.map((product)=>{
                return (0,_services_product_service__WEBPACK_IMPORTED_MODULE_0__/* .FetchColors */ .jW)({
                    productId: product.productId,
                    storeId: params.storeId,
                    isAttributeSaparateProduct: params.isAttributeSaparateProduct
                });
            });
            await Promise.allSettled(colorsToFetch).then((values)=>values.forEach((value, index)=>{
                    const colors = value.status === "fulfilled" ? value.value : null;
                    if (expectedProps.productsColor === null) {
                        expectedProps.productsColor = [
                            colors
                        ];
                    }
                    expectedProps.productsColor[index] = colors;
                }));
            const sizesToFetch = await expectedProps.productsColor.map((color, index)=>{
                const attributeOptionIds = color && color.map((clr)=>clr.attributeOptionId) || [
                    0
                ];
                return (0,_services_product_service__WEBPACK_IMPORTED_MODULE_0__/* .FetchInventoryById */ .oe)({
                    productId: expectedProps.productsDetail && expectedProps.productsDetail[index].productId || 0,
                    attributeOptionId: [
                        ...attributeOptionIds
                    ]
                });
            });
            await Promise.allSettled(sizesToFetch).then((values)=>values.forEach((value, index)=>{
                    const inventory = value.status === "fulfilled" ? value.value : null;
                    if (expectedProps.productInventory === null) {
                        expectedProps.productInventory = [
                            inventory
                        ];
                    }
                    expectedProps.productInventory[index] = inventory;
                }));
        }
    } catch (error) {
        (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_1__/* .highLightError */ .Eg)({
            error,
            component: `Compare Products Controller`
        });
    }
    (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_1__/* .conditionalLog */ .wH)({
        show: show_config__WEBPACK_IMPORTED_MODULE_2__/* ._showConsoles.compareProducts */ .YH.compareProducts,
        data: expectedProps,
        type: "CONTROLLER",
        name: show_config__WEBPACK_IMPORTED_MODULE_2__/* .__fileNames.compareProducts */ .eg.compareProducts
    });
    return {
        details: expectedProps.productsDetail,
        colors: expectedProps.productsColor,
        inventory: expectedProps.productInventory
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3632:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6183);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_2__]);
hooks__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const Price = ({ value , prices  })=>{
    let price = 0;
    const currency = (0,hooks__WEBPACK_IMPORTED_MODULE_2__/* .useTypedSelector */ .ix)((state)=>state.store.currency);
    if (value) prices === null ? price = 0 : price = +value;
    if (prices) {
        prices === null ? price = 0 : prices.msrp;
    }
    const toShow = price.toFixed(2);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            currency,
            toShow
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Price);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7200:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3632);
/* harmony import */ var Components_Compare_AllColors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5994);
/* harmony import */ var Components_Compare_AllSizes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3256);
/* harmony import */ var Components_Compare_DisplayCompareImage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2502);
/* harmony import */ var Controllers_CompareProductsController__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7309);
/* harmony import */ var Controllers_AppController__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(405);
/* harmony import */ var helpers_common_helper__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4822);
/* harmony import */ var helpers_global_console__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3650);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var page_config__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3521);
/* harmony import */ var show_config__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2118);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_1__, Components_Compare_AllColors__WEBPACK_IMPORTED_MODULE_2__, Components_Compare_AllSizes__WEBPACK_IMPORTED_MODULE_3__, Components_Compare_DisplayCompareImage__WEBPACK_IMPORTED_MODULE_4__, Controllers_CompareProductsController__WEBPACK_IMPORTED_MODULE_5__, Controllers_AppController__WEBPACK_IMPORTED_MODULE_6__, helpers_common_helper__WEBPACK_IMPORTED_MODULE_7__, helpers_global_console__WEBPACK_IMPORTED_MODULE_8__]);
([appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_1__, Components_Compare_AllColors__WEBPACK_IMPORTED_MODULE_2__, Components_Compare_AllSizes__WEBPACK_IMPORTED_MODULE_3__, Components_Compare_DisplayCompareImage__WEBPACK_IMPORTED_MODULE_4__, Controllers_CompareProductsController__WEBPACK_IMPORTED_MODULE_5__, Controllers_AppController__WEBPACK_IMPORTED_MODULE_6__, helpers_common_helper__WEBPACK_IMPORTED_MODULE_7__, helpers_global_console__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const ProductCompare = ({ products  })=>{
    var ref, ref1, ref2, ref3, ref4, ref5;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: "pt-10 pb-10",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "container mx-auto",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "text-2xl md:text-3xl lg:text-title font-title text-color-title text-center mb-4",
                        children: "Compare"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "relative overflow-auto border border-gray-300",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("table", {
                        className: "w-full",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tbody", {
                            className: "divide-y divide-y-gray-300",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_Compare_DisplayCompareImage__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                    className: "divide-x divide-x-gray-300",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                            className: "",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "p-2",
                                                children: "Title"
                                            })
                                        }),
                                        products === null || products === void 0 ? void 0 : (ref = products.details) === null || ref === void 0 ? void 0 : ref.map((product, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                className: "",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_9___default()), {
                                                    href: product.seName,
                                                    className: "p-2",
                                                    children: product.name
                                                })
                                            }, index))
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                    className: "divide-x divide-x-gray-300",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                            className: "",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "p-2",
                                                children: "SKU"
                                            })
                                        }),
                                        products === null || products === void 0 ? void 0 : (ref1 = products.details) === null || ref1 === void 0 ? void 0 : ref1.map((product, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                className: "",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "p-2",
                                                    children: product.sku
                                                })
                                            }, index))
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                    className: "divide-x divide-x-gray-300",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                            className: "",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "p-2",
                                                children: "Price"
                                            })
                                        }),
                                        products === null || products === void 0 ? void 0 : (ref2 = products.details) === null || ref2 === void 0 ? void 0 : ref2.map((product, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                className: "",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "p-2",
                                                    children: [
                                                        "MSRP ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                            value: product.msrp
                                                        })
                                                    ]
                                                })
                                            }, index))
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                    className: "divide-x divide-x-gray-300",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                            className: "",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "p-2",
                                                children: "Color"
                                            })
                                        }),
                                        products === null || products === void 0 ? void 0 : (ref3 = products.colors) === null || ref3 === void 0 ? void 0 : ref3.map((colors, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_Compare_AllColors__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                color: colors,
                                                index: index,
                                                seName: products.details && products.details[index].seName || "/"
                                            }, index))
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                    className: "divide-x divide-x-gray-300",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                            className: "",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "p-2",
                                                children: "Size"
                                            })
                                        }),
                                        products === null || products === void 0 ? void 0 : (ref4 = products.inventory) === null || ref4 === void 0 ? void 0 : ref4.map((inventory, index)=>{
                                            if (inventory === null) {
                                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                    className: "",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "p-2 flex flex-wrap gap-2",
                                                        children: '"-"'
                                                    })
                                                }, index);
                                            }
                                            return inventory.sizes.map((sizes)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_Compare_AllSizes__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                    index: index,
                                                    sizes: sizes
                                                }, index));
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                    className: "divide-x divide-x-gray-300",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                            className: "",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "p-2",
                                                children: "Description"
                                            })
                                        }),
                                        products === null || products === void 0 ? void 0 : (ref5 = products.details) === null || ref5 === void 0 ? void 0 : ref5.map((product, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                className: "",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "p-2",
                                                    dangerouslySetInnerHTML: {
                                                        __html: product.description
                                                    }
                                                })
                                            }, index))
                                    ]
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "text-center mt-4",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_9___default()), {
                        href: "/product-listing",
                        className: "btn btn-primary",
                        children: "SEND LINK"
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductCompare);
const getServerSideProps = async (context)=>{
    var ref, ref1;
    let expectedProps = {
        products: null,
        store: null
    };
    const domain = (0,helpers_common_helper__WEBPACK_IMPORTED_MODULE_7__/* .domainToShow */ .M_)({
        domain: (ref = context.req) === null || ref === void 0 ? void 0 : ref.rawHeaders[1],
        showProd: page_config__WEBPACK_IMPORTED_MODULE_10__/* .__domain.isSiteLive */ .Pq.isSiteLive
    });
    const query = {
        SKUs: (ref1 = context.query) === null || ref1 === void 0 ? void 0 : ref1.SKU
    };
    if (typeof query.SKUs === "string") {
        query.SKUs = query.SKUs;
    } else {
        query.SKUs = undefined;
    }
    try {
        expectedProps.store = await Controllers_AppController__WEBPACK_IMPORTED_MODULE_6__/* .FetchStoreDetails */ .ii(domain, "");
        if (expectedProps.store && query.SKUs) {
            expectedProps.products = await Controllers_CompareProductsController__WEBPACK_IMPORTED_MODULE_5__/* .FetchProductsDetail */ .o({
                skus: query.SKUs,
                storeId: expectedProps.store.storeId,
                isAttributeSaparateProduct: expectedProps.store.isAttributeSaparateProduct
            });
        }
    } catch (error) {
        (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_8__/* .highLightError */ .Eg)({
            error,
            component: `Compare Products page`
        });
    }
    (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_8__/* .conditionalLog */ .wH)({
        show: show_config__WEBPACK_IMPORTED_MODULE_11__/* ._showConsoles.compareProducts */ .YH.compareProducts,
        data: expectedProps.products,
        type: "NEXTJS PROPS",
        name: show_config__WEBPACK_IMPORTED_MODULE_11__/* .__fileNames.compareProducts */ .eg.compareProducts
    });
    return {
        props: {
            products: expectedProps.products
        }
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 7564:
/***/ ((module) => {

module.exports = import("chalk");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3598,1313,1664,5675,9483,6183,2337,405,2433], () => (__webpack_exec__(7200)));
module.exports = __webpack_exports__;

})();