"use strict";
(() => {
var exports = {};
exports.id = 5835;
exports.ids = [5835];
exports.modules = {

/***/ 8221:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _services_brand_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2449);
/* harmony import */ var helpers_common_helper__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4822);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_brand_service__WEBPACK_IMPORTED_MODULE_0__, helpers_common_helper__WEBPACK_IMPORTED_MODULE_1__]);
([_services_brand_service__WEBPACK_IMPORTED_MODULE_0__, helpers_common_helper__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (async ()=>{
    const brands = await (0,_services_brand_service__WEBPACK_IMPORTED_MODULE_0__/* .FetchBrands */ .O)("4");
    const alphabets = [];
    const sorted = brands.data.sort(function(a, b) {
        alphabets.push(a.brandName[0].toLowerCase());
        if (a.brandName > b.brandName) {
            return 1;
        } else if (a.brandName < b.brandName) {
            return -1;
        }
        return 0;
    });
    const nonDuplicates = (0,helpers_common_helper__WEBPACK_IMPORTED_MODULE_1__/* .removeDuplicates */ .R1)(sorted);
    const filtered_alphabets = alphabets.filter((item, index)=>alphabets.indexOf(item) === index);
    return {
        props: {
            brands: nonDuplicates,
            alphabets: filtered_alphabets
        }
    };
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2449:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "O": () => (/* binding */ FetchBrands)
/* harmony export */ });
/* harmony import */ var _utils_axios_util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(795);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__]);
_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const FetchBrands = async (storeId)=>{
    const url = `/Brand/getbrandbystoreid/${storeId}.json`;
    const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__/* .SendAsyncV2 */ .y)({
        url: url,
        method: "GET"
    });
    return res;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 7564:
/***/ ((module) => {

module.exports = import("chalk");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9483], () => (__webpack_exec__(8221)));
module.exports = __webpack_exports__;

})();