"use strict";
(() => {
var exports = {};
exports.id = 687;
exports.ids = [687,4096,6089,6509,4623,7142,1733,6868,892,3011,529];
exports.modules = {

/***/ 3893:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
/* harmony import */ var constants_validationMessages__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4108);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6183);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_uuid__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1295);
/* harmony import */ var react_uuid__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_uuid__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var services_file_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3201);
/* harmony import */ var services_review_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2200);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__, hooks__WEBPACK_IMPORTED_MODULE_4__, services_file_service__WEBPACK_IMPORTED_MODULE_8__, services_review_service__WEBPACK_IMPORTED_MODULE_9__]);
([axios__WEBPACK_IMPORTED_MODULE_1__, hooks__WEBPACK_IMPORTED_MODULE_4__, services_file_service__WEBPACK_IMPORTED_MODULE_8__, services_review_service__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const ProductReview = ()=>{
    const storeId = (0,hooks__WEBPACK_IMPORTED_MODULE_4__/* .useTypedSelector */ .ix)((state)=>state.store.id);
    const customerId = (0,hooks__WEBPACK_IMPORTED_MODULE_4__/* .useTypedSelector */ .ix)((state)=>state.user.id);
    const { 0: files , 1: setFilesFn  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)([]);
    const { 0: star , 1: setStar  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(5);
    // const [searchParam] = useSearchParams();
    const { query  } = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
    // const productId = searchParam.get('ProductId');
    const productId = query.ProductId;
    const validationSchema = yup__WEBPACK_IMPORTED_MODULE_10__.object().shape({
        comment: yup__WEBPACK_IMPORTED_MODULE_10__.string().min(3, constants_validationMessages__WEBPACK_IMPORTED_MODULE_2__/* .addReviewMessages.comment.min */ .fv.comment.min).max(200, constants_validationMessages__WEBPACK_IMPORTED_MODULE_2__/* .addReviewMessages.comment.max */ .fv.comment.max).required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_2__/* .addReviewMessages.comment.required */ .fv.comment.required),
        commentHeading: yup__WEBPACK_IMPORTED_MODULE_10__.string().min(3, constants_validationMessages__WEBPACK_IMPORTED_MODULE_2__/* .addReviewMessages.commentHeading.min */ .fv.commentHeading.min).max(60, constants_validationMessages__WEBPACK_IMPORTED_MODULE_2__/* .addReviewMessages.commentHeading.max */ .fv.commentHeading.max).required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_2__/* .addReviewMessages.commentHeading.required */ .fv.commentHeading.required)
    });
    const fileChangeHandler = async (event)=>{
        const inputFiles = event.target.files;
        const files = [];
        if (inputFiles) {
            for(let i = 0; i < inputFiles.length; i++){
                const file = inputFiles[i];
                const src = URL.createObjectURL(file);
                files.push({
                    file,
                    preview: src
                });
            }
            setFilesFn(files);
        }
    };
    const submitHandler = async (values)=>{
        const images = [];
        if (files) {
            for(let i = 0; i < files.length; i++){
                const file = files[i].file;
                const ext = file.name.split(".").at(-1);
                const folderPath = `temp/1/Store/${storeId}/writereview/${react_uuid__WEBPACK_IMPORTED_MODULE_7___default()()}.${ext}`;
                const image = await (0,services_file_service__WEBPACK_IMPORTED_MODULE_8__/* .UploadImage */ .z)({
                    folderPath,
                    files: file
                });
                images.push(image);
            }
        }
        const { data  } = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].get("https://geolocation-db.com/json/");
        const imagesA = images.map((url)=>({
                id: 0,
                rowVersion: "",
                location: `${data.city}, ${data.state}, ${data.country_name}, ${data.postal}`,
                ipAddress: data.IPv4,
                macAddress: "00-00-00-00-00-00",
                reviewId: 0,
                imageName: url,
                displayOrder: 0,
                recStatus: "A"
            }));
        const submitObject = {
            reviewModel: {
                id: 0,
                rowVersion: "",
                location: `${data.city}, ${data.state}, ${data.country_name}, ${data.postal}`,
                ipAddress: data.IPv4,
                macAddress: "00-00-00-00-00-00",
                productId: productId && +productId || 0,
                customerId: customerId || 0,
                storeId: storeId || 0,
                commentHeading: values.commentHeading,
                comment: values.comment,
                rating: star,
                helpFullCount: 0,
                notHelpFullCount: 0,
                recStatus: "A",
                images: imagesA
            }
        };
        (0,services_review_service__WEBPACK_IMPORTED_MODULE_9__/* .AddProductReview */ .G)(submitObject);
    };
    const getRatingText = ()=>{
        if (star === 1) {
            return "I HATE IT";
        } else if (star === 2) {
            return "I DON'T LIKE IT";
        } else if (star === 3) {
            return "IT'S OK";
        } else if (star === 4) {
            return "I LIKE IT";
        } else {
            return "I LOVE IT";
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: "container mx-auto my-6",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex flex-wrap -mx-3 gap-y-6",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-full md:w-4/12 lg:w-4/12 px-3",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "images/1040623_25528_STH.jpg",
                                    title: "",
                                    alt: ""
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-full md:w-8/12 lg:w-5/12 px-3",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "text-xl md:text-2xl lg:text-sub-title font-sub-title text-color-sub-title",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            className: "",
                                            children: "Peter Millar Men’s Solid Performance Polo - Knit Collar"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex items-center gap-2 mt-4",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "",
                                                children: "POST PUBLICLY AS:"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "",
                                                children: "Ankit"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "",
                                                children: "|"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    className: "",
                                                    children: "CLEAR"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-full md:w-full lg:w-3/12 px-3",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex items-center justify-end",
                                children: [
                                    Array(5).fill("").map((_, index)=>{
                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                            className: `h-5 w-5 flex-shrink-0 text-${index < star ? "primary-500" : "gray-300"}`,
                                            xmlns: "http://www.w3.org/2000/svg",
                                            viewBox: "0 0 20 20",
                                            fill: "currentColor",
                                            "aria-hidden": "true",
                                            onClick: ()=>setStar(index + 1),
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                d: "M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"
                                            })
                                        }, index);
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        children: getRatingText()
                                    })
                                ]
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "gird grid-cols-1 lg:flex lg:items-center gap-6 lg:py-8 lg:px-12 px-4 py-4 lg:my-5",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-full mx-auto max-w-7xl",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_3__.Formik, {
                        onSubmit: submitHandler,
                        validationSchema: validationSchema,
                        initialValues: {
                            comment: "",
                            commentHeading: ""
                        },
                        enableReinitialize: true,
                        children: ({ values , errors , touched , handleSubmit , handleBlur , handleChange ,  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                                onSubmit: handleSubmit,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex flex-wrap -mx-3 gap-y-6",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "w-full px-3",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    htmlFor: "First Name",
                                                    className: "block text-base font-medium text-gray-700",
                                                    children: "Description For your review"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "mt-2",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                                            placeholder: "Description For your review",
                                                            className: "form-input",
                                                            name: "comment",
                                                            onChange: handleChange,
                                                            onBlur: handleBlur,
                                                            value: values.comment,
                                                            children: " "
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "text-red-500 text-s mt-1",
                                                            children: touched.comment && errors.comment
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "w-full px-3",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    htmlFor: "First Name",
                                                    className: "block text-base font-medium text-gray-700",
                                                    children: "Headline For your review"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "mt-2",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                            type: "text",
                                                            placeholder: "Headline For your review",
                                                            className: "form-input",
                                                            name: "commentHeading",
                                                            onChange: handleChange,
                                                            onBlur: handleBlur,
                                                            value: values.commentHeading
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "text-red-500 text-s mt-1",
                                                            children: touched.commentHeading && errors.commentHeading
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "w-full px-3",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    htmlFor: "Address 1",
                                                    className: "block text-base font-medium text-gray-700",
                                                    children: "Select files to upload"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "mt-2",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        type: "file",
                                                        placeholder: "Select files to upload",
                                                        value: "",
                                                        className: "form-input",
                                                        multiple: true,
                                                        onChange: fileChangeHandler
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "flex flex-wrap",
                                                    children: files.map((file, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "h-24 w-24 m-2",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                src: file.preview,
                                                                alt: "preview"
                                                            })
                                                        }, index))
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "w-full lg:w-full px-3",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                type: "submit",
                                                className: "btn btn-primary",
                                                children: "Submit"
                                            })
                                        })
                                    ]
                                })
                            })
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductReview);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3201:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ UploadImage)
/* harmony export */ });
/* harmony import */ var _utils_axios_util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(795);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__]);
_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const UploadImage = async ({ folderPath , files  })=>{
    const url = `/upload/image?folderPath=${folderPath}`;
    const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__/* .SendAsyncV2 */ .y)({
        url: url,
        method: "POST",
        data: {
            files
        }
    });
    return res.data;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2200:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "G": () => (/* binding */ AddProductReview)
/* harmony export */ });
/* harmony import */ var _utils_axios_util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(795);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__]);
_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const AddProductReview = async (payload)=>{
    const url = `/StoreProduct/createproductreview.json`;
    const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__/* .SendAsyncV2 */ .y)({
        url: url,
        method: "POST",
        data: payload
    });
    return res.data;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2296:
/***/ ((module) => {

module.exports = require("formik");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 1295:
/***/ ((module) => {

module.exports = require("react-uuid");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 7564:
/***/ ((module) => {

module.exports = import("chalk");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9483,6183,4108], () => (__webpack_exec__(3893)));
module.exports = __webpack_exports__;

})();