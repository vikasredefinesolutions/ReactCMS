"use strict";
(() => {
var exports = {};
exports.id = 9190;
exports.ids = [9190,6089,4623,7142,1733,6868,892,3011,2164,529,1097,8018];
exports.modules = {

/***/ 3632:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6183);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_2__]);
hooks__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const Price = ({ value , prices  })=>{
    let price = 0;
    const currency = (0,hooks__WEBPACK_IMPORTED_MODULE_2__/* .useTypedSelector */ .ix)((state)=>state.store.currency);
    if (value) prices === null ? price = 0 : price = +value;
    if (prices) {
        prices === null ? price = 0 : prices.msrp;
    }
    const toShow = price.toFixed(2);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            currency,
            toShow
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Price);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7031:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "V": () => (/* binding */ CartPage),
/* harmony export */   "dn": () => (/* binding */ BrandList),
/* harmony export */   "uU": () => (/* binding */ CheckoutPage)
/* harmony export */ });
const BrandList = {
    title: "Personalized Brands Apperal",
    description: "Personalized Brands Apperal",
    keywords: "Gear"
};
const CartPage = {
    title: "Cart",
    description: "Cart Page",
    keywords: "Cart"
};
const CheckoutPage = {
    title: "Checkout",
    description: "Checkout Page",
    keywords: "Checkout"
};


/***/ }),

/***/ 1371:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var appComponents_modals_StartOrderModal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6531);
/* harmony import */ var appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2337);
/* harmony import */ var appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3632);
/* harmony import */ var appComponents_Screen_Layout_Head__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7027);
/* harmony import */ var constants_seo_constant__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7031);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6183);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var services_cart_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7591);
/* harmony import */ var services_product_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2433);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([appComponents_modals_StartOrderModal__WEBPACK_IMPORTED_MODULE_1__, appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_3__, hooks__WEBPACK_IMPORTED_MODULE_6__, services_cart_service__WEBPACK_IMPORTED_MODULE_9__, services_product_service__WEBPACK_IMPORTED_MODULE_10__]);
([appComponents_modals_StartOrderModal__WEBPACK_IMPORTED_MODULE_1__, appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_3__, hooks__WEBPACK_IMPORTED_MODULE_6__, services_cart_service__WEBPACK_IMPORTED_MODULE_9__, services_product_service__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const CartPage = ()=>{
    const { fetchCartDetails , storeDetails , updateCheckoutObject , storeProductColor ,  } = (0,hooks__WEBPACK_IMPORTED_MODULE_6__/* .useActions */ .ol)();
    const cartProducts = (0,hooks__WEBPACK_IMPORTED_MODULE_6__/* .useTypedSelector */ .ix)((state)=>state.cart.cart);
    const { 0: customerId , 1: setCustomerId  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(0);
    const { id: storeId , isAttributeSaparateProduct  } = (0,hooks__WEBPACK_IMPORTED_MODULE_6__/* .useTypedSelector */ .ix)((state)=>state.store);
    (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(()=>{
        if (customerId) {
            fetchCartDetails(customerId);
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        customerId
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(()=>{
        if (localStorage) {
            const id = localStorage.getItem("tempCustomerId");
            if (id) setCustomerId(~~id);
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    const { 0: showEdit , 1: setShowEdit  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(false);
    const { 0: product , 1: setProduct  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)();
    const { 0: currentCartProduct , 1: setCurrentCartProduct  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)();
    const { 0: coupon , 1: setCoupon  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)("");
    const loadProduct = (product)=>{
        if (storeId) {
            const obj = {
                totalQty: product.totalQty,
                sizeQtys: product.shoppingCartItemDetailsViewModels.map((res)=>({
                        size: res.attributeOptionValue,
                        qty: res.qty,
                        price: res.price
                    })),
                totalPrice: product.totalPrice
            };
            updateCheckoutObject(obj);
            setCurrentCartProduct(product);
            (0,services_product_service__WEBPACK_IMPORTED_MODULE_10__/* .FetchProductById */ .f)({
                // seName : seName || 'Nike-Men-s-Club-Fleece-Sleeve-Swoosh-Pullover-Hoodie',
                seName: product.seName,
                storeId,
                productId: 0
            }).then((res)=>{
                setProduct(res);
                if ((res === null || res === void 0 ? void 0 : res.id) !== null) {
                    storeDetails({
                        brand: {
                            id: (res === null || res === void 0 ? void 0 : res.brandID) || null,
                            name: (res === null || res === void 0 ? void 0 : res.brandName) || null,
                            url: (res === null || res === void 0 ? void 0 : res.brandImage) || null
                        },
                        product: {
                            id: (res === null || res === void 0 ? void 0 : res.id) || null,
                            name: (res === null || res === void 0 ? void 0 : res.name) || null,
                            price: {
                                msrp: (res === null || res === void 0 ? void 0 : res.msrp) || 0,
                                ourCost: (res === null || res === void 0 ? void 0 : res.ourCost) || 0,
                                salePrice: (res === null || res === void 0 ? void 0 : res.salePrice) || 0
                            } || null
                        }
                    });
                    (0,services_product_service__WEBPACK_IMPORTED_MODULE_10__/* .FetchColors */ .jW)({
                        productId: res.id,
                        storeId,
                        isAttributeSaparateProduct
                    }).then((res)=>{
                        if (res) {
                            storeProductColor({
                                colors: res
                            });
                            setProduct((pro)=>{
                                if (pro === null || pro === void 0 ? void 0 : pro.id) {
                                    return {
                                        ...pro,
                                        colors: res
                                    };
                                }
                                return undefined;
                            });
                            setShowEdit(true);
                        }
                    });
                }
            });
        }
    };
    const couponCodeSubmit = async ()=>{
        if (coupon) {
            const response = await (0,services_cart_service__WEBPACK_IMPORTED_MODULE_9__/* .checkCoupon */ .tD)({
                promotionsModel: {
                    customerId: customerId,
                    couponCode: coupon,
                    storeId: storeId,
                    taxCost: 0,
                    shippingCost: 0
                }
            });
            if (response.errors) {
                setCoupon(response.errors.errorDesc);
                setTimeout(()=>{
                    setCoupon("");
                }, 3000);
            }
        }
    };
    const deleteCartItem = async (id)=>{
        await (0,services_cart_service__WEBPACK_IMPORTED_MODULE_9__/* .deleteItemCart */ .jT)(id);
        fetchCartDetails(customerId);
    };
    const getTotalPrice = ()=>{
        let totalPrice = 0;
        cartProducts.forEach((res)=>{
            totalPrice += res.totalPrice;
        });
        return totalPrice;
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_Screen_Layout_Head__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                ...constants_seo_constant__WEBPACK_IMPORTED_MODULE_5__/* .CartPage */ .V
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                id: "",
                className: "mt-5",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "bg-white",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "container mx-auto",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex flex-wrap -mx-3 -mt-3 cart-box",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                                    "aria-labelledby": "cart-heading",
                                    className: "w-full lg:w-9/12 px-3 mt-3",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex justify-between items-center bg-gray-200 w-full px-4 py-2",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "text-2xl mr-3",
                                                    children: "Shopping Cart"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "text-base",
                                                    children: [
                                                        cartProducts.length,
                                                        " Item(s)",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "hidden-xs",
                                                            children: " in cart"
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                            id: "cart-heading",
                                            className: "sr-only",
                                            children: "Items in your shopping cart"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                            role: "list",
                                            className: "overflow-hidden",
                                            children: cartProducts.map((product, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                    className: "flex flex-wrap py-5 -mx-3",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "w-full lg:w-1/4 px-3",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                src: product.colorImage,
                                                                alt: "products",
                                                                className: ""
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "w-full lg:w-3/4 px-3 flex flex-wrap lg:justify-between",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "text-lg font-semibold",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                                        href: `/${product.seName}`,
                                                                        id: product.seName,
                                                                        className: "text-black hover:text-anchor-hover",
                                                                        title: "",
                                                                        children: product.productName
                                                                    }, product.seName)
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "w-full flex flex-wrap",
                                                                    children: [
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                            className: "lg:w-2/3 w-full mt-2",
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-between",
                                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                        className: "text-base",
                                                                                        children: [
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                className: "font-semibold",
                                                                                                children: "SKU :"
                                                                                            }),
                                                                                            " ",
                                                                                            product.sku
                                                                                        ]
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "mt-1 flex",
                                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                        className: "text-base",
                                                                                        children: [
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                className: "font-semibold",
                                                                                                children: "Color :"
                                                                                            }),
                                                                                            " ",
                                                                                            product.attributeOptionValue
                                                                                        ]
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                    className: "mt-10",
                                                                                    children: [
                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                            className: "text-base font-semibold border-b pb-2",
                                                                                            children: "Item Details"
                                                                                        }),
                                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                            className: "flex justify-between py-2",
                                                                                            children: [
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                                    className: "text-base font-semibold w-28",
                                                                                                    children: "Size"
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                                    className: "text-base font-semibold w-16 text-center",
                                                                                                    children: "Qty"
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                                    className: "text-base font-semibold w-20 text-right",
                                                                                                    children: "Price"
                                                                                                })
                                                                                            ]
                                                                                        }),
                                                                                        product.shoppingCartItemDetailsViewModels.map((item, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                className: "flex justify-between py-2",
                                                                                                children: [
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                                        className: "text-base w-28",
                                                                                                        children: item.attributeOptionValue
                                                                                                    }),
                                                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                                        className: "text-base w-16 text-center",
                                                                                                        children: item.qty
                                                                                                    }),
                                                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                        className: "text-base w-20 text-right",
                                                                                                        children: [
                                                                                                            "$",
                                                                                                            item.price
                                                                                                        ]
                                                                                                    })
                                                                                                ]
                                                                                            }, index)),
                                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                            className: "flex justify-between py-3 border-t border-b",
                                                                                            children: [
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                                    className: "text-base w-28",
                                                                                                    children: "Product Total:"
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                                    className: "text-base w-16 text-center",
                                                                                                    children: product.totalQty
                                                                                                }),
                                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                    className: "text-base w-20 text-right",
                                                                                                    children: [
                                                                                                        "$",
                                                                                                        product.totalPrice
                                                                                                    ]
                                                                                                })
                                                                                            ]
                                                                                        }),
                                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                            className: "flex justify-between py-3",
                                                                                            children: [
                                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                    className: "text-base",
                                                                                                    children: [
                                                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                            className: "mb-3 flex",
                                                                                                            children: [
                                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                                                    src: "images/logo-to-be-submitted.webp",
                                                                                                                    title: "",
                                                                                                                    alt: ""
                                                                                                                }),
                                                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                                                    className: "font-semibold ml-3",
                                                                                                                    children: [
                                                                                                                        "Logo to be",
                                                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                                                                                        "submitted"
                                                                                                                    ]
                                                                                                                })
                                                                                                            ]
                                                                                                        }),
                                                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                            children: [
                                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                                    className: "font-semibold",
                                                                                                                    children: "Location:"
                                                                                                                }),
                                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                                                    children: "Right Sleeve"
                                                                                                                })
                                                                                                            ]
                                                                                                        })
                                                                                                    ]
                                                                                                }),
                                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                                    className: "text-base text-right",
                                                                                                    children: [
                                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                                            className: "font-semibold",
                                                                                                            children: "Logo Price"
                                                                                                        }),
                                                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                                            children: "First Logo Free"
                                                                                                        })
                                                                                                    ]
                                                                                                })
                                                                                            ]
                                                                                        })
                                                                                    ]
                                                                                })
                                                                            ]
                                                                        }),
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                            className: "mt-2 lg:w-1/3 w-full",
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "bold text-xl text-right",
                                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                        className: "",
                                                                                        children: [
                                                                                            "Item Total:",
                                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                                                            "$",
                                                                                            product.totalPrice
                                                                                        ]
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "mt-6 lg:ml-10",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                                        onClick: ()=>loadProduct(product),
                                                                                        "data-modal-toggle": "startorderModal",
                                                                                        className: "btn btn-secondary !w-full !py-1 text-center",
                                                                                        children: "EDIT ITEM"
                                                                                    })
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "mt-3 lg:ml-10",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                                        onClick: ()=>deleteCartItem(product.shoppingCartItemsId),
                                                                                        className: "btn btn-primary !w-full !py-1 text-center",
                                                                                        children: "REMOVE"
                                                                                    })
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }, index))
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                                    "aria-labelledby": "summary-heading",
                                    className: "w-full lg:w-3/12 px-3 mt-3",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "border border-slate-400 bg-white",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "bg-gray-200 w-full text-lg font-medium px-4 py-1",
                                                    children: "Cart Summary"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "px-4 py-4",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("dl", {
                                                        className: "space-y-2",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "text-lg",
                                                                children: "Products Price"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "flex items-center justify-between pt-2",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("dt", {
                                                                        className: "text-base",
                                                                        children: "Subtotal"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("dd", {
                                                                        className: "text-base font-medium text-gray-900",
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                                            value: getTotalPrice()
                                                                        })
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "flex items-center justify-between border-t border-gray-200 pt-2",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("dt", {
                                                                        className: "text-base",
                                                                        children: "Estimated Tax"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("dd", {
                                                                        className: "text-base font-medium text-gray-900",
                                                                        children: "$00.00"
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "border-t border-gray-200 flex items-center relative",
                                                                children: [
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("dt", {
                                                                        className: "text-base z-0 w-full promocode",
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                                name: "Promo_code",
                                                                                id: "Promo_code",
                                                                                placeholder: "Promo code",
                                                                                onChange: (e)=>setCoupon(e.target.value),
                                                                                value: coupon,
                                                                                className: "peer placeholder:opacity-0 block w-full bg-transparent pt-2 appearance-none focus:outline-none focus:ring-0 focus:border-black border-gray-200 pr-10 relative z-10"
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                                htmlFor: "Promo_code",
                                                                                className: "absolute duration-300 -top-3 -z-1 origin-0 text-base bg-white peer-focus:-top-3 peer-placeholder-shown:top-2",
                                                                                children: "Promo code"
                                                                            })
                                                                        ]
                                                                    }),
                                                                    coupon && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                        onClick: ()=>couponCodeSubmit(),
                                                                        className: "coupon-code-Apply text-sm absolute right-0 top-2",
                                                                        children: "Apply"
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "border-t border-gray-200 pt-2 flex items-center justify-between",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("dt", {
                                                                        className: "flex items-center text-base",
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                            children: "Shipping"
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("dd", {
                                                                        className: "text-base font-medium text-gray-900",
                                                                        children: "$00.00"
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "flex justify-between items-center bg-gray-200 w-full text-lg font-medium px-4 py-1",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            children: "Total:"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                                value: getTotalPrice()
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "mt-4",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                id: "checkout",
                                                href: "/Checkout",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                                    className: "btn btn-lg btn-secondary !flex items-center justify-center w-full",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                            className: "fa fa-shopping-cart mr-2",
                                                            "aria-hidden": "true"
                                                        }),
                                                        "CHECKOUT NOW"
                                                    ]
                                                })
                                            }, "/checkout")
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "mt-4 bg-gray-200 px-4 py-4",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "flex items-center justify-center",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                            src: "images/order-risk-free-icon.jpg",
                                                            alt: "",
                                                            className: "mr-2"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "text-xl font-semibold",
                                                            children: "Order Risk-Free!"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "flex items-center justify-center text-lg text-center mt-3",
                                                    children: "Cancel your order without penalty anytime before your proof is approved."
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                })
            }),
            showEdit && product && product.id !== null && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_modals_StartOrderModal__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                modalHandler: ()=>setShowEdit(false),
                product: product,
                editDetails: currentCartProduct
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CartPage);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2296:
/***/ ((module) => {

module.exports = require("formik");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 7564:
/***/ ((module) => {

module.exports = import("chalk");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3598,1313,1664,5675,9483,6183,2337,2433,3019], () => (__webpack_exec__(1371)));
module.exports = __webpack_exports__;

})();