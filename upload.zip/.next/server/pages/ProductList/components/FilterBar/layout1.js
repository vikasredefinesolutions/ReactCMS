"use strict";
(() => {
var exports = {};
exports.id = 8279;
exports.ids = [8279,6089,4623,7142,1733,6868,892,3011];
exports.modules = {

/***/ 7197:
/***/ ((module) => {

module.exports = require("@fortawesome/react-fontawesome");

/***/ }),

/***/ 1583:
/***/ ((module) => {

module.exports = require("@mui/icons-material/GridView");

/***/ }),

/***/ 3929:
/***/ ((module) => {

module.exports = require("@mui/icons-material/TuneOutlined");

/***/ }),

/***/ 7644:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ViewAgendaOutlined");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 4563:
/***/ ((module) => {

module.exports = import("@fortawesome/free-solid-svg-icons");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [7961,8256], () => (__webpack_exec__(8256)));
module.exports = __webpack_exports__;

})();