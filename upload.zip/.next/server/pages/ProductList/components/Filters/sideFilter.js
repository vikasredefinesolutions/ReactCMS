"use strict";
(() => {
var exports = {};
exports.id = 892;
exports.ids = [892,6089,4623,6868,3011];
exports.modules = {

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [1801], () => (__webpack_exec__(1801)));
module.exports = __webpack_exports__;

})();