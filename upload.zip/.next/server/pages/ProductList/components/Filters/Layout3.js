"use strict";
(() => {
var exports = {};
exports.id = 6868;
exports.ids = [6868,6089,4623,892,3011];
exports.modules = {

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [5202], () => (__webpack_exec__(5202)));
module.exports = __webpack_exports__;

})();