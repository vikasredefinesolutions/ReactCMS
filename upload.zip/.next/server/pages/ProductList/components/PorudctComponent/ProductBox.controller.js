"use strict";
(() => {
var exports = {};
exports.id = 9139;
exports.ids = [9139];
exports.modules = {

/***/ 3574:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const ProductBoxController = ({ product , colorChangeHandler  })=>{
    const { 0: origin , 1: setOrigin  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
    const { 0: currentProduct , 1: setCurrentProduct  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(product.getProductImageOptionList[0]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        colorChangeHandler(product.id, product.sename || "", product.getProductImageOptionList[0].colorName);
        if (window !== undefined) {
            setOrigin(window.location.origin);
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        setCurrentProduct(product.getProductImageOptionList[0]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        product
    ]);
    return {
        currentProduct,
        origin,
        setCurrentProduct
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductBoxController);


/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3574));
module.exports = __webpack_exports__;

})();