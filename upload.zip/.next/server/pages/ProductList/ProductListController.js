"use strict";
(() => {
var exports = {};
exports.id = 1818;
exports.ids = [1818,529];
exports.modules = {

/***/ 9596:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$D": () => (/* binding */ AddRemoveToCompare),
/* harmony export */   "NX": () => (/* binding */ getSkuList),
/* harmony export */   "VN": () => (/* binding */ getCompareLink)
/* harmony export */ });
/* unused harmony export checkCompare */
const AddRemoveToCompare = (sku)=>{
    if (localStorage) {
        const skuList = getSkuList();
        const index = skuList.findIndex((_sku)=>_sku === sku);
        if (index > -1) {
            skuList.splice(index, 1);
        } else {
            skuList.push(sku);
        }
        localStorage.setItem("compareList", JSON.stringify(skuList));
    }
};
const checkCompare = (sku)=>{
    if (localStorage) {
        const skuList = getSkuList();
        const index = skuList.indexOf((_sku)=>_sku === sku);
        if (index) {
            return true;
        }
    }
    return false;
};
const getCompareLink = ()=>{
    if (localStorage) {
        const skuList = getSkuList();
        return `/itempage/Productcomapre?SKU=${skuList.toString()}`;
    }
    return "";
};
const getSkuList = ()=>{
    const data = localStorage.getItem("compareList");
    return data ? JSON.parse(data) : [];
};


/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 7564:
/***/ ((module) => {

module.exports = import("chalk");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9483,6183,7828], () => (__webpack_exec__(7828)));
module.exports = __webpack_exports__;

})();