"use strict";
(() => {
var exports = {};
exports.id = 1951;
exports.ids = [1951,6089,4623,7142,1733,6868,892,3011,529];
exports.modules = {

/***/ 1196:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _SelectLocation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(206);
/* harmony import */ var _SelectLogo__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2273);
/* harmony import */ var _ShareLater__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8361);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_SelectLocation__WEBPACK_IMPORTED_MODULE_2__, _SelectLogo__WEBPACK_IMPORTED_MODULE_3__, _ShareLater__WEBPACK_IMPORTED_MODULE_4__]);
([_SelectLocation__WEBPACK_IMPORTED_MODULE_2__, _SelectLogo__WEBPACK_IMPORTED_MODULE_3__, _ShareLater__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const CustomizeLogoSteps = ({ setShowOrSelect  })=>{
    const { 0: step , 1: setNextStep  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([
        "SELECT_LOCATION"
    ]);
    if (step[2] === "DONE") {
        setShowOrSelect("SHOW");
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "text-xl md:text-2xl lg:text-sub-title font-sub-title text-color-sub-title",
                    children: "Logo"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "p-4 divide-y divide-gray-200",
                    children: [
                        step[0] === "SELECT_LOCATION" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SelectLocation__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                            setNextStep: setNextStep
                        }),
                        step[1] === "SELECT_NOW" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SelectLogo__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            setNextStep: setNextStep
                        }),
                        step[1] === "SHARE_LATER" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ShareLater__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                            setNextStep: setNextStep
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CustomizeLogoSteps);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8330:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3632);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_1__]);
appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const LogoContainer = ({ id , image , label , status , price , selected , setSelected ,  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
        className: "w-full sm:w-1/2 lg:w-1/4 text-center px-3 flex",
        onClick: ()=>setSelected({
                url: image.url,
                name: label,
                id: id
            }),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: `border-2 hover:border-primary ${selected ? "border-primary" : "border-gray-200"} p-3 w-full text-ceter`,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        className: "inline-block",
                        src: image.url,
                        alt: ""
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mt-2",
                    children: label
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mt-2",
                    children: status
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mt-2",
                    children: [
                        "Estimated Cost: ",
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                            value: price
                        })
                    ]
                })
            ]
        })
    }, id);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LogoContainer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5017:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6183);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_1__]);
hooks__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const LogosToPrint = ({ setShowOrSelect  })=>{
    const selectedLogos = (0,hooks__WEBPACK_IMPORTED_MODULE_1__/* .useTypedSelector */ .ix)((state)=>state.product.toCheckout.logos);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "step-2",
        children: [
            selectedLogos === null || selectedLogos === void 0 ? void 0 : selectedLogos.map((logo, index)=>{
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "border border-gray-200 p-4 mt-4",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "",
                            children: [
                                "Location: ",
                                logo.location.label
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mt-2 w-32",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                className: "inline-block",
                                src: "images/Right-Chest-70-191.jpg",
                                alt: ""
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mt-2",
                            children: [
                                "Logo ",
                                logo.logo.name
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mt-2 flex gap-2 items-center",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "font-semibold",
                                    children: [
                                        "Logo ",
                                        index + 1,
                                        ":"
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "w-20 h-20 p-1 inline-flex items-center justify-center border border-gray-200",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        className: "inline-block",
                                        src: logo.logo.url,
                                        alt: ""
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mt-2",
                            children: "*Please Note: The above logo may not reflect the actual selected colors."
                        })
                    ]
                }, logo.no);
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "mt-4",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    onClick: ()=>setShowOrSelect("SELECT"),
                    className: "btn btn-primary w-full text-center",
                    children: "ADD ANOTHER LOGO"
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LogosToPrint);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 206:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6183);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_2__]);
hooks__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const SelectLocation = ({ setNextStep  })=>{
    const { updateLogoDetails  } = (0,hooks__WEBPACK_IMPORTED_MODULE_2__/* .useActions */ .ol)();
    const { 0: selectedLocation , 1: setLocation  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: showError , 1: setShowError  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { availableOptions  } = (0,hooks__WEBPACK_IMPORTED_MODULE_2__/* .useTypedSelector */ .ix)((state)=>state.product.toCheckout);
    const actionHandler = (action)=>{
        if (selectedLocation === null) {
            setShowError(true);
            return;
        }
        updateLogoDetails({
            location: selectedLocation
        });
        if (action === "later") {
            setNextStep([
                "SELECT_LOCATION",
                "SHARE_LATER"
            ]);
            return;
        }
        if (action === "now") {
            setNextStep([
                "SELECT_LOCATION",
                "SELECT_NOW"
            ]);
            return;
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "p-4",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "text-lg md:text-xl lg:text-small-title font-small-title text-color-small-title mb-2",
                children: [
                    "1. Select a Location",
                    showError && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-rose-600",
                        children: `(Please Select Location)`
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "max-w-5xl",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                    className: "flex flex-wrap gap-y-6 -mx-3",
                    children: availableOptions === null || availableOptions === void 0 ? void 0 : availableOptions.map((pos)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: "w-full sm:w-1/2 lg:w-1/4 text-center px-3 flex",
                            onClick: ()=>{
                                setLocation({
                                    label: pos.label,
                                    value: pos.value
                                });
                                if (showError) {
                                    setShowError(false);
                                }
                            },
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: `border-2 ${(selectedLocation === null || selectedLocation === void 0 ? void 0 : selectedLocation.value) === pos.value ? "border-primary" : "border-gray-200"} hover:border-primary p-3 w-full text-ceter`,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            className: "inline-block",
                                            src: pos.logo.url,
                                            alt: pos.label
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "mt-2",
                                        children: pos.label
                                    })
                                ]
                            })
                        }, pos.value);
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mt-3",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        onClick: ()=>actionHandler("now"),
                        className: "btn btn-primary",
                        children: "SELECT YOUR LOGO"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "OR"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        onClick: ()=>actionHandler("later"),
                        className: "btn btn-primary",
                        children: "SHARE LOGO LATER"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SelectLocation);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2273:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var Assets_images_asset__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1869);
/* harmony import */ var dummy_filters__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5369);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6183);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _LogoContainer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8330);
/* harmony import */ var _UploadLogoPopup__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7383);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_3__, _LogoContainer__WEBPACK_IMPORTED_MODULE_6__]);
([hooks__WEBPACK_IMPORTED_MODULE_3__, _LogoContainer__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const SelectLogo = ({ setNextStep  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const { updateOptions , updateLogoDetails  } = (0,hooks__WEBPACK_IMPORTED_MODULE_3__/* .useActions */ .ol)();
    const { 0: openModal , 1: setOpenModal  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const { 0: showError , 1: setShowError  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const { 0: preLogos , 1: setPreLogos  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(dummy_filters__WEBPACK_IMPORTED_MODULE_2__/* ._PreLogos */ .o);
    const { 0: selected , 1: setSelected  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(null);
    const { logos  } = (0,hooks__WEBPACK_IMPORTED_MODULE_3__/* .useTypedSelector */ .ix)((state)=>state.product.toCheckout);
    const actionHandler = (action)=>{
        if (action === "cancel") {
            router.back();
            return;
        }
        if (selected === null) {
            setShowError(true);
            return;
        }
        if (action === "apply") {
            if (logos !== null) {
                updateOptions({
                    value: logos[logos.length - 1].location.value,
                    label: logos[logos.length - 1].location.label,
                    addOrRemove: "REMOVE",
                    logo: {
                        url: logos[logos.length - 1].logo.url
                    }
                });
                updateLogoDetails({
                    location: logos[logos.length - 1].location,
                    url: selected.url,
                    name: selected.name
                });
            }
            setNextStep([
                "SELECT_LOCATION",
                "SELECT_NOW",
                "DONE"
            ]);
            return;
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "p-4",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "text-lg md:text-xl lg:text-small-title font-small-title text-color-small-title mb-2",
                        children: [
                            "2. Select a Logo",
                            " ",
                            showError && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "text-rose-600",
                                children: `(Please Select Logo)`
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "max-w-5xl",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                            className: "flex flex-wrap gap-y-6 -mx-3",
                            "x-data": "{selected : 0}",
                            children: [
                                preLogos.map((logo, index)=>{
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_LogoContainer__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                        id: logo.id,
                                        image: logo.image,
                                        label: logo.label,
                                        status: logo.status,
                                        price: logo.estimatedCost,
                                        selected: selected,
                                        setSelected: (val)=>{
                                            setSelected(val);
                                            if (showError) {
                                                setShowError(false);
                                            }
                                        }
                                    }, index);
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: "w-full sm:w-1/2 lg:w-1/4 text-center px-3 flex",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "border-2 hover:border-primary p-3 w-full text-ceter border-gray-200",
                                        onClick: ()=>setOpenModal(true),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                className: "inline-block",
                                                src: Assets_images_asset__WEBPACK_IMPORTED_MODULE_1__/* .icons.addNewLogo */ .c.addNewLogo,
                                                alt: ""
                                            })
                                        })
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mt-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                onClick: ()=>actionHandler("apply"),
                                className: "btn btn-primary",
                                children: "APPLY LOGO"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                onClick: ()=>actionHandler("cancel"),
                                className: "btn btn-primary",
                                children: "CANCEL"
                            })
                        ]
                    })
                ]
            }),
            openModal && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UploadLogoPopup__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                id: "upload",
                setOpenModal: setOpenModal,
                logoToShow: (logo)=>setPreLogos((logos)=>[
                            ...logos,
                            {
                                label: logo.name,
                                status: "In Process",
                                estimatedCost: 5,
                                id: 4,
                                image: {
                                    url: logo.previewURL
                                }
                            }, 
                        ])
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SelectLogo);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8361:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6183);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_1__]);
hooks__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const ShareLater = ({ setNextStep  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { updateOptions  } = (0,hooks__WEBPACK_IMPORTED_MODULE_1__/* .useActions */ .ol)();
    const { logos  } = (0,hooks__WEBPACK_IMPORTED_MODULE_1__/* .useTypedSelector */ .ix)((state)=>state.product.toCheckout);
    const actionHandler = (action)=>{
        if (action === "CONTINUE") {
            if (logos !== null) {
                updateOptions({
                    value: logos[logos.length - 1].location.value,
                    label: logos[logos.length - 1].location.label,
                    addOrRemove: "REMOVE",
                    logo: {
                        url: ""
                    }
                });
            }
            setNextStep([
                "SELECT_LOCATION",
                "SHARE_LATER",
                "DONE"
            ]);
            return;
        }
        if (action === "CANCEL") {
            router.back();
            return;
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "p-4",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "text-lg md:text-xl lg:text-small-title font-small-title text-color-small-title mb-2",
                children: "2. Share Logo Later"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "",
                    children: "No Worries! One of our gear guides will be contacting you after your order has been submitted. We can finalize decoration details at that time."
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mt-3",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        onClick: ()=>actionHandler("CONTINUE"),
                        className: "btn btn-primary",
                        children: "CONTINUE"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        onClick: ()=>actionHandler("CANCEL"),
                        className: "btn btn-primary",
                        children: "CANCEL"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ShareLater);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7383:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const UploadLogoPopup = ({ id , setOpenModal , logoToShow ,  })=>{
    const { 0: fileToUpload , 1: setFileToUpload  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const fileReader = (event)=>{
        var ref;
        if (((ref = event.currentTarget) === null || ref === void 0 ? void 0 : ref.files) === null) return;
        const file = {
            name: event.currentTarget.files[0].name,
            type: event.currentTarget.files[0].type,
            previewURL: URL.createObjectURL(event.currentTarget.files[0])
        };
        setFileToUpload(file);
    };
    const continueHandler = ()=>{
        if (fileToUpload === null) {
            return;
        }
        logoToShow(fileToUpload);
        setOpenModal(false);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        id: "addnewlogoModal",
        className: "overflow-y-auto overflow-x-hidden fixed z-50 justify-center items-center h-modal h-full inset-0",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-full h-full bg-black bg-opacity-50 flex items-center justify-center",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "relative px-4 w-full max-w-3xl h-full md:h-auto",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "relative bg-white rounded-lg shadow max-h-screen overflow-y-auto",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex justify-between items-start p-5 rounded-t border-b sticky top-0 left-0 bg-white",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "text-xl font-semibold text-gray-900 lg:text-2xl",
                                    children: "Add a new logo"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    type: "button",
                                    className: "text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center",
                                    onClick: ()=>setOpenModal(false),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                        className: "w-5 h-5",
                                        fill: "currentColor",
                                        viewBox: "0 0 20 20",
                                        xmlns: "http://www.w3.org/2000/svg",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                            fillRule: "evenodd",
                                            d: "M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z",
                                            clipRule: "evenodd"
                                        })
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "p-6",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "mb-2.5",
                                            children: "Accepted formats: .JPG, .GIF, .TIF, .PNG, .BMP,.TIF,.AI and .EPS. Must be 10MB or less."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "mb-2.5",
                                            children: "Please note: The new logo file is a representation of your logo and can be utilized while shopping. Our design team will process the file and email you a sample when it is complete. You will not be charged for the logo setup until you approve the sample."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex flex-wrap",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "w-full sm:w-1/3",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                    className: "",
                                                    htmlFor: id,
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                            type: "file",
                                                            name: id,
                                                            id: id,
                                                            // value={undefined}
                                                            className: "sr-only",
                                                            onChange: fileReader,
                                                            accept: "image/*"
                                                        }),
                                                        !(fileToUpload === null || fileToUpload === void 0 ? void 0 : fileToUpload.previewURL) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "border border-gray-200 bg-gray-50 w-full h-60",
                                                            children: "Choose a logo file"
                                                        }),
                                                        (fileToUpload === null || fileToUpload === void 0 ? void 0 : fileToUpload.previewURL) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                            src: fileToUpload === null || fileToUpload === void 0 ? void 0 : fileToUpload.previewURL,
                                                            alt: "",
                                                            className: "img-responsive"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "mt-3",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        onClick: continueHandler,
                                                        className: "btn btn-primary w-full text-center",
                                                        children: "CONTINUE"
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "w-full sm:w-2/3",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "bg-gray-100 sm:ml-4 p-3",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "arrow"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                        children: "Add Images"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        children: "The logo setup process. JPG, GIF, PNG, BMP, TIF, AI and EPS. Must be 10 MB or less."
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UploadLogoPopup);


/***/ }),

/***/ 3632:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6183);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_2__]);
hooks__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const Price = ({ value , prices  })=>{
    let price = 0;
    const currency = (0,hooks__WEBPACK_IMPORTED_MODULE_2__/* .useTypedSelector */ .ix)((state)=>state.store.currency);
    if (value) prices === null ? price = 0 : price = +value;
    if (prices) {
        prices === null ? price = 0 : prices.msrp;
    }
    const toShow = price.toFixed(2);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            currency,
            toShow
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Price);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5369:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "o": () => (/* binding */ _PreLogos)
/* harmony export */ });
/* unused harmony export filters */
// to show filter options
const filters = [
    {
        component: "filter",
        id: 323,
        css: {
            backGroundColor: "black",
            position: "left"
        },
        attributes: [
            {
                sortId: 1,
                name: "categories",
                component: "checkbox",
                label: "Categories",
                css: {
                    backgroundColor: "",
                    color: "black",
                    font: ""
                },
                options: [
                    {
                        label: "Coat & Jacket",
                        id: "coat-xcydsadf",
                        count: 21
                    },
                    {
                        label: "kids",
                        id: "kids-xcydsadf",
                        count: 21
                    },
                    {
                        label: "T-shirts",
                        id: "tshirt-xcydsadf",
                        count: 21
                    }, 
                ]
            },
            {
                sortId: 3,
                name: "tags",
                component: "chips",
                label: "Categories",
                css: {
                    backgroundColor: "",
                    color: "black",
                    font: ""
                },
                options: [
                    {
                        label: "Coat & Jacket",
                        id: "coat-xcydsadf",
                        count: 21
                    },
                    {
                        label: "kids",
                        count: 21,
                        id: "kids-xcydsadf"
                    },
                    {
                        label: "T-shirts",
                        count: 21,
                        id: "tshirt-xcydsadf"
                    }, 
                ]
            },
            {
                sortId: 2,
                name: "color-plates",
                component: "color",
                label: "Categories",
                css: {
                    backgroundColor: "",
                    color: "black",
                    font: ""
                },
                options: [
                    {
                        color: "blue",
                        id: "coat-xcydsadf",
                        count: 21
                    },
                    {
                        color: "red",
                        id: "kids-xcydsadf",
                        count: 21
                    },
                    {
                        color: "yellow",
                        id: "tshirt-xcydsadf",
                        count: 21
                    }, 
                ]
            }, 
        ]
    }, 
];
const _PreLogos = [
    {
        label: "Logo #PK1663",
        status: "In Process",
        estimatedCost: 5,
        id: 1,
        image: {
            url: "images/Right-Chest-70-191.jpg"
        }
    },
    {
        label: "Logo #PK5571",
        status: "In Process",
        estimatedCost: 5,
        id: 2,
        image: {
            url: "images/Right-Chest-70-191.jpg"
        }
    }, 
];


/***/ }),

/***/ 4021:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Lp": () => (/* binding */ IndexLabels),
/* harmony export */   "QW": () => (/* binding */ logoPositions)
/* harmony export */ });
/* unused harmony export nullOrInitials */
const logoPositions = [
    {
        value: "rightSleeve",
        label: "Right Sleeve",
        selected: false,
        image: {
            url: "images/Right-Chest-70-191.jpg",
            alt: ""
        }
    },
    {
        value: "backYoke",
        label: "Back Yoke",
        selected: false,
        image: {
            url: "images/Right-Chest-70-191.jpg",
            alt: ""
        }
    },
    {
        value: "frontYoke",
        label: "Front Yoke",
        selected: false,
        image: {
            url: "images/Right-Chest-70-191.jpg",
            alt: ""
        }
    }, 
];
const IndexLabels = [
    {
        value: 0,
        label: "First",
        price: "FREE"
    },
    {
        value: 1,
        label: "Second",
        price: 6
    },
    {
        value: 2,
        label: "Third",
        price: 6
    },
    {
        value: 3,
        label: "Fourth",
        price: 6
    },
    {
        value: 4,
        label: "Fifth",
        price: 6
    },
    {
        value: 5,
        label: "Sixth",
        price: 6
    },
    {
        value: 6,
        label: "Seventh",
        price: 6
    }, 
];
const nullOrInitials = [
    {
        size: "sm",
        qty: 12,
        price: "100"
    },
    {
        size: "lg",
        qty: 122,
        price: "100"
    }, 
];


/***/ }),

/***/ 5465:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2337);
/* harmony import */ var Components_CustomizeLogo_CustomizeLogoSteps__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1196);
/* harmony import */ var Components_CustomizeLogo_LogosToPrint__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5017);
/* harmony import */ var constants_store_constant__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7297);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6183);
/* harmony import */ var mock_startModal_mock__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4021);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([Components_CustomizeLogo_CustomizeLogoSteps__WEBPACK_IMPORTED_MODULE_2__, Components_CustomizeLogo_LogosToPrint__WEBPACK_IMPORTED_MODULE_3__, hooks__WEBPACK_IMPORTED_MODULE_5__]);
([Components_CustomizeLogo_CustomizeLogoSteps__WEBPACK_IMPORTED_MODULE_2__, Components_CustomizeLogo_LogosToPrint__WEBPACK_IMPORTED_MODULE_3__, hooks__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const CustomizeLogo = ()=>{
    const { clearLogoUploadHistory  } = (0,hooks__WEBPACK_IMPORTED_MODULE_5__/* .useActions */ .ol)();
    const storeLayout = (0,hooks__WEBPACK_IMPORTED_MODULE_5__/* .useTypedSelector */ .ix)((state)=>state.store.layout);
    const { sizeQtys  } = (0,hooks__WEBPACK_IMPORTED_MODULE_5__/* .useTypedSelector */ .ix)((state)=>state.product.toCheckout);
    const { name: productName  } = (0,hooks__WEBPACK_IMPORTED_MODULE_5__/* .useTypedSelector */ .ix)((state)=>state.product.product);
    const { color: productColor  } = (0,hooks__WEBPACK_IMPORTED_MODULE_5__/* .useTypedSelector */ .ix)((state)=>state.product.selected);
    const { 0: showOrSelect , 1: setShowOrSelect  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)("SELECT");
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        const logos = mock_startModal_mock__WEBPACK_IMPORTED_MODULE_6__/* .logoPositions.map */ .QW.map((logo)=>({
                label: logo.label,
                value: logo.value,
                logo: {
                    url: logo.image.url
                }
            }));
        clearLogoUploadHistory(logos);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_4__/* ._Store.type3 */ .up.type3) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "mainsection pt-5",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "container mx-auto",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "text-xl md:text-2xl lg:text-sub-title font-sub-title text-color-sub-title mb-4",
                        children: "Apply Logo(s)"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "border border-gray-200 p-4 mb-6",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-wrap gap-y-6 -mx-3 mb-6",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "w-full lg:w-1/5 px-3",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "relative",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "border border-gray-200",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "max-w-xl mx-auto",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                        src: productColor.imageUrl,
                                                        alt: productColor.name,
                                                        className: "max-h-full mx-auto"
                                                    })
                                                })
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "w-full lg:w-4/5 px-3",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "mb-4",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                    className: "text-2xl font-bold mb-4",
                                                    children: productName
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "pb-4 flex items-center",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "font-bold inline-block w-24",
                                                            children: "COLOR"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            children: `: ${productColor.name}`
                                                        })
                                                    ]
                                                }),
                                                sizeQtys !== null && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "pb-4 flex items-center",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "font-bold inline-block w-24",
                                                            children: "SIZE / QTY"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            children: `: ${sizeQtys[0].size} / ${sizeQtys[0].qty}`
                                                        })
                                                    ]
                                                }),
                                                sizeQtys !== null && sizeQtys.length > 1 && sizeQtys.map((sizeQty, index)=>{
                                                    if (index === 0) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
                                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "pb-4 flex items-center",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                className: "font-bold inline-block w-24"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                children: `: ${sizeQty.size} / ${sizeQty.qty}`
                                                            })
                                                        ]
                                                    }, index);
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }),
                            showOrSelect === "SELECT" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_CustomizeLogo_CustomizeLogoSteps__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                setShowOrSelect: setShowOrSelect
                            }),
                            showOrSelect === "SHOW" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_CustomizeLogo_LogosToPrint__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                setShowOrSelect: setShowOrSelect
                            })
                        ]
                    })
                ]
            })
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CustomizeLogo);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 7564:
/***/ ((module) => {

module.exports = import("chalk");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3598,5675,9483,6183,2337], () => (__webpack_exec__(5465)));
module.exports = __webpack_exports__;

})();