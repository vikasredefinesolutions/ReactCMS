"use strict";
(() => {
var exports = {};
exports.id = 6219;
exports.ids = [6219,4096,3827,6089,6509,4623,8279,7142,1733,6868,5333,892,3011,7617,4154,7182,7528,529,1097,8018,8981];
exports.modules = {

/***/ 5747:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2337);
/* harmony import */ var constants_store_constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7297);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6183);
/* harmony import */ var page_config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3521);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _SizeChartModal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(785);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_3__, _SizeChartModal__WEBPACK_IMPORTED_MODULE_6__]);
([hooks__WEBPACK_IMPORTED_MODULE_3__, _SizeChartModal__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const AvailableColors = ()=>{
    const { setColor  } = (0,hooks__WEBPACK_IMPORTED_MODULE_3__/* .useActions */ .ol)();
    const storeLayout = (0,hooks__WEBPACK_IMPORTED_MODULE_3__/* .useTypedSelector */ .ix)((state)=>state.store.layout);
    const colors = (0,hooks__WEBPACK_IMPORTED_MODULE_3__/* .useTypedSelector */ .ix)((state)=>state.product.product.colors);
    const { 0: showAllColors , 1: setShowAllColors  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const { 0: showModal , 1: setShowModal  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(null);
    const selectedColor = (0,hooks__WEBPACK_IMPORTED_MODULE_3__/* .useTypedSelector */ .ix)((state)=>state.product.selected.color);
    if (colors === null) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
    const colorsCount = colors.length;
    const showAllColorsButton = colorsCount > page_config__WEBPACK_IMPORTED_MODULE_4__/* .__product.imagesInRow */ .vb.imagesInRow;
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_2__/* ._Store.type1 */ .up.type1) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "text-sm text-gray-600 bg-primary flex flex-wrap justify-between items-center p-2 md:p-0 md:pl-2 my-2",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-lg font-bold text-white",
                        children: "Available Colors:"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex flex-wrap gap-5 text-sm text-center px-2 available-colors",
                    children: colors.map((product, index)=>{
                        const show = showAllColors || index < page_config__WEBPACK_IMPORTED_MODULE_4__/* .__product.imagesInRow */ .vb.imagesInRow;
                        const highlight = product.attributeOptionId === (selectedColor === null || selectedColor === void 0 ? void 0 : selectedColor.attributeOptionId) ? "border-secondary" : "border-slate-200";
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: `w-20 ${show === false && "sr-only"}`,
                            onClick: ()=>setColor(product),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: `border-2 ${highlight} hover:border-secondary mb-1 last:mb-0`,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                        src: product.imageUrl,
                                        alt: product.altTag,
                                        className: "w-full object-center object-cover"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "",
                                    style: {
                                        whiteSpace: "nowrap",
                                        overflow: "hidden",
                                        textOverflow: "ellipsis"
                                    },
                                    children: product.name
                                })
                            ]
                        }, product.attributeOptionId);
                    })
                }),
                showAllColorsButton && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "text-right",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        onClick: ()=>setShowAllColors((showAll)=>!showAll),
                        className: "",
                        children: showAllColors ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "span1",
                            children: "Show Less"
                        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "span1",
                                    children: "See All"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    className: "span2",
                                    children: [
                                        " ",
                                        colorsCount,
                                        " "
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "span3",
                                    children: "Colors"
                                })
                            ]
                        })
                    })
                })
            ]
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_2__/* ._Store.type2 */ .up.type2) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "text-black mb-5 flex items-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "font-bold w-32",
                            children: "Color Name "
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            children: [
                                ": ",
                                selectedColor === null || selectedColor === void 0 ? void 0 : selectedColor.name
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex justify-between flex-wrap items-end mb-5",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex align-top",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "w-32 flex flex-wrap items-center",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "font-bold",
                                        children: "Select Color"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex flex-wrap gap-1 text-sm text-center",
                                    children: colors.map((product)=>{
                                        const active = product.attributeOptionId === (selectedColor === null || selectedColor === void 0 ? void 0 : selectedColor.attributeOptionId) ? " border-[#cdde00]" : "border-[#415364] hover:border-[#cdde00]";
                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: `w-8 h-8 border-2 ${active} cursor-pointer overflow-hidden text-center`,
                                            onClick: ()=>setColor(product),
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                src: product.imageUrl,
                                                alt: product.altTag,
                                                className: "max-h-full mx-auto"
                                            })
                                        }, product.attributeOptionId);
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                onClick: ()=>setShowModal("sizeChart"),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "images/size-chart.jpg",
                                    alt: ""
                                })
                            })
                        }),
                        showModal && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SizeChartModal__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                            modalHandler: setShowModal
                        })
                    ]
                })
            ]
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_2__/* ._Store.type3 */ .up.type3) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-full flex justify-center text-center gap-2 text-md font-bold mb-2",
                    children: "Available Color:"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "sub-image w-full flex justify-center text-center gap-2 text-xs",
                    children: colors.map((product)=>{
                        const highlight = product.attributeOptionId === selectedColor.attributeOptionId ? "border-primary" : "hover:border-primary";
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "overflow-hidden",
                            onClick: ()=>setColor(product),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: `w-20 h-20 border ${highlight} p-1 mb-1`,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                        src: product.imageUrl,
                                        alt: product.altTag,
                                        className: "max-h-full mx-auto"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "text-primary",
                                    children: product.name
                                })
                            ]
                        }, product.attributeOptionId);
                    })
                })
            ]
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_2__/* ._Store.type4 */ .up.type4) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-full flex justify-center text-center gap-2 text-md font-bold mb-2",
                    children: "Available Color:"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "sub-image w-full flex justify-center text-center gap-2 text-xs",
                    children: colors.map((product)=>{
                        const hightlight = product.attributeOptionId === (selectedColor === null || selectedColor === void 0 ? void 0 : selectedColor.attributeOptionId) ? "border-secondary" : "border-gray-300 hover:border-secondary";
                        if (product.imageUrl === null) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "overflow-hidden",
                            onClick: ()=>setColor(product),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: `w-20 h-20 border-2 ${hightlight} p-1 mb-1`,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                        src: product.imageUrl,
                                        alt: product.altTag,
                                        className: "max-h-full mx-auto"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "text-primary",
                                    children: product.name
                                })
                            ]
                        }, product.attributeOptionId);
                    })
                })
            ]
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AvailableColors);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7193:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2337);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6183);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_2__]);
hooks__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const AvailableInventoryModal = ({ modalHandler  })=>{
    const { colors , brand , name: productName , inventory , sizes ,  } = (0,hooks__WEBPACK_IMPORTED_MODULE_2__/* .useTypedSelector */ .ix)((state)=>state.product.product);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        onClick: ()=>modalHandler(null),
        id: "availableinventoryModal",
        className: " overflow-y-auto overflow-x-hidden fixed right-0 left-0 top-4 z-50 justify-center items-center h-modal md:h-full md:inset-0",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-full h-full bg-black bg-opacity-50 flex items-center justify-center",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "relative px-4 w-full max-w-3xl h-full md:h-auto",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "relative bg-gray-200 shadow max-h-screen overflow-y-auto",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "px-4 lg:px-10 bg-blue-900 text-white",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex flex-wrap items-center justify-between py-6",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "pl-8",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                src: brand.url,
                                                alt: "",
                                                className: ""
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "uppercase font-semibold flex flex-wrap items-center",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    fill: "white",
                                                    className: " w-6 h-6 mr-1",
                                                    viewBox: "0 0 48 48",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                        d: "M23.55 9.4Q24.45 9.4 25.1 8.75Q25.75 8.1 25.75 7.2Q25.75 6.3 25.1 5.65Q24.45 5 23.55 5Q22.65 5 22 5.65Q21.35 6.3 21.35 7.2Q21.35 8.1 22 8.75Q22.65 9.4 23.55 9.4ZM21.55 41.3H9Q7.8 41.3 6.9 40.4Q6 39.5 6 38.3V9.2Q6 8 6.9 7.1Q7.8 6.2 9 6.2H18.25Q18.55 4.55 20.05 3.275Q21.55 2 23.55 2Q25.55 2 27.075 3.275Q28.6 4.55 28.85 6.2H38.1Q39.3 6.2 40.2 7.1Q41.1 8 41.1 9.2V19.35H38.1V9.2Q38.1 9.2 38.1 9.2Q38.1 9.2 38.1 9.2H32.8V15.7H14.3V9.2H9Q9 9.2 9 9.2Q9 9.2 9 9.2V38.3Q9 38.3 9 38.3Q9 38.3 9 38.3H21.55ZM31 40.05 23 32.05 25.15 29.9 31 35.75 42.95 23.8 45.1 25.95Z"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "",
                                                    children: "Available Inventory"
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    className: "text-xl font-semibold text-gray-900 lg:text-2xl bg-white p-4 px-8 border-b border-neutral-200",
                                    children: productName
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "p-4 pb-2 lg:pb-4 lg:p-10 pt-0 lg:pt-0 bg-gray-200",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "overflow-x-auto max-h-screen bg-white",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                    cellPadding: "0",
                                    cellSpacing: "0",
                                    className: "table-auto w-full text-xs text-center text-[#191919]",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                            className: "text-xs font-semibold border-b border-neutral-200",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                className: "divide-x divide-slate-200",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                        className: "px-2 py-4 w-32",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "",
                                                            children: "Color"
                                                        })
                                                    }),
                                                    sizes.split(",").map((size)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            className: "px-2 py-4",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "",
                                                                children: size
                                                            })
                                                        }, size))
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                            className: "divide-y divide-slate-200",
                                            children: colors === null || colors === void 0 ? void 0 : colors.map((color)=>{
                                                /*#__PURE__*/ return react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tr", {
                                                    className: "divide-x divide-slate-200",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("td", {
                                                                className: "px-2 py-3",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "w-10 mx-auto mb-1 border border-slate-200",
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                                            src: color.imageUrl,
                                                                            alt: color.altTag,
                                                                            className: ""
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "",
                                                                        children: color.name
                                                                    })
                                                                ]
                                                            }),
                                                            sizes.split(",").map((size, index)=>{
                                                                const foundIt = inventory === null || inventory === void 0 ? void 0 : inventory.inventory.find((int)=>int.name === size && int.colorAttributeOptionId === color.attributeOptionId);
                                                                if (foundIt) {
                                                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                        className: "px-2 py-3",
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "",
                                                                            children: foundIt.inventory === 0 ? foundIt.futureInventory || "-" : foundIt.inventory
                                                                        })
                                                                    }, index);
                                                                }
                                                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
                                                            })
                                                        ]
                                                    })
                                                }, color.attributeOptionId);
                                            })
                                        })
                                    ]
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex items-center justify-end p-4 lg:p-10 pt-0 lg:pt-0",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                onClick: ()=>modalHandler(null),
                                type: "button",
                                className: "p-2 px-3 bg-indigo-600 border border-indigo-600 text-white",
                                children: "Close"
                            })
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AvailableInventoryModal);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7412:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var constants_store_constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7297);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6183);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_3__]);
hooks__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const ColorName = ()=>{
    const storeLayout = (0,hooks__WEBPACK_IMPORTED_MODULE_3__/* .useTypedSelector */ .ix)((state)=>state.store.layout);
    const color = (0,hooks__WEBPACK_IMPORTED_MODULE_3__/* .useTypedSelector */ .ix)((state)=>state.product.selected.color);
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_2__/* ._Store.type3 */ .up.type3) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "pb-4 pt-4 flex items-center",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "font-bold inline-block w-28",
                    children: "Color Name : "
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: color.name
                })
            ]
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ColorName);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1077:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3632);
/* harmony import */ var constants_store_constant__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7297);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6183);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__, hooks__WEBPACK_IMPORTED_MODULE_4__]);
([appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__, hooks__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const DiscountPrice = ({ msrp , salePrice  })=>{
    const { layout: storeLayout  } = (0,hooks__WEBPACK_IMPORTED_MODULE_4__/* .useTypedSelector */ .ix)((state)=>state.store);
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_3__/* ._Store.type3 */ .up.type3) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex items-center gap-2 mb-4",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "",
                    children: "Price Per Item"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "text-3xl font-semibold",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        value: salePrice
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "text-gray-500",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        value: msrp
                    })
                })
            ]
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DiscountPrice);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4861:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6183);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var services_user_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1488);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_1__, services_user_service__WEBPACK_IMPORTED_MODULE_3__]);
([hooks__WEBPACK_IMPORTED_MODULE_1__, services_user_service__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const HeartIcon = ({ className  })=>{
    const selectedColor = (0,hooks__WEBPACK_IMPORTED_MODULE_1__/* .useTypedSelector */ .ix)((state)=>state.product.selected.color);
    const addToWishList = (id)=>{
        if (id === null) return;
        (0,services_user_service__WEBPACK_IMPORTED_MODULE_3__/* .UpdateWishList */ .SD)(id);
    // .then((res) => console.log(res))
    // .catch((res) => console.log(res));
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: className,
        onClick: ()=>{
            return addToWishList((selectedColor === null || selectedColor === void 0 ? void 0 : selectedColor.productId) || null);
        },
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
            className: "material-icons-outlined",
            children: " favorite_border "
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HeartIcon);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1610:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var constants_store_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7297);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6183);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_2__]);
hooks__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const InventoryInput = ({ size , qty , price , isDisabled =false , color ,  })=>{
    const { updateQuantities , updateQuantities2  } = (0,hooks__WEBPACK_IMPORTED_MODULE_2__/* .useActions */ .ol)();
    const { 0: value , 1: setValue  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0);
    const { layout: storeLayout  } = (0,hooks__WEBPACK_IMPORTED_MODULE_2__/* .useTypedSelector */ .ix)((state)=>state.store);
    const handleChange = (event)=>{
        setValue(+event.target.value);
        if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_1__/* ._Store.type1 */ .up.type1) {
            updateQuantities({
                size: size,
                qty: +event.target.value,
                price: price
            });
        } else {
            updateQuantities2({
                size: size,
                qty: +event.target.value,
                price: price,
                color: color || ""
            });
        }
    };
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_1__/* ._Store.type4 */ .up.type4) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                type: "number",
                name: "qty",
                value: value,
                onChange: handleChange,
                min: 0,
                className: "form-input",
                disabled: isDisabled
            })
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_1__/* ._Store.type2 */ .up.type2) {
        if (qty === 0) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "",
            children: "Call for Inventory"
        });
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                type: "number",
                name: "qty",
                value: value,
                onChange: handleChange,
                min: 0,
                className: "border border-[#c2c2c2] px-2.5 py-1 w-20"
            })
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_1__/* ._Store.type3 */ .up.type3) {
        if (qty === 0) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "",
            children: "-"
        });
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-20",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                type: "number",
                name: "qty",
                value: value,
                onChange: handleChange,
                min: 0,
                className: "form-input !pr-3 w-full"
            })
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InventoryInput);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4653:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const PersonalizationFontModal = ({ onCancel  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        id: "PersonalizeFontsModal",
        className: "overflow-y-auto overflow-x-hidden fixed z-50 justify-center items-center h-modal h-full inset-0",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-full h-full bg-black bg-opacity-50 flex items-center justify-center",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "relative px-4 w-full max-w-3xl h-full md:h-auto",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "relative bg-white rounded-lg shadow max-h-screen overflow-y-auto",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex justify-between items-start p-5 rounded-t border-b sticky top-0 left-0 bg-white",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "text-xl font-semibold text-gray-900 lg:text-2xl",
                                    children: "Personalization Font Examples"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    type: "button",
                                    className: "text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center",
                                    onClick: ()=>onCancel(null),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                        className: "w-5 h-5",
                                        fill: "currentColor",
                                        viewBox: "0 0 20 20",
                                        xmlns: "http://www.w3.org/2000/svg",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                            fillRule: "evenodd",
                                            d: "M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z",
                                            clipRule: "evenodd"
                                        })
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "p-6",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "mb-6 last:mb-0",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                src: "images/block-l.jpg",
                                                alt: ""
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "p-2 bg-gray-100",
                                            children: "Micro Sans Serif"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "mb-6 last:mb-0",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                src: "images/script-l.jpg",
                                                alt: ""
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "p-2 bg-gray-100",
                                            children: "Easy Script"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "mb-6 last:mb-0",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                src: "images/block-serif-l.jpg",
                                                alt: ""
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "p-2 bg-gray-100",
                                            children: "Bookman"
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PersonalizationFontModal);


/***/ }),

/***/ 655:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2337);
/* harmony import */ var appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3632);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var page_config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3521);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8096);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__]);
appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const ProductAlike = ({ title , products  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const sliderRef = (0,react__WEBPACK_IMPORTED_MODULE_5__.useRef)(null);
    const goToNextProduct = ()=>{
        sliderRef.current.slickNext();
    };
    const goToPrevProduct = ()=>{
        sliderRef.current.slickPrev();
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: products === null ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "mainsection mt-10",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "container mx-auto",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full text-center text-2xl md:text-3xl lg:text-title font-title text-color-title text-color-title mb-4",
                        children: title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "relative",
                        id: "slider",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_slick__WEBPACK_IMPORTED_MODULE_6___default()), {
                            ref: (c)=>sliderRef.current = c,
                            ...page_config__WEBPACK_IMPORTED_MODULE_4__/* .sliderSettings.similarProducts */ .K6.similarProducts,
                            children: products.map((product)=>{
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "slide-item",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "px-2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "flex text-center lg:w-auto mb-6",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "relative pb-4",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "w-full bg-gray-200 rounded-md overflow-hidden aspect-w-1 aspect-h-1",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            onClick: ()=>router.push(product.seName),
                                                            // href={`${encodeURIComponent(product.seName)}`}
                                                            className: "relative",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                                src: product.image,
                                                                alt: product.name,
                                                                className: "w-auto h-auto max-h-max"
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "mt-6",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                onClick: ()=>router.push(product.seName),
                                                                className: "mt-1 text-anchor hover:text-anchor-hover",
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "relative underline",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                            className: "absolute inset-0"
                                                                        }),
                                                                        product.name
                                                                    ]
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "mt-3 text-black text-base tracking-wider",
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                    className: "font-semibold",
                                                                    children: [
                                                                        "MSRP ",
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                            value: product.msrp
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        })
                                    })
                                }, product.id);
                            })
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductAlike);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7103:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var constants_store_constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7297);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6183);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_3__]);
hooks__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const ProducAvailableSizes = ()=>{
    const storeLayout = (0,hooks__WEBPACK_IMPORTED_MODULE_3__/* .useTypedSelector */ .ix)((state)=>state.store.layout);
    const sizes = (0,hooks__WEBPACK_IMPORTED_MODULE_3__/* .useTypedSelector */ .ix)((state)=>state.product.product.sizes);
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_2__/* ._Store.type1 */ .up.type1) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "text-lg",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "font-semibold",
                    children: "Available Size(s):"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: ` ${sizes}`
                })
            ]
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProducAvailableSizes);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3527:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2337);
/* harmony import */ var constants_store_constant__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7297);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6183);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_4__]);
hooks__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const ProductColors = ()=>{
    const storeLayout = (0,hooks__WEBPACK_IMPORTED_MODULE_4__/* .useTypedSelector */ .ix)((state)=>state.store.layout);
    const colors = (0,hooks__WEBPACK_IMPORTED_MODULE_4__/* .useTypedSelector */ .ix)((state)=>state.product.product.colors);
    const { setColor  } = (0,hooks__WEBPACK_IMPORTED_MODULE_4__/* .useActions */ .ol)();
    if (colors === null) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_3__/* ._Store.type3 */ .up.type3) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex align-top mb-4",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "w-24 flex flex-wrap items-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "font-bold",
                            children: "Colors:"
                        }),
                        " "
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex flex-wrap text-center pl-0",
                    children: colors.map((product)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-8",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                onClick: ()=>setColor(product),
                                className: "w-8 h-8 border-2 text-center inline-block border-transparent hover:border-primary border-primary",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    src: product.imageUrl,
                                    alt: product.altTag,
                                    className: "max-h-full inline-block"
                                })
                            })
                        }, product.productId);
                    })
                })
            ]
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductColors);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7336:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var constants_store_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7297);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6183);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_2__]);
hooks__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const ProductCompanion = ({ name , imageUrl , id  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const storeLayout = (0,hooks__WEBPACK_IMPORTED_MODULE_2__/* .useTypedSelector */ .ix)((state)=>state.store.layout);
    if (name === null) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
    const goToProduct = (id)=>{
        if (id === null) return;
        router.push(`/product/${id}`);
    };
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_1__/* ._Store.type3 */ .up.type3) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "pt-10 mx-auto max-w-xs text-center",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mb-2 text-2xl",
                    children: "COMPANION"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "",
                            onClick: ()=>goToProduct(id),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: imageUrl || "/dummyShirtImage.jpg",
                                alt: name,
                                className: "max-h-full mx-auto "
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mt-2",
                            children: name
                        })
                    ]
                }, name)
            ]
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_1__/* ._Store.type4 */ .up.type4) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "text-black mb-5 text-sm",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "font-bold mr-1",
                    children: "Companion Product"
                }),
                " :",
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "",
                    onClick: ()=>goToProduct(id),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        className: "text-anchor hover:text-anchor-hover",
                        children: name
                    })
                }, name)
            ]
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "text-lg m-3",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "font-semibold",
                children: "Companion Product:"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    onClick: ()=>goToProduct(id),
                    className: "text-indigo-500 text-sm font-semibold underline",
                    children: name
                })
            }, name)
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductCompanion);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 705:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var constants_store_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7297);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6183);
/* harmony import */ var page_config__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3521);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_2__]);
hooks__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const ProductDescription = ({ text , heading  })=>{
    const { 0: showExtra , 1: setShowExtra  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const storeLayout = (0,hooks__WEBPACK_IMPORTED_MODULE_2__/* .useTypedSelector */ .ix)((state)=>state.store.layout);
    if (!text) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
    const showExtraButton = text.length >= page_config__WEBPACK_IMPORTED_MODULE_3__/* .__product.descriptionLength */ .vb.descriptionLength;
    // const show = useTypedSelector((state) => state.store.display.footer);
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_1__/* ._Store.type1 */ .up.type1) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "m-3",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                    className: "font-semibold text-2xl mb-2",
                    children: heading
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: `relative text-sm text-gray-700 tracking-widest div_description transition-all pb-8 ${!showExtra && "h-40 overflow-hidden"}`,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "pb-3",
                            dangerouslySetInnerHTML: {
                                __html: text
                            }
                        }),
                        showExtraButton && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: `bg-gradient-to-b from-[#fffefe00] to-[#ffffff] absolute bottom-0 left-0 right-0 ${!showExtra && "pt-20"} text-center`,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "text-indigo-500 underline text-sm font-bold",
                                onClick: ()=>setShowExtra((show)=>!show),
                                children: showExtra ? "Read Less" : "Read More"
                            })
                        })
                    ]
                })
            ]
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_1__/* ._Store.type3 */ .up.type3) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "mainsection pt-10",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "container mx-auto",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-full text-center text-2xl md:text-3xl lg:text-title font-title mb-4",
                            children: heading
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "",
                            dangerouslySetInnerHTML: {
                                __html: text
                            }
                        })
                    ]
                })
            })
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_1__/* ._Store.type2 */ .up.type2) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "container mx-auto pt-10",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full text-center text-xl md:text-2xl lg:text-sub-title font-sub-title mb-4",
                        children: heading
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "text-default-text font-default-text",
                        dangerouslySetInnerHTML: {
                            __html: text
                        }
                    })
                ]
            })
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_1__/* ._Store.type4 */ .up.type4) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "mainsection mt-20",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "container mx-auto",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-full text-center text-2xl md:text-3xl lg:text-title font-title mb-4",
                            children: heading
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "text-[#0A1C2B] text-sm",
                            dangerouslySetInnerHTML: {
                                __html: text
                            }
                        })
                    ]
                })
            })
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductDescription);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 971:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var constants_store_constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7297);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6183);
/* harmony import */ var _ProductImg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4350);
/* harmony import */ var _ProductInfo__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7576);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_3__, _ProductImg__WEBPACK_IMPORTED_MODULE_4__, _ProductInfo__WEBPACK_IMPORTED_MODULE_5__]);
([hooks__WEBPACK_IMPORTED_MODULE_3__, _ProductImg__WEBPACK_IMPORTED_MODULE_4__, _ProductInfo__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const ProductDetails = ({ product  })=>{
    const storeLayout = (0,hooks__WEBPACK_IMPORTED_MODULE_3__/* .useTypedSelector */ .ix)((state)=>state.store.layout);
    // const show = useTypedSelector((state) => state.store.display.footer);
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_2__/* ._Store.type1 */ .up.type1) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "container mx-auto mt-6",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "lg:grid lg:grid-cols-2 lg:gap-4 lg:items-start",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductImg__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        product: product
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductInfo__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        product: product
                    })
                ]
            })
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_2__/* ._Store.type2 */ .up.type2) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "container bg-white mx-auto",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "pt-6 border-t border-[#f0f0f0] mt-6 overflow-hidden",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-wrap -mx-3 gap-y-6",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductImg__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                product: product
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductInfo__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                product: product
                            })
                        ]
                    })
                })
            })
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_2__/* ._Store.type3 */ .up.type3) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "mainsection pt-5",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "container mx-auto",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "grid grid-cols-1 lg:grid-cols-2 gap-8 lg:items-start",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductImg__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                            product: product
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductInfo__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            product: product
                        })
                    ]
                })
            })
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_2__/* ._Store.type4 */ .up.type4) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "container mx-auto",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "lg:grid lg:grid-cols-2 lg:gap-x-8 lg:items-start",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductImg__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                            product: product
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductInfo__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            product: product
                        })
                    ]
                })
            })
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductDetails);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3490:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var constants_store_constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7297);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6183);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_3__]);
hooks__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const ProductFeatures = ({ fewFeatures ,  })=>{
    const storeLayout = (0,hooks__WEBPACK_IMPORTED_MODULE_3__/* .useTypedSelector */ .ix)((state)=>state.store.layout);
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_2__/* ._Store.type1 */ .up.type1) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-full text-center flex justify-center mt-5 py-3",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full max-w-5xl grid grid-cols-1 lg:grid-cols-3",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-wrap justify-center items-center border-r border-b border-b-primary lg:border-b-transparent lg:border-r-primary pb-3 lg:pb-0",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "material-icons text-2xl",
                                children: "local_shipping"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "ml-2 text-left text-sm uppercase leading-4",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                        children: "FREE SHIPPING"
                                    }),
                                    " ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    "To One Location"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-wrap justify-center items-center border-r border-b border-b-primary lg:border-b-transparent lg:border-r-primary py-3 lg:py-0",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "material-icons text-2xl",
                                children: "style"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "ml-2 text-left text-sm uppercase leading-4",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                        children: "1ST LOGO FREE"
                                    }),
                                    " ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    "UP TO 10,000 STITCHES"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-wrap justify-center items-center pt-3 lg:pt-0",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "material-icons text-2xl",
                                children: "verified"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "ml-2 text-left text-sm uppercase leading-4",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                        children: "FREE PROOF"
                                    }),
                                    " ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    "ON ALL ORDERS"
                                ]
                            })
                        ]
                    })
                ]
            })
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_2__/* ._Store.type2 */ .up.type2) {
        if (fewFeatures) {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                className: "",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "container mx-auto pt-10",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "bg-[#CFD2D3] p-4 flex flex-wrap",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "w-full lg:w-1/2 border-b lg:border-b-0 lg:border-r last:border-r-0 border-[#8b9ba7] flex justify-center items-center gap-2 text-3xl font-bold px-1 lg:px-6 tracking-wide lg:tracking-widest lg:justify-end",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "w-1/4 lg:w-auto",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: "images/first-logo-img.png",
                                            alt: ""
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        children: "First Logo Free"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "w-full lg:w-1/2 border-r last:border-r-0 border-[#8b9ba7] flex justify-center items-center gap-2 text-3xl font-bold px-1 lg:px-6 tracking-wide lg:tracking-widest lg:justify-start",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "w-1/4 lg:w-auto",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: "images/free-shipping-img.png",
                                            alt: ""
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        children: "Free Shipping"
                                    })
                                ]
                            })
                        ]
                    })
                })
            });
        }
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "py-4 mb-5 text-center bg-[#061b2c] text-white uppercase",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "inline-block py-2 md:py-0 px-8 border-b md:border-b-0 md:border-r border-white",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full md:w-auto flex flex-wrap justify-center items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: "images/free-shipping-new.png",
                                alt: ""
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "leading-5 ml-4 inline-block text-left",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                        className: "block font-extrabold",
                                        children: "Free Shipping"
                                    }),
                                    " ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "To One Location"
                                    })
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "inline-block py-2 md:py-0 px-8",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full md:w-auto flex flex-wrap justify-center items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: "images/logo-free.png",
                                alt: ""
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "leading-5 ml-4 inline-block text-left",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                        className: "block font-extrabold",
                                        children: "1st Logo Free"
                                    }),
                                    " ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "With Order"
                                    })
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "inline-block py-2 md:py-0 px-8 border-t md:border-t-0 md:border-l border-white",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full md:w-auto flex flex-wrap justify-center items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: "images/guarantee.png",
                                alt: ""
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "leading-5 ml-4 inline-block text-left",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                        className: "block font-extrabold",
                                        children: "Satisfaction"
                                    }),
                                    " ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Guarantee"
                                    })
                                ]
                            })
                        ]
                    })
                })
            ]
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_2__/* ._Store.type3 */ .up.type3) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-full bg-[#061b2c] text-center flex justify-center mb-4 py-4 text-white",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full max-w-5xl grid grid-cols-1 lg:grid-cols-3",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-wrap justify-center items-center border-r border-b border-b-white lg:border-b-transparent lg:border-r-white pb-3 lg:pb-0",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "images/free-shipping-new.png",
                                    alt: ""
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "ml-2 text-left text-xs uppercase leading-4",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                        children: "FREE SHIPPING"
                                    }),
                                    " ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    "To One Location"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-wrap justify-center items-center border-r border-b border-b-white lg:border-b-transparent lg:border-r-white py-3 lg:py-0",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "images/logo-free.png",
                                    alt: ""
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "ml-2 text-left text-xs uppercase leading-4",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                        children: "1ST LOGO FREE"
                                    }),
                                    " ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    "UP TO 10,000 STITCHES"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-wrap justify-center items-center pt-3 lg:pt-0",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "images/guarantee.png",
                                    alt: ""
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "ml-2 text-left text-xs uppercase leading-4",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                        children: "FREE PROOF"
                                    }),
                                    " ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    "ON ALL ORDERS"
                                ]
                            })
                        ]
                    })
                ]
            })
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_2__/* ._Store.type4 */ .up.type4) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: " NO product feature component added for Divinig UI "
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: "No Product Feature Component Found"
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductFeatures);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4350:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2337);
/* harmony import */ var constants_paths_constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3125);
/* harmony import */ var constants_store_constant__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7297);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6183);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_inner_image_zoom__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3967);
/* harmony import */ var react_inner_image_zoom__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_inner_image_zoom__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _AvailableColors__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5747);
/* harmony import */ var _HeartIcon__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4861);
/* harmony import */ var _ProductCompanion__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7336);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_4__, _AvailableColors__WEBPACK_IMPORTED_MODULE_8__, _HeartIcon__WEBPACK_IMPORTED_MODULE_9__, _ProductCompanion__WEBPACK_IMPORTED_MODULE_10__]);
([hooks__WEBPACK_IMPORTED_MODULE_4__, _AvailableColors__WEBPACK_IMPORTED_MODULE_8__, _HeartIcon__WEBPACK_IMPORTED_MODULE_9__, _ProductCompanion__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const ProductImg = ({ product  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
    const { setImage  } = (0,hooks__WEBPACK_IMPORTED_MODULE_4__/* .useActions */ .ol)();
    // STATES ----------------------------------------
    const storeLayout = (0,hooks__WEBPACK_IMPORTED_MODULE_4__/* .useTypedSelector */ .ix)((state)=>state.store.layout);
    const selectedColor = (0,hooks__WEBPACK_IMPORTED_MODULE_4__/* .useTypedSelector */ .ix)((state)=>state.product.selected.color);
    const selectedImage = (0,hooks__WEBPACK_IMPORTED_MODULE_4__/* .useTypedSelector */ .ix)((state)=>state.product.selected.image);
    // const show = useTypedSelector((state) => state.store.display.footer);
    // FUNCTIONS  ----------------------------------------
    const selectImgHandler = (img)=>{
        setImage(img);
    };
    // UseEffect's  ----------------------------------------
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        setImage({
            id: 0,
            imageUrl: selectedColor.imageUrl,
            altTag: selectedColor.altTag
        });
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        selectedColor.attributeOptionId
    ]);
    // JSX  ----------------------------------------
    if (product === null) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_3__/* ._Store.type1 */ .up.type1) {
        var ref;
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "col-span-1 grid grid-cols-12 gap-6",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "col-span-12 border border-slate-200 relative",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "main-image max-w-lg mx-auto",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_inner_image_zoom__WEBPACK_IMPORTED_MODULE_7___default()), {
                            src: selectedImage === null || selectedImage === void 0 ? void 0 : selectedImage.imageUrl,
                            zoomType: "hover",
                            // alt={selectedImage.label}
                            hideHint: true,
                            className: "w-full object-center object-cover sm:rounded-lg main_image"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "sub-image md:absolute md:left-2 md:top-4 md:w-20 md:block",
                        children: selectedColor === null || selectedColor === void 0 ? void 0 : (ref = selectedColor.moreImages) === null || ref === void 0 ? void 0 : ref.map((img, index)=>({
                                ...img,
                                id: index
                            })).map((img)=>{
                            const highlight = img.id === selectedImage.id ? "border-secondary" : "border-slate-200 hover:border-secondary";
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: `md:border p-1 mb-1 last:mb-0 ${highlight}`,
                                onClick: ()=>selectImgHandler(img),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                    src: img.imageUrl,
                                    alt: img.altTag,
                                    className: "w-full object-center object-cover"
                                })
                            }, img.id + img.imageUrl);
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_HeartIcon__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                        className: "absolute right-2 top-4 w-6 h-6"
                    })
                ]
            })
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_3__/* ._Store.type2 */ .up.type2) {
        var ref1;
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-full lg:w-6/12 px-3",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "",
                        onClick: ()=>router.push(constants_paths_constant__WEBPACK_IMPORTED_MODULE_2__/* .paths.PRODUCT_LISTING */ .H.PRODUCT_LISTING),
                        children: "<< Back"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "main-image border border-[#f0f0f0] mb-3",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_inner_image_zoom__WEBPACK_IMPORTED_MODULE_7___default()), {
                            src: selectedImage === null || selectedImage === void 0 ? void 0 : selectedImage.imageUrl,
                            zoomType: "hover",
                            // alt={selectedImage.label}
                            hideHint: true,
                            className: "max-h-full mx-auto"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "sub-image w-full flex justify-center text-center gap-2",
                        children: selectedColor === null || selectedColor === void 0 ? void 0 : (ref1 = selectedColor.moreImages) === null || ref1 === void 0 ? void 0 : ref1.map((img, index)=>({
                                ...img,
                                id: index
                            })).map((img)=>{
                            const highlight = img.id === selectedImage.id ? "border-[#cdde00]" : "border-[#415364] hover:border-[#cdde00]";
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: `w-20 h-20 overflow-hidden border ${highlight} p-1`,
                                onClick: ()=>selectImgHandler(img),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                    src: img.imageUrl,
                                    alt: img.altTag,
                                    className: "max-h-full mx-auto"
                                })
                            }, img.id);
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "max-w-sm mx-auto text-center mt-5",
                        children: "This product is subject to order minimum and maximum quantity requirements"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_HeartIcon__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                        className: "absolute right-2 top-4 w-6 h-6"
                    })
                ]
            })
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_3__/* ._Store.type3 */ .up.type3) {
        var ref2;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "relative",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "relative",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "border border-gray-200 mb-3",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "main-image max-w-xl mx-auto",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_inner_image_zoom__WEBPACK_IMPORTED_MODULE_7___default()), {
                                    src: selectedImage === null || selectedImage === void 0 ? void 0 : selectedImage.imageUrl,
                                    zoomType: "hover",
                                    // alt={selectedImage.label}
                                    hideHint: true,
                                    className: "max-h-full mx-auto"
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "sub-image absolute left-2 top-4 w-20 block",
                            children: selectedColor === null || selectedColor === void 0 ? void 0 : (ref2 = selectedColor.moreImages) === null || ref2 === void 0 ? void 0 : ref2.map((img, index)=>({
                                    ...img,
                                    id: index
                                })).map((img)=>{
                                const highlight = img.id === selectedImage.id ? "border-primary" : "hover:border-primary";
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: `border ${highlight} p-1 mb-1 last:mb-0`,
                                    onClick: ()=>selectImgHandler(img),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                        src: img.imageUrl,
                                        alt: img.altTag,
                                        className: "w-full object-center object-cover"
                                    })
                                }, img.id);
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_HeartIcon__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                            className: "absolute right-2 top-4 w-6 h-6"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_AvailableColors__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductCompanion__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                    name: product.companionProductName,
                    id: product.companionProductId,
                    link: product.companionProductLink,
                    imageUrl: product.companionProductImage
                })
            ]
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_3__/* ._Store.type4 */ .up.type4) {
        var ref3;
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "col-span-1",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "relative",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "main-image border border-gray-200 mb-3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_inner_image_zoom__WEBPACK_IMPORTED_MODULE_7___default()), {
                                    src: selectedImage === null || selectedImage === void 0 ? void 0 : selectedImage.imageUrl,
                                    zoomType: "hover",
                                    // alt={selectedImage.label}
                                    hideHint: true,
                                    className: "max-h-full mx-auto"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "sub-image absolute left-2 top-4 w-20 block",
                                children: selectedColor === null || selectedColor === void 0 ? void 0 : (ref3 = selectedColor.moreImages) === null || ref3 === void 0 ? void 0 : ref3.map((img, index)=>({
                                        ...img,
                                        id: index
                                    })).map((img)=>{
                                    const hightlight = img.id === selectedImage.id ? "border-secondary" : "border-gray-300 hover:border-secondary";
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: `border ${hightlight} p-1 mb-1 last:mb-0`,
                                        onClick: ()=>selectImgHandler(img),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                            src: img.imageUrl,
                                            alt: img.altTag,
                                            className: "w-full object-center object-cover"
                                        })
                                    }, img.id);
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_HeartIcon__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                className: "absolute right-2 top-4 w-6 h-6"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_AvailableColors__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {})
                ]
            })
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductImg);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7576:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var appComponents_modals_ForgotModal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5402);
/* harmony import */ var appComponents_modals_LoginModal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(365);
/* harmony import */ var appComponents_modals_StartOrderModal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6531);
/* harmony import */ var appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3632);
/* harmony import */ var appComponents_ui_AddToCartButton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4915);
/* harmony import */ var constants_paths_constant__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3125);
/* harmony import */ var constants_store_constant__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7297);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6183);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _AskToLogin__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7388);
/* harmony import */ var _AvailableColors__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5747);
/* harmony import */ var _AvailableInventoryModal__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(7193);
/* harmony import */ var _ColorName__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7412);
/* harmony import */ var _DiscountPrice__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1077);
/* harmony import */ var _DiscountPricing__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(2972);
/* harmony import */ var _PersonalizationFontModal__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(4653);
/* harmony import */ var _PriceTable__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(1313);
/* harmony import */ var _ProductAvailableSizes__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(7103);
/* harmony import */ var _ProductColors__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(3527);
/* harmony import */ var _ProductCompanion__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(7336);
/* harmony import */ var _ProductDescription__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(705);
/* harmony import */ var _ProductFeatures__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(3490);
/* harmony import */ var _ProductInventory__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(7767);
/* harmony import */ var _ProductMinimumQuantity__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(6336);
/* harmony import */ var _ProductNote__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(6785);
/* harmony import */ var _ProductPrice__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(3437);
/* harmony import */ var _ProductQuoteRequest__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(7084);
/* harmony import */ var _ProductRequestConsultation__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(6910);
/* harmony import */ var _ProductSKU__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(2);
/* harmony import */ var _ProductStarReviews__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(9581);
/* harmony import */ var _SizeChartModal__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(785);
/* harmony import */ var _TopRatedProducts__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(5037);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([appComponents_modals_ForgotModal__WEBPACK_IMPORTED_MODULE_1__, appComponents_modals_LoginModal__WEBPACK_IMPORTED_MODULE_2__, appComponents_modals_StartOrderModal__WEBPACK_IMPORTED_MODULE_3__, appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_4__, appComponents_ui_AddToCartButton__WEBPACK_IMPORTED_MODULE_5__, hooks__WEBPACK_IMPORTED_MODULE_8__, _AskToLogin__WEBPACK_IMPORTED_MODULE_11__, _AvailableColors__WEBPACK_IMPORTED_MODULE_12__, _AvailableInventoryModal__WEBPACK_IMPORTED_MODULE_13__, _ColorName__WEBPACK_IMPORTED_MODULE_14__, _DiscountPrice__WEBPACK_IMPORTED_MODULE_15__, _DiscountPricing__WEBPACK_IMPORTED_MODULE_16__, _PriceTable__WEBPACK_IMPORTED_MODULE_18__, _ProductAvailableSizes__WEBPACK_IMPORTED_MODULE_19__, _ProductColors__WEBPACK_IMPORTED_MODULE_20__, _ProductCompanion__WEBPACK_IMPORTED_MODULE_21__, _ProductDescription__WEBPACK_IMPORTED_MODULE_22__, _ProductFeatures__WEBPACK_IMPORTED_MODULE_23__, _ProductInventory__WEBPACK_IMPORTED_MODULE_24__, _ProductMinimumQuantity__WEBPACK_IMPORTED_MODULE_25__, _ProductNote__WEBPACK_IMPORTED_MODULE_26__, _ProductPrice__WEBPACK_IMPORTED_MODULE_27__, _ProductQuoteRequest__WEBPACK_IMPORTED_MODULE_28__, _ProductRequestConsultation__WEBPACK_IMPORTED_MODULE_29__, _ProductSKU__WEBPACK_IMPORTED_MODULE_30__, _SizeChartModal__WEBPACK_IMPORTED_MODULE_32__, _TopRatedProducts__WEBPACK_IMPORTED_MODULE_33__]);
([appComponents_modals_ForgotModal__WEBPACK_IMPORTED_MODULE_1__, appComponents_modals_LoginModal__WEBPACK_IMPORTED_MODULE_2__, appComponents_modals_StartOrderModal__WEBPACK_IMPORTED_MODULE_3__, appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_4__, appComponents_ui_AddToCartButton__WEBPACK_IMPORTED_MODULE_5__, hooks__WEBPACK_IMPORTED_MODULE_8__, _AskToLogin__WEBPACK_IMPORTED_MODULE_11__, _AvailableColors__WEBPACK_IMPORTED_MODULE_12__, _AvailableInventoryModal__WEBPACK_IMPORTED_MODULE_13__, _ColorName__WEBPACK_IMPORTED_MODULE_14__, _DiscountPrice__WEBPACK_IMPORTED_MODULE_15__, _DiscountPricing__WEBPACK_IMPORTED_MODULE_16__, _PriceTable__WEBPACK_IMPORTED_MODULE_18__, _ProductAvailableSizes__WEBPACK_IMPORTED_MODULE_19__, _ProductColors__WEBPACK_IMPORTED_MODULE_20__, _ProductCompanion__WEBPACK_IMPORTED_MODULE_21__, _ProductDescription__WEBPACK_IMPORTED_MODULE_22__, _ProductFeatures__WEBPACK_IMPORTED_MODULE_23__, _ProductInventory__WEBPACK_IMPORTED_MODULE_24__, _ProductMinimumQuantity__WEBPACK_IMPORTED_MODULE_25__, _ProductNote__WEBPACK_IMPORTED_MODULE_26__, _ProductPrice__WEBPACK_IMPORTED_MODULE_27__, _ProductQuoteRequest__WEBPACK_IMPORTED_MODULE_28__, _ProductRequestConsultation__WEBPACK_IMPORTED_MODULE_29__, _ProductSKU__WEBPACK_IMPORTED_MODULE_30__, _SizeChartModal__WEBPACK_IMPORTED_MODULE_32__, _TopRatedProducts__WEBPACK_IMPORTED_MODULE_33__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


































const ProductInfo = ({ product  })=>{
    const { setShowLoader  } = (0,hooks__WEBPACK_IMPORTED_MODULE_8__/* .useActions */ .ol)();
    const { 0: openModal , 1: setOpenModal  } = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)(null);
    const { layout: storeLayout  } = (0,hooks__WEBPACK_IMPORTED_MODULE_8__/* .useTypedSelector */ .ix)((state)=>state.store);
    const { id: userId  } = (0,hooks__WEBPACK_IMPORTED_MODULE_8__/* .useTypedSelector */ .ix)((state)=>state.user);
    const { price: pricePerItem , totalPrice , totalQty , minQtyCheck ,  } = (0,hooks__WEBPACK_IMPORTED_MODULE_8__/* .useTypedSelector */ .ix)((state)=>state.product.toCheckout);
    // const show = useTypedSelector((state) => state.store.display.footer);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_9__.useRouter)();
    const modalHandler = (param)=>{
        if (param) {
            setOpenModal(param);
            return;
        }
        setOpenModal(null);
    };
    const buyNowHandler = (isLoggedIn)=>{
        if (isLoggedIn === false) {
            modalHandler("login");
            return;
        }
        if (isLoggedIn === true) {
            if (minQtyCheck === false) {
                modalHandler("personalizationFonts");
                return;
            }
            router.push(`${constants_paths_constant__WEBPACK_IMPORTED_MODULE_6__/* .paths.CUSTOMIZE_LOGO */ .H.CUSTOMIZE_LOGO}/${product.id}`);
            return;
        }
    };
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_7__/* ._Store.type1 */ .up.type1) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "col-span-1 mt-4 md:mt-10 px-2 md:px-4 sm:px-0 sm:mt-16 lg:mt-0",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex flex-wrap",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-full md:w-2/3",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                    className: "text-3xl font-semibold text-gray-900",
                                    children: product.name
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductSKU__WEBPACK_IMPORTED_MODULE_30__/* ["default"] */ .Z, {
                                    skuID: product.sku
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductPrice__WEBPACK_IMPORTED_MODULE_27__/* ["default"] */ .Z, {
                                    ourCost: product.ourCost,
                                    msrp: product.msrp,
                                    imap: product.imap,
                                    salePrice: product.salePrice
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductRequestConsultation__WEBPACK_IMPORTED_MODULE_29__/* ["default"] */ .Z, {})
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_AvailableColors__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {}),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mt-3",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: "sr-only",
                                children: "Product information"
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_DiscountPricing__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                    showPriceTable: true,
                                    price: {
                                        ourCost: product.ourCost,
                                        msrp: product.msrp,
                                        imap: product.imap,
                                        salePrice: product.salePrice
                                    }
                                }),
                                !product.isDiscontinue && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_AskToLogin__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                    modalHandler: modalHandler
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "m-3",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        type: "button",
                        className: "text-indigo-500 text-sm font-semibold underline",
                        onClick: ()=>modalHandler("availableInventory"),
                        children: "Check Available Inventory"
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "m-3 flex flex-wrap text-gray-900 justify-between items-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductAvailableSizes__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "button",
                                className: "text-indigo-500 text-sm font-semibold underline",
                                onClick: ()=>modalHandler("sizeChart"),
                                children: "Size Chart"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductCompanion__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {
                    link: product.companionProductLink,
                    name: product.companionProductName,
                    id: product.companionProductId,
                    imageUrl: product.companionProductImage
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductStarReviews__WEBPACK_IMPORTED_MODULE_31__/* ["default"] */ .Z, {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductDescription__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {
                    text: product.description,
                    heading: "Description"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                    className: "mt-6",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mt-10",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "button",
                                disabled: product.isDiscontinue,
                                onClick: ()=>{
                                    setOpenModal("startOrder");
                                    setShowLoader(true);
                                },
                                className: "btn btn-xl btn-secondary !flex items-center justify-center w-full uppercase",
                                children: product.isDiscontinue ? "Discontinued" : "START ORDER"
                            })
                        }),
                        product.isDiscontinue && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TopRatedProducts__WEBPACK_IMPORTED_MODULE_33__/* ["default"] */ .Z, {
                            title: "Top Rated Alternatives",
                            suggestedProducts: product.suggestedProducts
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mt-5 text-center",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                onClick: ()=>router.push(constants_paths_constant__WEBPACK_IMPORTED_MODULE_6__/* .paths.REQUEST_CONSULTATION */ .H.REQUEST_CONSULTATION),
                                className: "text-indigo-500 text-lg font-semibold underline",
                                children: "Or request a free consultation with one of our experts"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductFeatures__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .Z, {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                    "aria-labelledby": "details-heading",
                    className: "mt-12",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        id: "details-heading",
                        className: "sr-only",
                        children: "Additional details"
                    })
                }),
                openModal === "sizeChart" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SizeChartModal__WEBPACK_IMPORTED_MODULE_32__/* ["default"] */ .Z, {
                    modalHandler: modalHandler
                }),
                openModal === "availableInventory" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_AvailableInventoryModal__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                    modalHandler: modalHandler
                }),
                openModal === "startOrder" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_modals_StartOrderModal__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    modalHandler: modalHandler,
                    product: product
                }),
                openModal === "login" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_modals_LoginModal__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    modalHandler: modalHandler
                }),
                openModal === "forgot" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_modals_ForgotModal__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                    modalHandler: modalHandler
                })
            ]
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_7__/* ._Store.type3 */ .up.type3) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "col-span-1",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mb-4",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                            className: "text-2xl font-bold mb-4",
                            children: product.name
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductFeatures__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductPrice__WEBPACK_IMPORTED_MODULE_27__/* ["default"] */ .Z, {
                            ourCost: product.ourCost,
                            msrp: product.msrp,
                            imap: product.imap,
                            salePrice: product.salePrice
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductSKU__WEBPACK_IMPORTED_MODULE_30__/* ["default"] */ .Z, {
                            skuID: product.sku
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductMinimumQuantity__WEBPACK_IMPORTED_MODULE_25__/* ["default"] */ .Z, {
                    pricingLabel: "Discount Pricing"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PriceTable__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductColors__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ColorName__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {}),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mb-4 flex items-center justify-end gap-2",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "inline-block",
                            onClick: ()=>modalHandler("sizeChart"),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: "images/size-chart.jpg",
                                alt: ""
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "inline-block btn btn-sm !py-0.5 btn-outline-secondary",
                            onClick: ()=>modalHandler("personalizationFonts"),
                            children: "Personalizations Fonts"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductInventory__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z, {
                    productId: product.id
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mb-4 text-rose-500 text-sm",
                    children: "PLEASE SIGN INTO YOUR ACCOUNT TO VIEW LIVE INVENTORY AND VOLUME DISCOUNTS"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mb-4 bg-[#ececec] py-4 px-2",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_DiscountPrice__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                            ourCost: product.ourCost,
                            msrp: product.msrp,
                            imap: product.imap,
                            salePrice: product.salePrice
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            type: "button",
                            className: "btn btn-lg btn-secondary w-full",
                            onClick: ()=>buyNowHandler(!!userId),
                            children: "LOGIN TO SHOP NOW WITH LIVE INVENTORY"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductNote__WEBPACK_IMPORTED_MODULE_26__/* ["default"] */ .Z, {
                    note: `<strong>PLEASE NOTE:</strong> If you are ordering product that is
        backordered, your entire order will not ship until all items are
        available. Click the number in the Availability column above to see
        future inventory dates. Please reference the ship date shown in your
        cart.`
                }),
                openModal === "sizeChart" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SizeChartModal__WEBPACK_IMPORTED_MODULE_32__/* ["default"] */ .Z, {
                    modalHandler: modalHandler
                }),
                openModal === "personalizationFonts" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PersonalizationFontModal__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                    onCancel: modalHandler
                }),
                openModal === "login" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_modals_LoginModal__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    modalHandler: modalHandler
                }),
                openModal === "forgot" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_modals_ForgotModal__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                    modalHandler: modalHandler
                })
            ]
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_7__/* ._Store.type2 */ .up.type2) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "w-full lg:w-6/12 px-3",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mb-1",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: "text-[22px] font-black text-black",
                        children: product.name
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mb-2",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "font-bold text-sm tracking-widest bg-no-repeat",
                        style: {
                            backgroundImage: "url(images/personalize-icon.png)",
                            paddingLeft: "35px",
                            paddingTop: "3px",
                            paddingBottom: "8px",
                            backgroundSize: "25px"
                        },
                        children: "PERSONALIZE WITH YOUR LOGO"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductFeatures__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .Z, {}),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "text-black mb-5 text-[16px] flex items-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "font-bold w-32",
                            children: "SKU "
                        }),
                        " ",
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            children: `: ${product.sku}`
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductPrice__WEBPACK_IMPORTED_MODULE_27__/* ["default"] */ .Z, {
                    ourCost: product.ourCost,
                    msrp: product.msrp,
                    imap: product.imap,
                    salePrice: product.salePrice
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductMinimumQuantity__WEBPACK_IMPORTED_MODULE_25__/* ["default"] */ .Z, {
                    pricingLabel: ""
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_AvailableColors__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductInventory__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z, {
                    productId: product.id
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mb-3",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        type: "button",
                        className: "btn btn-lg btn-secondary w-full",
                        onClick: ()=>setOpenModal("qouteRequest"),
                        children: "CLICK HERE TO SUBMIT A QUOTE REQUEST"
                    })
                }),
                openModal === "qouteRequest" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductQuoteRequest__WEBPACK_IMPORTED_MODULE_28__/* ["default"] */ .Z, {
                    modalHandler: modalHandler
                })
            ]
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_7__/* ._Store.type4 */ .up.type4) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "col-span-1 mt-4 md:mt-10 sm:mt-16 lg:mt-0",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mb-4 text-2xl border-b border-b-gray-200 pb-2",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: "",
                        children: product.name
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductSKU__WEBPACK_IMPORTED_MODULE_30__/* ["default"] */ .Z, {
                    skuID: product.sku
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductPrice__WEBPACK_IMPORTED_MODULE_27__/* ["default"] */ .Z, {
                    ourCost: product.ourCost,
                    msrp: product.msrp,
                    imap: product.imap,
                    salePrice: product.salePrice
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductMinimumQuantity__WEBPACK_IMPORTED_MODULE_25__/* ["default"] */ .Z, {
                    pricingLabel: ""
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_DiscountPricing__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                    showPriceTable: true,
                    price: {
                        salePrice: product.salePrice,
                        imap: product.imap,
                        msrp: product.msrp,
                        ourCost: product.ourCost
                    }
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductInventory__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z, {
                    productId: product.id
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductCompanion__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {
                    name: product.companionProductName,
                    id: product.companionProductId,
                    imageUrl: product.companionProductImage,
                    link: product.companionProductLink
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "bg-gray-100 p-4 flex flex-wrap items-end justify-between gap-2 text-sm mb-5",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "mb-2",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "inline-block w-40",
                                            children: "Quantity Selected:"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            className: "font-semibold text-base",
                                            children: [
                                                totalQty,
                                                " "
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "inline-block w-40",
                                            children: "Price Per Item:"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "font-semibold text-base",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                value: pricePerItem
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "text-base",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "inline-block",
                                    children: "Subtotal:"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "font-semibold text-xl lg:text-3xl",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                        value: totalPrice
                                    })
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "",
                    children: userId ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_ui_AddToCartButton__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        title: "ADD TO CART",
                        className: "btn btn-lg btn-secondary w-full text-center !font-normal"
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        type: "button",
                        className: "btn btn-lg btn-secondary w-full text-center !font-normal",
                        "data-modal-toggle": "LoginModal",
                        children: "CHECK INVENTORY AND YOUR PRICING"
                    })
                })
            ]
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductInfo);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7767:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_product_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2433);
/* harmony import */ var appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2337);
/* harmony import */ var appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3632);
/* harmony import */ var constants_store_constant__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7297);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6183);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _InventoryInput__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1610);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_product_service__WEBPACK_IMPORTED_MODULE_1__, appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_3__, hooks__WEBPACK_IMPORTED_MODULE_5__, _InventoryInput__WEBPACK_IMPORTED_MODULE_7__]);
([_services_product_service__WEBPACK_IMPORTED_MODULE_1__, appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_3__, hooks__WEBPACK_IMPORTED_MODULE_5__, _InventoryInput__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const Inventory = ({ productId  })=>{
    const { updatePrice  } = (0,hooks__WEBPACK_IMPORTED_MODULE_5__/* .useActions */ .ol)();
    const storeLayout = (0,hooks__WEBPACK_IMPORTED_MODULE_5__/* .useTypedSelector */ .ix)((state)=>state.store.layout);
    const { color  } = (0,hooks__WEBPACK_IMPORTED_MODULE_5__/* .useTypedSelector */ .ix)((state)=>state.product.selected);
    const { totalPrice  } = (0,hooks__WEBPACK_IMPORTED_MODULE_5__/* .useTypedSelector */ .ix)((state)=>state.product.toCheckout);
    const { price , colors  } = (0,hooks__WEBPACK_IMPORTED_MODULE_5__/* .useTypedSelector */ .ix)((state)=>state.product.product);
    const { 0: inventory , 1: setInventory  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        updatePrice({
            price: (price === null || price === void 0 ? void 0 : price.msrp) || 0
        });
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        price === null || price === void 0 ? void 0 : price.msrp
    ]);
    const showInventoryFor = (payload)=>{
        (0,_services_product_service__WEBPACK_IMPORTED_MODULE_1__/* .FetchInventoryById */ .oe)(payload).then((res)=>setInventory(res));
    // .catch((err) => console.log('err', err))
    // .finally(() => );
    };
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        if (colors === null) return;
        showInventoryFor({
            productId: colors[0].productId,
            attributeOptionId: [
                colors[0].attributeOptionId
            ]
        });
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        colors
    ]);
    if (inventory === null) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_4__/* ._Store.type3 */ .up.type3) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "mb-4",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-wrap justify-between bg-gray-300 py-3 font-semibold",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "px-2",
                                children: "Size"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "",
                                children: "Availability"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-20",
                                children: "QTY"
                            })
                        ]
                    }),
                    inventory === null || inventory === void 0 ? void 0 : inventory.sizes.map((product)=>{
                        if (product.colorAttributeOptionId === color.attributeOptionId) {
                            return product.sizeArr.map((size)=>{
                                var ref, ref1;
                                /*#__PURE__*/ return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex flex-wrap items-center justify-between border-b border-b-gray-300 py-2",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "font-semibold px-2",
                                            children: size
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "",
                                            children: ((ref = inventory.inventory.find((int)=>int.colorAttributeOptionId === color.attributeOptionId && int.name === size)) === null || ref === void 0 ? void 0 : ref.inventory) || "Out of Stock"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_InventoryInput__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                            size: size,
                                            qty: ((ref1 = inventory.inventory.find((int)=>int.colorAttributeOptionId === color.attributeOptionId && int.name === size)) === null || ref1 === void 0 ? void 0 : ref1.inventory) || 0,
                                            price: (price === null || price === void 0 ? void 0 : price.msrp) || 0
                                        })
                                    ]
                                }, size);
                            });
                        }
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
                    })
                ]
            })
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_4__/* ._Store.type4 */ .up.type4) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "text-xs bg-gray-100 mb-5",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "hidden md:flex flex-wrap gap-y-5 bg-secondary text-white",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "p-2 w-full md:w-2/12",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "font-semibold",
                                    children: "Color"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex flex-wrap justify-evenly text-center gap-y-5 w-full md:w-10/12",
                                children: inventory === null || inventory === void 0 ? void 0 : inventory.sizes.map((product)=>{
                                    if (product.colorAttributeOptionId === color.attributeOptionId) {
                                        return product.sizeArr.map((size, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "p-2 w-1/2 md:w-1/12",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "font-semibold",
                                                    children: size
                                                })
                                            }, index));
                                    }
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
                                })
                            })
                        ]
                    }),
                    colors === null || colors === void 0 ? void 0 : colors.map((color)=>{
                        /*#__PURE__*/ return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex flex-wrap gap-y-5 border-b last:border-b-0 border-b-gray-300 mb-5 md:mb-0",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "p-2 w-full md:w-2/12 text-center md:text-left",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "md:hidden font-semibold text-center mb-1",
                                            children: "Color:"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "mb-1 text-center w-10 h-10 mx-auto md:m-0 border-gray-300 p-1 bg-white",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                src: color.imageUrl,
                                                alt: color.altTag,
                                                className: "max-h-full inline-block"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "",
                                            children: color.name
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex flex-wrap justify-evenly text-center gap-y-5 w-full md:w-10/12",
                                    children: inventory === null || inventory === void 0 ? void 0 : inventory.sizes.map((product)=>{
                                        if (product.colorAttributeOptionId === color.attributeOptionId) {
                                            return product.sizeArr.map((size, index)=>{
                                                var ref;
                                                const inv = ((ref = inventory.inventory.find((int)=>int.colorAttributeOptionId === color.attributeOptionId && int.name === size)) === null || ref === void 0 ? void 0 : ref.inventory) || 0;
                                                const inventry = inventory.inventory.find((int)=>int.colorAttributeOptionId === color.attributeOptionId && int.name === size);
                                                return inv > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "p-2 w-1/2 md:w-1/12",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "mb-1",
                                                                children: inv > 50 ? "50+" : inv
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_InventoryInput__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                                size: size,
                                                                qty: inv,
                                                                price: (inventry === null || inventry === void 0 ? void 0 : inventry.price) || 5,
                                                                color: color.name,
                                                                isDisabled: inv < 1
                                                            })
                                                        ]
                                                    }, index)
                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "p-2 w-1/2 md:w-1/12",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "border-bottom p-b-10",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                                className: "text-center center",
                                                                children: " - "
                                                            }),
                                                            " "
                                                        ]
                                                    })
                                                });
                                            });
                                        }
                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
                                    })
                                })
                            ]
                        }, color.attributeOptionId);
                    })
                ]
            })
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_4__/* ._Store.type2 */ .up.type2) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mb-4",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "text-left pl-0 block",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex items-center font-bold justify-between border-b border-b-gray-300 py-3 px-4 bg-[#cfd2d3]",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "",
                                        children: "Size"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "",
                                        children: "QTY."
                                    })
                                ]
                            }),
                            inventory === null || inventory === void 0 ? void 0 : inventory.sizes.map((product)=>{
                                if (product.colorAttributeOptionId === color.attributeOptionId) {
                                    return product.sizeArr.map((size, index)=>{
                                        var ref;
                                        /*#__PURE__*/ return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex items-center justify-between border-b border-b-gray-300 py-3 pl-4",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "",
                                                    children: size
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_InventoryInput__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                    size: size,
                                                    qty: ((ref = inventory.inventory.find((int)=>int.colorAttributeOptionId === color.attributeOptionId && int.name === size)) === null || ref === void 0 ? void 0 : ref.inventory) || 0,
                                                    price: (price === null || price === void 0 ? void 0 : price.msrp) || 0
                                                })
                                            ]
                                        }, index);
                                    });
                                }
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mb-3 font-bold bg-[#051C2C] px-4 py-2.5 text-white tracking-widest text-center",
                    children: "Add 12 more of this johnnie-O Men's The Original 4-Button Polo to your cart to save an additional $8.00 per Item!"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "bg-[#d8dfe1] text-sm text-gray-900 flex flex-wrap p-5 items-center gap-2 tracking-wider mb-3",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "",
                            children: "Price Per Item"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-4xl font-bold",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                value: totalPrice
                            })
                        })
                    ]
                })
            ]
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Inventory);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6336:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var constants_store_constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7297);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6183);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_3__]);
hooks__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const MinimumQuantity = ({ pricingLabel  })=>{
    const storeLayout = (0,hooks__WEBPACK_IMPORTED_MODULE_3__/* .useTypedSelector */ .ix)((state)=>state.store.layout);
    const { minQuantity  } = (0,hooks__WEBPACK_IMPORTED_MODULE_3__/* .useTypedSelector */ .ix)((state)=>state.product.selected.color);
    const unitUnits = minQuantity > 1 ? "units" : "unit";
    const { 0: showMsg , 1: setShowMsg  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_2__/* ._Store.type1 */ .up.type1) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "text-sm text-gray-900 bg-primary flex flex-wrap justify-between items-center p-2 md:p-0 md:pl-2 mt-5",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "text-lg font-semibold text-white",
                        children: [
                            pricingLabel,
                            ":"
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                        onClick: ()=>setShowMsg((show)=>!show),
                        className: "text-white py-1 md:px-2 flex flex-wrap text-sm font-semibold uppercase items-center",
                        id: "aMinOrder",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "MINIMUM ORDER :"
                            }),
                            `${minQuantity} ${unitUnits} per color`
                        ]
                    }),
                    showMsg && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "text-xs p-3 pb-0",
                        id: "divMinorder",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                            children: [
                                "We reserve the right to reject orders that do not meet the",
                                " ",
                                minQuantity,
                                "piece minimum per style ",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                " and color, exceptions may apply for men’s and women’s companion styles per color."
                            ]
                        })
                    })
                ]
            })
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_2__/* ._Store.type2 */ .up.type2) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "mb-5 w-full",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                className: "",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                    className: "mb-4 last:mb-0",
                    "x-data": "{ open: false }",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                            className: "w-full flex justify-start items-start text-left font-bold font-heading tracking-wider",
                            // :className="open == true ? '':' rounded-b-lg'"
                            onClick: ()=>setShowMsg((show)=>!show),
                            children: [
                                !showMsg && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "material-icons-outlined",
                                    children: "+"
                                }),
                                showMsg && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "material-icons-outlined",
                                    children: "-"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "text-md text-black",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                            children: "MINIMUM ORDER QUANTITY:"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "font-normal",
                                            children: ` ${minQuantity} ${unitUnits} per color`
                                        })
                                    ]
                                })
                            ]
                        }),
                        showMsg && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "text-defaule-text",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                className: "mb-2 text-black",
                                children: [
                                    "We reserve the right to reject orders that do not meet the",
                                    " ",
                                    minQuantity,
                                    " piece minimum per style and color, exceptions may apply for men’s and women’s companion styles per color."
                                ]
                            })
                        })
                    ]
                })
            })
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_2__/* ._Store.type3 */ .up.type3) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "mb-4 pb-4",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex items-center gap-1",
                    onClick: ()=>setShowMsg((show)=>!show),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "material-icons-outlined text-xl"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "font-bold inline-block",
                            children: "MINIMUM ORDER QUANTITY :"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            children: ` ${minQuantity} ${unitUnits} per color`
                        })
                    ]
                }),
                showMsg && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "text-sm",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                        children: [
                            "We reserve the right to reject orders that do not meet the",
                            " ",
                            minQuantity,
                            "piece minimum per style ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            " and color, exceptions may apply for men’s and women’s companion styles per color."
                        ]
                    })
                })
            ]
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_2__/* ._Store.type4 */ .up.type4) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "text-black mb-2 text-sm flex items-center",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "font-bold w-36",
                    children: "MINIMUM ORDER:"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: ` ${minQuantity} ${unitUnits} per color`
                })
            ]
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MinimumQuantity);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6785:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var constants_store_constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7297);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6183);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_3__]);
hooks__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const ProductNote = ({ note  })=>{
    const storeLayout = (0,hooks__WEBPACK_IMPORTED_MODULE_3__/* .useTypedSelector */ .ix)((state)=>state.store.layout);
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_2__/* ._Store.type3 */ .up.type3) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "",
            dangerouslySetInnerHTML: {
                __html: note
            }
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductNote);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3437:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3632);
/* harmony import */ var constants_store_constant__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7297);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6183);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__, hooks__WEBPACK_IMPORTED_MODULE_4__]);
([appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__, hooks__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const ProductPrice = ({ msrp  })=>{
    const { layout: storeLayout  } = (0,hooks__WEBPACK_IMPORTED_MODULE_4__/* .useTypedSelector */ .ix)((state)=>state.store);
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_3__/* ._Store.type1 */ .up.type1) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "text-gray-700 pt-1 text-sm",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "font-semibold inline-block w-16",
                    children: "MSRP "
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    children: [
                        `: `,
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                            value: msrp
                        })
                    ]
                })
            ]
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_3__/* ._Store.type2 */ .up.type2) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "text-black mb-5 text-[16px] flex items-center",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "font-bold w-32",
                    children: "MSRP "
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    children: [
                        `: `,
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                            value: msrp
                        })
                    ]
                })
            ]
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_3__/* ._Store.type3 */ .up.type3) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "pb-4 flex items-center",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "font-bold inline-block w-24",
                    children: "MSRP "
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        value: msrp
                    })
                })
            ]
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_3__/* ._Store.type4 */ .up.type4) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "text-black mb-2 text-sm flex items-center",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "font-bold w-12",
                    children: "MSRP "
                }),
                " ",
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        value: msrp
                    })
                })
            ]
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductPrice);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7084:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var constants_validationMessages__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4108);
/* harmony import */ var constants_store_constant__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7297);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6183);
/* harmony import */ var _ProductQuoteRequestInput__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5771);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_6__]);
hooks__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








const __QuoteRequestInitials = {
    name: "",
    email: "",
    organization: "",
    sport: "",
    phoneNumber: "",
    additionalInformation: ""
};
const __QuoteRequestSchema = yup__WEBPACK_IMPORTED_MODULE_3__.object().shape({
    name: yup__WEBPACK_IMPORTED_MODULE_3__.string().required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_4__/* .__QuoteRequestMessages.name.required */ .QC.name.required),
    email: yup__WEBPACK_IMPORTED_MODULE_3__.string().required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_4__/* .__QuoteRequestMessages.email.required */ .QC.email.required),
    organization: yup__WEBPACK_IMPORTED_MODULE_3__.string().required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_4__/* .__QuoteRequestMessages.organization.required */ .QC.organization.required),
    sport: yup__WEBPACK_IMPORTED_MODULE_3__.string().required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_4__/* .__QuoteRequestMessages.sport.required */ .QC.sport.required)
});
const ProductQuoteRequest = ({ modalHandler  })=>{
    const storeLayout = (0,hooks__WEBPACK_IMPORTED_MODULE_6__/* .useTypedSelector */ .ix)((state)=>state.store.layout);
    const { name: productName  } = (0,hooks__WEBPACK_IMPORTED_MODULE_6__/* .useTypedSelector */ .ix)((state)=>state.product.product);
    const { color: productColor  } = (0,hooks__WEBPACK_IMPORTED_MODULE_6__/* .useTypedSelector */ .ix)((state)=>state.product.selected);
    const quoteRequestHandler = ()=>{};
    // const show = useTypedSelector((state) => state.store.display.footer);
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_5__/* ._Store.type2 */ .up.type2) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            id: "QuoteRequestModal",
            "aria-hidden": "true",
            className: " overflow-y-auto overflow-x-hidden fixed z-50 justify-center items-center h-modal h-full inset-0",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full h-full bg-black bg-opacity-50 flex items-center justify-center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "relative px-4 w-full max-w-2xl h-fullborder border-neutral-200 inline-block h-auto",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_1__.Formik, {
                        initialValues: __QuoteRequestInitials,
                        onSubmit: quoteRequestHandler,
                        validationSchema: __QuoteRequestSchema,
                        children: ({ values , handleChange  })=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_1__.Form, {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "relative bg-white rounded-lg shadow dark:bg-gray-700 max-h-screen overflow-y-auto",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex justify-between items-center p-5 rounded-t border-b dark:border-gray-600 sticky top-0 left-0 bg-white",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "text-xl font-semibold text-gray-900 lg:text-2xl login-top-title dark:text-white",
                                                    children: "Contact us"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "flex items-center gap-x-2",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        type: "button",
                                                        className: "text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-600 dark:hover:text-white",
                                                        onClick: ()=>modalHandler(null),
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                            className: "w-5 h-5",
                                                            fill: "currentColor",
                                                            viewBox: "0 0 20 20",
                                                            xmlns: "http://www.w3.org/2000/svg",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                fillRule: "evenodd",
                                                                d: "M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z",
                                                                clipRule: "evenodd"
                                                            })
                                                        })
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "p-6",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "flex flex-wrap gap-1 pt-4 first:pt-0 font-semibold",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "",
                                                            children: "Product Name :"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "",
                                                            children: productName
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "flex flex-wrap gap-1 pt-4 first:pt-0 font-semibold",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "",
                                                            children: "Color :"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "",
                                                            children: productColor.name
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductQuoteRequestInput__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                    label: "Name",
                                                    placeHolder: "Name",
                                                    value: values.name,
                                                    name: "name",
                                                    onChange: handleChange,
                                                    type: "text",
                                                    required: true,
                                                    containerClass: "pt-4 first:pt-0"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductQuoteRequestInput__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                    label: "Email",
                                                    placeHolder: "Your Email Address",
                                                    value: values.email,
                                                    name: "email",
                                                    onChange: handleChange,
                                                    type: "text",
                                                    required: true,
                                                    containerClass: "pt-4 first:pt-0"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductQuoteRequestInput__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                    label: "School/Organization",
                                                    placeHolder: "Your School/Organization",
                                                    value: values.organization,
                                                    name: "organization",
                                                    onChange: handleChange,
                                                    type: "text",
                                                    required: true,
                                                    containerClass: "pt-4 first:pt-0"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductQuoteRequestInput__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                    label: "Sport",
                                                    placeHolder: "Your Sport",
                                                    value: values.sport,
                                                    name: "sport",
                                                    onChange: handleChange,
                                                    type: "text",
                                                    required: true,
                                                    containerClass: "pt-4 first:pt-0"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductQuoteRequestInput__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                    label: "Phone Number",
                                                    placeHolder: "Your Phone",
                                                    value: values.phoneNumber,
                                                    name: "phoneNumber",
                                                    onChange: handleChange,
                                                    type: "number",
                                                    required: false,
                                                    containerClass: "pt-4 first:pt-0"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductQuoteRequestInput__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                    label: "Additional Information",
                                                    placeHolder: "Enter Additional Information",
                                                    value: values.additionalInformation,
                                                    name: "additionalInformation",
                                                    onChange: handleChange,
                                                    type: "textArea",
                                                    required: false,
                                                    containerClass: "pt-4 first:pt-0"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex items-center justify-end p-6 space-x-2 rounded-b border-t border-gray-200 dark:border-gray-600",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    type: "button",
                                                    className: "btn btn-primary",
                                                    onClick: ()=>modalHandler(null),
                                                    children: "Cancel"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    type: "submit",
                                                    className: "btn btn-secondary",
                                                    children: "Send"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            });
                        }
                    })
                })
            })
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductQuoteRequest);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5771:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const ProductQuoteRequestInput = ({ label , name , placeHolder , value , onChange , type , required , containerClass ,  })=>{
    if (type === "number" || type === "text") {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: containerClass,
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                    htmlFor: "",
                    className: "block text-base font-medium text-gray-700",
                    children: [
                        label,
                        " ",
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-rose-500",
                            children: `${required ? `*` : ""}`
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mt-1",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        type: type,
                        id: name,
                        name: name,
                        placeholder: placeHolder,
                        value: value,
                        onChange: onChange,
                        className: "form-input"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_1__.ErrorMessage, {
                    name: name,
                    className: "text-rose-500",
                    component: "p"
                })
            ]
        });
    }
    if (type === "textArea") {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "pt-4 first:pt-0",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                    htmlFor: "",
                    className: "block text-base font-medium text-gray-700",
                    children: label
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mt-1",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                        className: "form-input",
                        rows: 3,
                        id: name,
                        name: name,
                        placeholder: placeHolder,
                        value: value,
                        onChange: onChange
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_1__.ErrorMessage, {
                    name: name,
                    className: "text-rose-500",
                    component: "p"
                })
            ]
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductQuoteRequestInput);


/***/ }),

/***/ 6910:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var constants_paths_constant__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3125);
/* harmony import */ var constants_store_constant__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7297);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6183);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_5__]);
hooks__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const ProductRequestConsultation = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const storeLayout = (0,hooks__WEBPACK_IMPORTED_MODULE_5__/* .useTypedSelector */ .ix)((state)=>state.store.layout);
    const { productId , color  } = (0,hooks__WEBPACK_IMPORTED_MODULE_5__/* .useTypedSelector */ .ix)((state)=>state.product.selected);
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_4__/* ._Store.type1 */ .up.type1) {
        const params = {
            productId: productId,
            color: color.name
        };
        const consultationURL = `${constants_paths_constant__WEBPACK_IMPORTED_MODULE_3__/* .paths.REQUEST_CONSULTATION */ .H.REQUEST_CONSULTATION}?productid=${params.productId}&title=Request%20Consultation%20%26%20Proof&Color=${params.color}`;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "w-full md:w-1/3 mt-2 md:text-right text-sm font-semibold text-indigo-500",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    onClick: ()=>router.push(consultationURL),
                    className: "text-indigo-500 underline",
                    children: "Request Consultation and Proof"
                }),
                ">"
            ]
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductRequestConsultation);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2675:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var appComponents_modals_ForgotModal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5402);
/* harmony import */ var appComponents_modals_LoginModal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(365);
/* harmony import */ var constants_store_constant__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7297);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6183);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _constants_paths_constant__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3125);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([appComponents_modals_ForgotModal__WEBPACK_IMPORTED_MODULE_2__, appComponents_modals_LoginModal__WEBPACK_IMPORTED_MODULE_3__, hooks__WEBPACK_IMPORTED_MODULE_5__]);
([appComponents_modals_ForgotModal__WEBPACK_IMPORTED_MODULE_2__, appComponents_modals_LoginModal__WEBPACK_IMPORTED_MODULE_3__, hooks__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const ProductReviews = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    const { 0: openModal , 1: setOpenModal  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const storeLayout = (0,hooks__WEBPACK_IMPORTED_MODULE_5__/* .useTypedSelector */ .ix)((state)=>state.store.layout);
    const { id: userId  } = (0,hooks__WEBPACK_IMPORTED_MODULE_5__/* .useTypedSelector */ .ix)((state)=>state.user);
    const { id: productId  } = (0,hooks__WEBPACK_IMPORTED_MODULE_5__/* .useTypedSelector */ .ix)((state)=>state.product.product);
    const modalHandler = (param)=>{
        if (param) {
            setOpenModal(param);
            return;
        }
        setOpenModal(null);
    };
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_4__/* ._Store.type4 */ .up.type4) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "container mx-auto pt-10",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full text-center text-xl md:text-2xl lg:text-sub-title font-sub-title mb-4",
                        children: "REVIEW"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "text-default-text font-default-text text-center",
                        children: "NO REVIEWS ARE AVAILABLE FOR THIS PRODUCT."
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mt-5 p-6 bg-[#f5f5f6]",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-small-title font-small-title text-center mb-5",
                                children: "WE WANT TO HEAR FROM YOU"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-default-text font-default-text text-center mb-6",
                                children: "Tell us what you think about this item. It helps us get better at what we do, and ultimately provide you with better products"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-default-text font-default-text text-center",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    type: "submit",
                                    className: "btn btn-lg btn-secondary uppercase",
                                    children: "Write A Review"
                                })
                            })
                        ]
                    })
                ]
            })
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_4__/* ._Store.type1 */ .up.type1) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
            className: "mainsection mt-10 mb-20",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "container mx-auto",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-full text-center text-2xl md:text-3xl lg:text-title font-title mb-4",
                            children: "REVIEW"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "text-default-text font-default-text text-center",
                            children: "NO REVIEWS ARE AVAILABLE FOR THIS PRODUCT."
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mt-5 p-6 bg-[#f5f5f6]",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "text-lg md:text-xl lg:text-small-title font-small-title text-center mb-5",
                                    children: "WE WANT TO HEAR FROM YOU"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "text-default-text font-default-text text-center mb-6",
                                    children: "Tell us what you think about this item. It helps us get better at what we do, and ultimately provide you with better products"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "text-default-text font-default-text text-center",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        type: "submit",
                                        className: "btn btn-lg btn-secondary uppercase",
                                        onClick: ()=>{
                                            if (userId) {
                                                router.push(`${_constants_paths_constant__WEBPACK_IMPORTED_MODULE_7__/* .paths.WRITE_A_REVIEW */ .H.WRITE_A_REVIEW}??ProductId=${productId}`);
                                                return;
                                            }
                                            modalHandler("login");
                                        },
                                        children: "Write A Review"
                                    })
                                })
                            ]
                        })
                    ]
                }),
                openModal === "login" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_modals_LoginModal__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    modalHandler: modalHandler
                }),
                openModal === "forgot" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_modals_ForgotModal__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    modalHandler: modalHandler
                })
            ]
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductReviews);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9581:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const ProductStarReviews = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "mt-3 hidden",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                className: "sr-only",
                children: "Reviews"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex items-center",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                className: "h-5 w-5 flex-shrink-0 text-indigo-500",
                                xmlns: "http://www.w3.org/2000/svg",
                                viewBox: "0 0 20 20",
                                fill: "currentColor",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                    d: "M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                className: "h-5 w-5 flex-shrink-0 text-indigo-500",
                                xmlns: "http://www.w3.org/2000/svg",
                                viewBox: "0 0 20 20",
                                fill: "currentColor",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                    d: "M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                className: "h-5 w-5 flex-shrink-0 text-indigo-500",
                                xmlns: "http://www.w3.org/2000/svg",
                                viewBox: "0 0 20 20",
                                fill: "currentColor",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                    d: "M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                className: "h-5 w-5 flex-shrink-0 text-indigo-500",
                                xmlns: "http://www.w3.org/2000/svg",
                                viewBox: "0 0 20 20",
                                fill: "currentColor",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                    d: "M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                className: "h-5 w-5 flex-shrink-0 text-gray-300",
                                xmlns: "http://www.w3.org/2000/svg",
                                viewBox: "0 0 20 20",
                                fill: "currentColor",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                    d: "M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "sr-only",
                        children: "4 out of 5 stars"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductStarReviews);


/***/ }),

/***/ 785:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var constants_store_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7297);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6183);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_2__]);
hooks__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const SizeChart = ({ modalHandler , modal  })=>{
    const storeLayout = (0,hooks__WEBPACK_IMPORTED_MODULE_2__/* .useTypedSelector */ .ix)((state)=>state.store.layout);
    const sizeChart = (0,hooks__WEBPACK_IMPORTED_MODULE_2__/* .useTypedSelector */ .ix)((state)=>state.product.product.sizeChart);
    if (modal === "NO" && storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_1__/* ._Store.type3 */ .up.type3) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "mainsection pt-10",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "container mx-auto",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full text-center text-2xl md:text-3xl lg:text-title font-title mb-4",
                        children: sizeChart === null || sizeChart === void 0 ? void 0 : sizeChart.name
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "FIND YOUR SIZE"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "overflow-x-auto max-h-screen bg-gray-100 p-5",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                    cellPadding: 0,
                                    cellSpacing: 0,
                                    className: "table-auto w-full text-sm text-center border border-neutral-200",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                            className: "text-sm bg-gray-100 font-semibold uppercase border-b border-neutral-200",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                className: "divide-x divide-slate-200",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                        className: "px-2 py-4",
                                                        children: "\xa0"
                                                    }),
                                                    sizeChart === null || sizeChart === void 0 ? void 0 : sizeChart.measurements.map((length, index)=>{
                                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            className: "px-2 py-4",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "",
                                                                children: length
                                                            })
                                                        }, index);
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                            className: "divide-y divide-slate-200",
                                            children: sizeChart === null || sizeChart === void 0 ? void 0 : sizeChart.sizeChartRange.map((range, index)=>{
                                                /*#__PURE__*/ return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                    className: "divide-x divide-slate-200",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: "px-2 py-3 text-left",
                                                            children: range
                                                        }),
                                                        sizeChart === null || sizeChart === void 0 ? void 0 : sizeChart.measurements.map((length, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                className: "px-2 py-3",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "",
                                                                    children: sizeChart.sizeChartView[`${length}${range}`]
                                                                })
                                                            }, index))
                                                    ]
                                                }, index);
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            })
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_1__/* ._Store.type3 */ .up.type3) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            id: "sizechartModal",
            className: "overflow-y-auto overflow-x-hidden fixed z-50 justify-center items-center h-modal h-full inset-0",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full h-full bg-black bg-opacity-50 flex items-center justify-center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "relative px-4 w-full max-w-3xl h-full md:h-auto",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "relative bg-white rounded-lg shadow max-h-screen overflow-y-auto",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex justify-between items-start p-5 rounded-t border-b sticky top-0 left-0 bg-white",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "text-xl font-semibold text-gray-900 lg:text-2xl",
                                        children: sizeChart === null || sizeChart === void 0 ? void 0 : sizeChart.name
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        type: "button",
                                        className: "text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center",
                                        onClick: ()=>modalHandler(null),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                            className: "w-5 h-5",
                                            fill: "currentColor",
                                            viewBox: "0 0 20 20",
                                            xmlns: "http://www.w3.org/2000/svg",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                fillRule: "evenodd",
                                                d: "M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z",
                                                clipRule: "evenodd"
                                            })
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "overflow-x-auto max-h-screen",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                        cellPadding: "0",
                                        cellSpacing: "0",
                                        className: "table-auto w-full text-sm text-center text-[#191919]",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                className: "text-sm bg-gray-100 font-semibold uppercase border-b border-neutral-200",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                    className: "divide-x divide-slate-200",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            className: "px-2 py-4",
                                                            children: "\xa0"
                                                        }),
                                                        sizeChart === null || sizeChart === void 0 ? void 0 : sizeChart.measurements.map((length, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                className: "px-2 py-4",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "",
                                                                    children: length
                                                                })
                                                            }, index))
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                className: "divide-y divide-slate-200",
                                                children: sizeChart === null || sizeChart === void 0 ? void 0 : sizeChart.sizeChartRange.map((range, index)=>{
                                                    /*#__PURE__*/ return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                        className: "divide-x divide-slate-200",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                className: "px-2 py-3 text-left",
                                                                children: range
                                                            }),
                                                            sizeChart === null || sizeChart === void 0 ? void 0 : sizeChart.measurements.map((length, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                    className: "px-2 py-3",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "",
                                                                        children: sizeChart.sizeChartView[`${length}${range}`]
                                                                    })
                                                                }, index))
                                                        ]
                                                    }, index);
                                                })
                                            })
                                        ]
                                    })
                                })
                            })
                        ]
                    })
                })
            })
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_1__/* ._Store.type2 */ .up.type2) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            id: "FitSizeModal",
            "aria-hidden": "true",
            className: " overflow-y-auto overflow-x-hidden fixed z-50 justify-center items-center h-modal h-full inset-0",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full h-full bg-black bg-opacity-50 flex items-center justify-center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "relative px-4 w-full max-w-2xl h-fullborder border-neutral-200 inline-block h-auto",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "relative bg-white rounded-lg shadow dark:bg-gray-700 max-h-screen overflow-y-auto",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex justify-between items-center p-5 rounded-t border-b dark:border-gray-600 sticky top-0 left-0 bg-white",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "text-xl font-semibold text-gray-900 lg:text-2xl login-top-title dark:text-white",
                                        children: sizeChart === null || sizeChart === void 0 ? void 0 : sizeChart.name
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "flex items-center gap-x-2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            type: "button",
                                            className: "text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-600 dark:hover:text-white",
                                            onClick: ()=>modalHandler(null),
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                className: "w-5 h-5",
                                                fill: "currentColor",
                                                viewBox: "0 0 20 20",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                    fillRule: "evenodd",
                                                    d: "M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z",
                                                    clipRule: "evenodd"
                                                })
                                            })
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "p-6",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "table-responsive",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("table", {
                                        className: "table border border-gray-300 w-full",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tbody", {
                                            className: "divide-y divide-gray-300",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                    className: "divide-x divide-gray-300 bg-gray-100",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                            className: "p-2",
                                                            children: "SIZE"
                                                        }),
                                                        sizeChart === null || sizeChart === void 0 ? void 0 : sizeChart.measurements.map((length, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                className: "p-2",
                                                                children: length
                                                            }, index))
                                                    ]
                                                }),
                                                sizeChart === null || sizeChart === void 0 ? void 0 : sizeChart.sizeChartRange.map((range, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                        className: "divide-x divide-gray-300",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                className: "p-2",
                                                                children: range
                                                            }),
                                                            sizeChart.measurements.map((length, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                    className: "p-2",
                                                                    children: sizeChart.sizeChartView[`${length}${range}`]
                                                                }, index))
                                                        ]
                                                    }, index))
                                            ]
                                        })
                                    })
                                })
                            })
                        ]
                    })
                })
            })
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_1__/* ._Store.type1 */ .up.type1) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            onClick: ()=>modalHandler(null),
            id: "sizechartModal",
            className: "overflow-y-auto overflow-x-hidden fixed right-0 left-0 top-4 z-50 justify-center items-center h-modal md:h-full md:inset-0",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full h-full bg-black bg-opacity-50 flex items-center justify-center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "relative px-4 w-full max-w-3xl h-full md:h-auto",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "relative bg-white rounded-lg shadow max-h-screen overflow-y-auto",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex justify-between items-start p-5 rounded-t border-b sticky top-0 left-0 bg-white",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "text-xl font-semibold text-gray-900 lg:text-2xl",
                                        children: sizeChart === null || sizeChart === void 0 ? void 0 : sizeChart.name
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        type: "button",
                                        className: "text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center",
                                        onClick: ()=>modalHandler(null),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                            className: "w-5 h-5",
                                            fill: "currentColor",
                                            viewBox: "0 0 20 20",
                                            xmlns: "http://www.w3.org/2000/svg",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                fillRule: "evenodd",
                                                d: "M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z",
                                                clipRule: "evenodd"
                                            })
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "overflow-x-auto max-h-screen",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                        cellPadding: "0",
                                        cellSpacing: "0",
                                        className: "table-auto w-full text-sm text-center text-[#191919]",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                                className: "text-sm bg-gray-100 font-semibold uppercase border-b border-neutral-200",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                    className: "divide-x divide-slate-200",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                            className: "px-2 py-4",
                                                            children: "\xa0"
                                                        }),
                                                        sizeChart === null || sizeChart === void 0 ? void 0 : sizeChart.measurements.map((size)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                                className: "px-2 py-4",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "",
                                                                    children: size
                                                                })
                                                            }, size))
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                                className: "divide-y divide-slate-200",
                                                children: sizeChart === null || sizeChart === void 0 ? void 0 : sizeChart.sizeChartRange.map((piece)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                        className: "divide-x divide-slate-200",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                className: "px-2 py-3 text-left",
                                                                children: piece
                                                            }),
                                                            sizeChart.measurements.map((length, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                                    className: "px-2 py-3",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "",
                                                                        children: sizeChart.sizeChartView[`${length}${piece}`]
                                                                    })
                                                                }, length))
                                                        ]
                                                    }, piece))
                                            })
                                        ]
                                    })
                                })
                            })
                        ]
                    })
                })
            })
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SizeChart);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5037:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2337);
/* harmony import */ var appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3632);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__]);
appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const TopRatedProducts = ({ title , suggestedProducts  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: "mainsection mt-10",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "container mx-auto",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-full text-center text-2xl md:text-3xl lg:text-title font-title text-color-title text-color-title mb-4",
                    children: title
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "relative flex justify-center max-w-full max-h-[50px]",
                    id: "slider",
                    children: suggestedProducts.map((product)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "slide-item",
                            onClick: ()=>"handle click",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "px-2",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex text-center lg:w-auto mb-6",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "relative pb-4",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "w-full bg-gray-200 rounded-md overflow-hidden aspect-w-1 aspect-h-1",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                    href: `/${product.seName}`,
                                                    className: "relative",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                        src: product.image,
                                                        alt: product.name,
                                                        className: "w-auto h-auto max-h-max"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "mt-6",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "mt-1 text-anchor hover:text-anchor-hover",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                            href: `/${product.seName}`,
                                                            className: "relative underline",
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                        className: "absolute inset-0"
                                                                    }),
                                                                    product.name
                                                                ]
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "mt-3 text-black text-base tracking-wider",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                            className: "font-semibold",
                                                            children: [
                                                                "MSRP ",
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                    value: product.msrp
                                                                })
                                                            ]
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            })
                        }, product.sku);
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TopRatedProducts);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2396:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var Components_ProductDetails_ProductDescription__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(705);
/* harmony import */ var Components_ProductDetails_ProductDetails__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(971);
/* harmony import */ var Components_ProductDetails_ProductFeatures__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3490);
/* harmony import */ var Components_ProductDetails_SizeChartModal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(785);
/* harmony import */ var constants_store_constant__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7297);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6183);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var helpers_global_console__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3650);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var show_config__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2118);
/* harmony import */ var _ProductAlike__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(655);
/* harmony import */ var _ProductReviews__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2675);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([Components_ProductDetails_ProductDescription__WEBPACK_IMPORTED_MODULE_1__, Components_ProductDetails_ProductDetails__WEBPACK_IMPORTED_MODULE_2__, Components_ProductDetails_ProductFeatures__WEBPACK_IMPORTED_MODULE_3__, Components_ProductDetails_SizeChartModal__WEBPACK_IMPORTED_MODULE_4__, hooks__WEBPACK_IMPORTED_MODULE_6__, helpers_global_console__WEBPACK_IMPORTED_MODULE_9__, _ProductAlike__WEBPACK_IMPORTED_MODULE_12__, _ProductReviews__WEBPACK_IMPORTED_MODULE_13__]);
([Components_ProductDetails_ProductDescription__WEBPACK_IMPORTED_MODULE_1__, Components_ProductDetails_ProductDetails__WEBPACK_IMPORTED_MODULE_2__, Components_ProductDetails_ProductFeatures__WEBPACK_IMPORTED_MODULE_3__, Components_ProductDetails_SizeChartModal__WEBPACK_IMPORTED_MODULE_4__, hooks__WEBPACK_IMPORTED_MODULE_6__, helpers_global_console__WEBPACK_IMPORTED_MODULE_9__, _ProductAlike__WEBPACK_IMPORTED_MODULE_12__, _ProductReviews__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














const Product = ({ product  })=>{
    var ref, ref1, ref2;
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_10__.useRouter)();
    const storeLayout = (0,hooks__WEBPACK_IMPORTED_MODULE_6__/* .useTypedSelector */ .ix)((state)=>state.store.layout);
    const { store_productDetails , setColor , setShowLoader  } = (0,hooks__WEBPACK_IMPORTED_MODULE_6__/* .useActions */ .ol)();
    const addParams = ()=>{
        router.query.altview = "1";
        router.query.v = "product-detail";
        router.push(router);
    };
    const addHtml = ()=>{
    // console.log(router.pathname);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(()=>{
        if (!window.location.pathname.includes(".html")) {
            addHtml();
        } else if (router.query.altview === undefined || router.query.v === undefined) {
            addParams();
        }
        if (product === null || product === void 0 ? void 0 : product.doNotExist) {
            router.push(product.doNotExist.retrunUrlOrCategorySename || "/");
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(()=>{
        if (product) {
            if (product.doNotExist === null) {
                var ref;
                store_productDetails({
                    brand: {
                        id: product.details.brandID,
                        name: product.details.brandName,
                        url: product.details.brandImage
                    },
                    product: {
                        id: product.details.id || null,
                        name: product.details.name || null,
                        discounts: product.discount || null,
                        sizes: ((ref = product.details) === null || ref === void 0 ? void 0 : ref.sizes) || "",
                        sizeChart: product.sizes || null,
                        colors: product.colors || null,
                        price: {
                            msrp: product.details.msrp,
                            ourCost: product.details.ourCost,
                            salePrice: product.details.salePrice
                        } || null,
                        inventory: product.inventory
                    }
                });
                if (product.colors) {
                    setColor(product.colors[0]);
                }
            }
        }
        setShowLoader(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    if (product === null) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: "Product Page Loading... "
    });
    (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_9__/* .conditionalLog */ .wH)({
        show: show_config__WEBPACK_IMPORTED_MODULE_11__/* ._showConsoles.productDetails */ .YH.productDetails,
        name: show_config__WEBPACK_IMPORTED_MODULE_11__/* .__fileNames.productDetails */ .eg.productDetails,
        type: "PAGE",
        data: product
    });
    if (product.doNotExist) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
    }
    if ((product === null || product === void 0 ? void 0 : product.details) === null || (product === null || product === void 0 ? void 0 : product.details) === undefined) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: " Product Details not found "
        });
    }
    const HeadTag = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_7___default()), {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                children: ((ref = product.SEO) === null || ref === void 0 ? void 0 : ref.pageTitle) || product.details.name
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "description",
                content: ((ref1 = product.SEO) === null || ref1 === void 0 ? void 0 : ref1.metaDescription) || product.details.description
            }, "desc"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "keywords",
                content: ((ref2 = product.SEO) === null || ref2 === void 0 ? void 0 : ref2.metaKeywords) || product.details.name
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                rel: "stylesheet",
                type: "text/css",
                charSet: "UTF-8",
                href: "https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.min.css"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                rel: "stylesheet",
                type: "text/css",
                href: "https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick-theme.min.css"
            })
        ]
    });
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_5__/* ._Store.type1 */ .up.type1) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                HeadTag,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: `font-Outfit`,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_ProductDetails_ProductDetails__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                            product: product.details
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductAlike__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                            title: "YOU MAY ALSO LIKE",
                            products: product.alike
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductReviews__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                            reviews: null
                        })
                    ]
                })
            ]
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_5__/* ._Store.type2 */ .up.type2) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                HeadTag,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: `font-Outfit tracking-wider`,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_ProductDetails_ProductDetails__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                            product: product.details
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_ProductDetails_ProductFeatures__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            fewFeatures: true
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_ProductDetails_ProductDescription__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                            heading: "DESCRIPTION",
                            text: product.details.description
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductReviews__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                            reviews: null
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductAlike__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                            title: "YOU MAY ALSO LIKE",
                            products: product.alike
                        })
                    ]
                })
            ]
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_5__/* ._Store.type3 */ .up.type3) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                HeadTag,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: `font-Outfit`,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_ProductDetails_ProductDetails__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                            product: product.details
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_ProductDetails_ProductDescription__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                            heading: "Description",
                            text: product.details.description
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_ProductDetails_SizeChartModal__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                            modalHandler: ()=>"Do nothing",
                            modal: "NO"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductAlike__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                            title: "YOU MAY ALSO LIKE",
                            products: product.alike
                        })
                    ]
                })
            ]
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_5__/* ._Store.type4 */ .up.type4) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                HeadTag,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: `font-Outfit tracking-wider`,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_ProductDetails_ProductDetails__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                            product: product.details
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_ProductDetails_ProductDescription__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                            heading: "Description",
                            text: product.details.description
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductAlike__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                            title: "YOU MAY ALSO LIKE",
                            products: product.alike
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductReviews__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                            reviews: null
                        })
                    ]
                })
            ]
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Product);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4915:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export AddToCart */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_cart_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7591);
/* harmony import */ var helpers_getLocation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8443);
/* harmony import */ var helpers_global_console__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3650);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6183);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_cart_service__WEBPACK_IMPORTED_MODULE_1__, helpers_getLocation__WEBPACK_IMPORTED_MODULE_2__, helpers_global_console__WEBPACK_IMPORTED_MODULE_3__, hooks__WEBPACK_IMPORTED_MODULE_4__]);
([_services_cart_service__WEBPACK_IMPORTED_MODULE_1__, helpers_getLocation__WEBPACK_IMPORTED_MODULE_2__, helpers_global_console__WEBPACK_IMPORTED_MODULE_3__, hooks__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const AddToCart = ({ title , className  })=>{
    const { showModal  } = (0,hooks__WEBPACK_IMPORTED_MODULE_4__/* .useActions */ .ol)();
    const toCheckout = (0,hooks__WEBPACK_IMPORTED_MODULE_4__/* .useTypedSelector */ .ix)((state)=>state.product.toCheckout);
    const customerId = (0,hooks__WEBPACK_IMPORTED_MODULE_4__/* .useTypedSelector */ .ix)((state)=>state.user.customer.id);
    const selectedProduct = (0,hooks__WEBPACK_IMPORTED_MODULE_4__/* .useTypedSelector */ .ix)((state)=>state.product.selected);
    const addToCartHandler = async ()=>{
        var ref;
        const location = await (0,helpers_getLocation__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
        const tempCustId = localStorage.getItem("tempCustomerId");
        const cartLogoPersonModel = [];
        (ref = toCheckout.sizeQtys) === null || ref === void 0 ? void 0 : ref.map((res)=>cartLogoPersonModel.push({
                attributeOptionId: 0,
                attributeOptionValue: res.size,
                code: "",
                price: res.price,
                quantity: res.qty,
                logoPrice: 0,
                logoQty: 0,
                logoFile: "string",
                estimateDate: new Date("2022-11-03T05:09:52.659Z"),
                isEmployeeLoginPrice: 0,
                cartLogoPersonDetailModels: [
                    {
                        location: `${location.city}, ${location.state}, ${location.country_name}, ${location.postal}`,
                        logoTotal: 0,
                        colorImagePath: "string",
                        logoUniqueId: "string",
                        price: 0,
                        logoColors: "string",
                        logoNotes: "string",
                        logoDate: new Date("2022-11-03T05:09:52.659Z"),
                        logoNames: "string",
                        digitalPrice: 0,
                        logoPositionImagePath: "string",
                        oldFilePath: "string",
                        originalLogoFilePath: "string"
                    }, 
                ]
            }));
        const cartObject = {
            addToCartModel: {
                customerId: customerId || (tempCustId ? ~~tempCustId : 0),
                productId: selectedProduct.productId,
                storeId: 4,
                shoppingCartItemModel: {
                    id: 0,
                    price: toCheckout.totalPrice,
                    quantity: toCheckout.totalQty,
                    weight: 0,
                    productType: 0,
                    discountPrice: 0,
                    logoTitle: selectedProduct.color.altTag,
                    logogImagePath: selectedProduct.color.imageUrl,
                    perQuantity: 0,
                    appQuantity: 0,
                    status: 2,
                    discountPercentage: 0,
                    productCustomizationId: 0,
                    itemNotes: "",
                    isEmployeeLoginPrice: 0
                },
                shoppingCartItemsDetailModels: [
                    {
                        attributeOptionName: "Color",
                        attributeOptionValue: selectedProduct.color.name,
                        attributeOptionId: selectedProduct.color.attributeOptionId
                    }, 
                ],
                cartLogoPersonModel: cartLogoPersonModel
            }
        };
        if (cartObject) {
            try {
                const res = await (0,_services_cart_service__WEBPACK_IMPORTED_MODULE_1__/* .addToCart */ .Xq)(cartObject);
                if (!customerId) {
                    localStorage.setItem("tempCustomerId", res);
                }
                showModal({
                    message: "Added to cart Successfully",
                    type: "Success"
                });
            } catch (error) {
                (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_3__/* .highLightError */ .Eg)({
                    error,
                    component: "StartOrderModal"
                });
            }
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
        type: "button",
        className: className,
        "data-modal-toggle": "addToCart",
        onClick: addToCartHandler,
        children: title
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AddToCart);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8981:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants_store_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7297);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6183);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _layouts_layout1__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1658);
/* harmony import */ var _layouts_layout2__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7607);
/* harmony import */ var _layouts_layout3__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5207);
/* harmony import */ var _ProductListController__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7828);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_2__, _layouts_layout1__WEBPACK_IMPORTED_MODULE_4__, _layouts_layout2__WEBPACK_IMPORTED_MODULE_5__, _layouts_layout3__WEBPACK_IMPORTED_MODULE_6__, _ProductListController__WEBPACK_IMPORTED_MODULE_7__]);
([hooks__WEBPACK_IMPORTED_MODULE_2__, _layouts_layout1__WEBPACK_IMPORTED_MODULE_4__, _layouts_layout2__WEBPACK_IMPORTED_MODULE_5__, _layouts_layout3__WEBPACK_IMPORTED_MODULE_6__, _ProductListController__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const ProductList = ({ pageData , slug  })=>{
    const { checkedFilters  } = pageData;
    const { filters , product , totalCount , productView , showFilter , showSortMenu , skuList , compareCheckBoxHandler , handleChange , colorChangeHandler , loadMore , sortProductJson , setShowSortMenu , setProductView , setShowFilter , clearFilters ,  } = (0,_ProductListController__WEBPACK_IMPORTED_MODULE_7__["default"])(pageData, slug, checkedFilters || [], pageData.brandId);
    const storeLayout = (0,hooks__WEBPACK_IMPORTED_MODULE_2__/* .useTypedSelector */ .ix)((state)=>state.store.layout);
    let Layout = react__WEBPACK_IMPORTED_MODULE_3__.Fragment;
    if (storeLayout === _constants_store_constant__WEBPACK_IMPORTED_MODULE_1__/* ._Store.type1 */ .up.type1) {
        Layout = _layouts_layout1__WEBPACK_IMPORTED_MODULE_4__["default"];
    } else if (storeLayout === _constants_store_constant__WEBPACK_IMPORTED_MODULE_1__/* ._Store.type2 */ .up.type2) {
        Layout = _layouts_layout2__WEBPACK_IMPORTED_MODULE_5__["default"];
    } else if (storeLayout === _constants_store_constant__WEBPACK_IMPORTED_MODULE_1__/* ._Store.type3 */ .up.type3) {
        Layout = _layouts_layout3__WEBPACK_IMPORTED_MODULE_6__["default"];
    } else if (storeLayout === _constants_store_constant__WEBPACK_IMPORTED_MODULE_1__/* ._Store.type4 */ .up.type4) {
        Layout = _layouts_layout1__WEBPACK_IMPORTED_MODULE_4__["default"];
    }
    if (totalCount > 0) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Layout, {
            showSortMenu: showSortMenu,
            filters: filters,
            products: product,
            checkedFilters: checkedFilters,
            totalCount: totalCount,
            productView: productView,
            showFilter: showFilter,
            skuList: skuList,
            colorChangeHandler: colorChangeHandler,
            handleChange: handleChange,
            loadMore: loadMore,
            sortProductJson: sortProductJson,
            setShowSortMenu: setShowSortMenu,
            setProductView: setProductView,
            setShowFilter: setShowFilter,
            clearFilters: clearFilters,
            compareCheckBoxHandler: compareCheckBoxHandler
        });
    } else {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
            style: {
                padding: "150px"
            },
            className: "text-center",
            children: [
                " ",
                "No Product Found"
            ]
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductList);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9120:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Search),
/* harmony export */   "getServerSideProps": () => (/* reexport safe */ _Components_Slug_getServerSideProps__WEBPACK_IMPORTED_MODULE_5__.N)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var appComponents_Screen_Layout_Head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7027);
/* harmony import */ var Components_ProductDetails__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2396);
/* harmony import */ var pages_Home__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5140);
/* harmony import */ var pages_ProductList__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8981);
/* harmony import */ var _Components_Slug_getServerSideProps__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9510);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([Components_ProductDetails__WEBPACK_IMPORTED_MODULE_2__, pages_Home__WEBPACK_IMPORTED_MODULE_3__, pages_ProductList__WEBPACK_IMPORTED_MODULE_4__, _Components_Slug_getServerSideProps__WEBPACK_IMPORTED_MODULE_5__]);
([Components_ProductDetails__WEBPACK_IMPORTED_MODULE_2__, pages_Home__WEBPACK_IMPORTED_MODULE_3__, pages_ProductList__WEBPACK_IMPORTED_MODULE_4__, _Components_Slug_getServerSideProps__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






function Search(props) {
    const { pageType , pageData , slug  } = props;
    let page = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: "Loading ..."
    });
    const tprops = {
        //
        pageData: pageData,
        pageType: pageType,
        slug: slug
    };
    if (pageType && pageData && slug) {
        if (pageType === "collection") {
            page = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: "Collection"
            });
        } else if (pageType === "product") {
            page = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_ProductDetails__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                product: pageData
            });
        } else if (pageType === "topic") {
            page = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_Screen_Layout_Head__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        title: pageData === null || pageData === void 0 ? void 0 : pageData.seTitle,
                        description: pageData === null || pageData === void 0 ? void 0 : pageData.seDescription,
                        keywords: pageData === null || pageData === void 0 ? void 0 : pageData.seKeyWords
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(pages_Home__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        props: tprops
                    })
                ]
            });
        } else if ("brand,category".includes(pageType)) {
            const { seo  } = pageData;
            page = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_Screen_Layout_Head__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        title: seo === null || seo === void 0 ? void 0 : seo.seTitle,
                        description: seo === null || seo === void 0 ? void 0 : seo.seDescription,
                        keywords: seo === null || seo === void 0 ? void 0 : seo.seKeyWords
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(pages_ProductList__WEBPACK_IMPORTED_MODULE_4__["default"], {
                        pageData: pageData,
                        slug: slug
                    })
                ]
            });
        } else {
            const { seo: seo1  } = pageData;
            page = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_Screen_Layout_Head__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        title: seo1 === null || seo1 === void 0 ? void 0 : seo1.seTitle,
                        description: seo1 === null || seo1 === void 0 ? void 0 : seo1.seDescription,
                        keywords: seo1 === null || seo1 === void 0 ? void 0 : seo1.seKeyWords
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(pages_Home__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        props: tprops
                    })
                ]
            });
        }
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: page
    });
}


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7197:
/***/ ((module) => {

module.exports = require("@fortawesome/react-fontawesome");

/***/ }),

/***/ 2845:
/***/ ((module) => {

module.exports = require("@mui/icons-material/CloseOutlined");

/***/ }),

/***/ 7372:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Favorite");

/***/ }),

/***/ 5967:
/***/ ((module) => {

module.exports = require("@mui/icons-material/FavoriteBorderOutlined");

/***/ }),

/***/ 1583:
/***/ ((module) => {

module.exports = require("@mui/icons-material/GridView");

/***/ }),

/***/ 3929:
/***/ ((module) => {

module.exports = require("@mui/icons-material/TuneOutlined");

/***/ }),

/***/ 7644:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ViewAgendaOutlined");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2296:
/***/ ((module) => {

module.exports = require("formik");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 1736:
/***/ ((module) => {

module.exports = require("react-dom/server");

/***/ }),

/***/ 3967:
/***/ ((module) => {

module.exports = require("react-inner-image-zoom");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 4508:
/***/ ((module) => {

module.exports = require("react-responsive-carousel");

/***/ }),

/***/ 8096:
/***/ ((module) => {

module.exports = require("react-slick");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 4563:
/***/ ((module) => {

module.exports = import("@fortawesome/free-solid-svg-icons");;

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 7564:
/***/ ((module) => {

module.exports = import("chalk");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3598,1313,1664,5675,9483,6183,2337,4108,5402,365,405,6450,1719,2433,3916,1801,1848,7961,8256,39,2289,3853,5202,1658,7607,5207,7828,3019,6685], () => (__webpack_exec__(9120)));
module.exports = __webpack_exports__;

})();