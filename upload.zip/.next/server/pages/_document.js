"use strict";
(() => {
var exports = {};
exports.id = 660;
exports.ids = [660,6089,4623,7142,1733,6868,892,3011];
exports.modules = {

/***/ 5641:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var Controllers_AppController__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(405);
/* harmony import */ var helpers_common_helper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4822);
/* harmony import */ var helpers_global_console__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3650);
/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6859);
/* harmony import */ var page_config__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3521);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([Controllers_AppController__WEBPACK_IMPORTED_MODULE_1__, helpers_common_helper__WEBPACK_IMPORTED_MODULE_2__, helpers_global_console__WEBPACK_IMPORTED_MODULE_3__]);
([Controllers_AppController__WEBPACK_IMPORTED_MODULE_1__, helpers_common_helper__WEBPACK_IMPORTED_MODULE_2__, helpers_global_console__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






let store = null;
class MyDocument extends next_document__WEBPACK_IMPORTED_MODULE_4__["default"] {
    static async getInitialProps(ctx) {
        var ref;
        const originalRenderPage = ctx.renderPage;
        const domain = (0,helpers_common_helper__WEBPACK_IMPORTED_MODULE_2__/* .domainToShow */ .M_)({
            domain: (ref = ctx.req) === null || ref === void 0 ? void 0 : ref.rawHeaders[1],
            showProd: page_config__WEBPACK_IMPORTED_MODULE_5__/* .__domain.isSiteLive */ .Pq.isSiteLive
        });
        try {
            store = await Controllers_AppController__WEBPACK_IMPORTED_MODULE_1__/* .FetchStoreDetails */ .ii(domain, "pathName");
        } catch (error) {
            (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_3__/* .highLightError */ .Eg)({
                error,
                component: "_document"
            });
        }
        ctx.renderPage = ()=>originalRenderPage({
                enhanceApp: (App)=>App
            });
        const initialProps = await next_document__WEBPACK_IMPORTED_MODULE_4__["default"].getInitialProps(ctx);
        return initialProps;
    }
    render() {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(next_document__WEBPACK_IMPORTED_MODULE_4__.Html, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_document__WEBPACK_IMPORTED_MODULE_4__.Head, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "stylesheet",
                        type: "text/css",
                        href: `https://redefinecommerce.blob.core.windows.net/rdc/${1}/store/${5}/css/${5}.css`
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("body", {
                    className: "font-Outfit bg-white",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_document__WEBPACK_IMPORTED_MODULE_4__.Main, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_document__WEBPACK_IMPORTED_MODULE_4__.NextScript, {})
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyDocument);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4140:
/***/ ((module) => {

module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 9716:
/***/ ((module) => {

module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 6368:
/***/ ((module) => {

module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 6724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 8743:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/html-context.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 7564:
/***/ ((module) => {

module.exports = import("chalk");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [1313,6859,9483,405], () => (__webpack_exec__(5641)));
module.exports = __webpack_exports__;

})();