"use strict";
(() => {
var exports = {};
exports.id = 905;
exports.ids = [905,6089,4623,6868,892,3011];
exports.modules = {

/***/ 3125:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "E": () => (/* binding */ queryParam),
/* harmony export */   "H": () => (/* binding */ paths)
/* harmony export */ });
const queryParam = {
    TEAM: "team",
    INDIVIDUAL: "individual"
};
const paths = {
    HOME: "/home",
    PRODUCT: "/product",
    SPECIAL_REQUEST: "/special_request",
    PRODUCT_LISTING: "/product-list",
    NOT_FOUND: "/not-found",
    CHECKOUT: "/checkout",
    MY_ACCOUNT: "/my-account",
    SIGN_UP: "/CreateAccount/SignUp",
    THANK_YOU: "/thank-you",
    CART: "/cart.html",
    BRAND: "/brands.html",
    WISHLIST: "/wishlist",
    WRITE_A_REVIEW: "/writereview/writereview",
    REQUEST_CONSULTATION: "/itempage/RequestConsultationProof",
    CUSTOMIZE_LOGO: "/customize",
    PRODUCT_COMPARE: "/compare"
};


/***/ }),

/***/ 1604:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var constants_paths_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3125);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);



const PageNotFound = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "container static-content",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "row",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "col-sm-12 col-xs-12",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "text-center p-t-60 p-b-30",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "m-b-40",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: "/images/404.png",
                                alt: "404",
                                title: "404"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "you-may-like-title m-b-20",
                            children: "Page Not Found"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "m-b-30",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                onClick: ()=>router.push(constants_paths_constant__WEBPACK_IMPORTED_MODULE_1__/* .paths.HOME */ .H.HOME),
                                className: "btn btn-default btn-lg",
                                children: "Back to home page"
                            })
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PageNotFound);


/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(1604));
module.exports = __webpack_exports__;

})();