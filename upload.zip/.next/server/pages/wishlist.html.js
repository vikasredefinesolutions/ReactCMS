"use strict";
(() => {
var exports = {};
exports.id = 9281;
exports.ids = [9281,6089,4623,7142,1733,6868,892,3011,529];
exports.modules = {

/***/ 1200:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2337);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6183);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var services_wishlist_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3237);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_2__, services_wishlist_service__WEBPACK_IMPORTED_MODULE_4__]);
([hooks__WEBPACK_IMPORTED_MODULE_2__, services_wishlist_service__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const Wishlist = ()=>{
    const { 0: wishlist , 1: setWishlist  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
    const customerId = (0,hooks__WEBPACK_IMPORTED_MODULE_2__/* .useTypedSelector */ .ix)((state)=>state.user.id);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        (0,services_wishlist_service__WEBPACK_IMPORTED_MODULE_4__/* .getWishlist */ .sA)(customerId || 0).then((wishlist)=>setWishlist(wishlist));
    // setWishlist(wishlist);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    const removeWishlistHandler = (id)=>{
        (0,services_wishlist_service__WEBPACK_IMPORTED_MODULE_4__/* .removeWishlist */ .Ih)(id);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: "container mx-auto pt-20",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "pb-10 text-center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "text-title mb-2",
                    children: "Wishlist"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "relative",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                    role: "list",
                    className: "flex flex-wrap -mx-3 gap-y-6",
                    children: wishlist.map((list, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: "w-full md:w-1/2 lg:w-1/4 px-3",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "group relative border border-gray-300 p-3 text-center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "w-full",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                            src: list.colorLogoUrl,
                                            className: "",
                                            alt: "wishlist"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "mt-4",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                className: "",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    href: "product-page.html",
                                                    className: "text-anchor",
                                                    children: list.productName
                                                })
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "text-default-text mt-2",
                                                children: [
                                                    "$",
                                                    list.price
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex justify-center items-center gap-2 mt-2",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                            href: "product-page.html",
                                                            title: "",
                                                            className: "btn btn-secondary !py-1 text-center",
                                                            children: "View"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                            title: "Remove",
                                                            className: "btn btn-primary !py-1 text-center",
                                                            onClick: ()=>removeWishlistHandler(list.id),
                                                            children: "Remove"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        }, index))
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Wishlist);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3237:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ih": () => (/* binding */ removeWishlist),
/* harmony export */   "h6": () => (/* binding */ AddToWishlist),
/* harmony export */   "sA": () => (/* binding */ getWishlist)
/* harmony export */ });
/* harmony import */ var _utils_axios_util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(795);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__]);
_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const AddToWishlist = async (payload)=>{
    const url = "/StoreProductWishList/createstoreproductwishlist.json";
    const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__/* .SendAsyncV2 */ .y)({
        url: url,
        method: "POST",
        data: payload
    });
    return res.data;
};
const getWishlist = async (customerId)=>{
    const url = `/StoreProductWishList/getwishlistbycustomerid/${customerId}.json`;
    const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__/* .SendAsyncV2 */ .y)({
        url: url,
        method: "GET"
    });
    return res.data;
};
const removeWishlist = async (wishlistId)=>{
    const url = "/StoreProductWishList/deletewishlistbyid.json";
    const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__/* .SendAsyncV2 */ .y)({
        url: url,
        method: "DELETE",
        data: {
            wishlistId
        }
    });
    return res.data;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 7564:
/***/ ((module) => {

module.exports = import("chalk");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3598,5675,9483,6183,2337], () => (__webpack_exec__(1200)));
module.exports = __webpack_exports__;

})();