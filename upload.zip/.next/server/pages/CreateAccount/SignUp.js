"use strict";
(() => {
var exports = {};
exports.id = 2988;
exports.ids = [2988,4096,6089,6509,4623,7142,1733,6868,892,3011,529];
exports.modules = {

/***/ 2628:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const RedefineFwInput = ({ label , name , placeHolder , value , onChange , type ,  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-full lg:w-full px-3",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                htmlFor: name,
                className: "block text-base font-medium text-gray-700",
                children: label
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "mt-1",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                    type: type,
                    id: name,
                    name: name,
                    placeholder: placeHolder,
                    value: value,
                    onChange: onChange,
                    className: "form-input"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_1__.ErrorMessage, {
                name: name
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RedefineFwInput);


/***/ }),

/***/ 1221:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ SignUp_RedefineInput)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "formik"
var external_formik_ = __webpack_require__(2296);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./src/Components/SignUp/EyeButton.tsx


const EyeButton = ({ showPassword , setShowPassword  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("button", {
        className: "block w-7 h-7 text-center text-xl leading-0 absolute top-2 right-2 text-gray-400 focus:outline-none hover:text-indigo-500 transition-colors",
        onClick: ()=>setShowPassword((state)=>!state),
        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
            className: `material-symbols-outlined text-base mdi-${showPassword ? "eye-outline" : "eye-off-outline"}`,
            children: "visibility"
        })
    });
};
/* harmony default export */ const SignUp_EyeButton = (EyeButton);

;// CONCATENATED MODULE: ./src/Components/SignUp/InfoButton.tsx


const InfoButton = ()=>{
    const { 0: showInfo , 1: setShowInfo  } = (0,external_react_.useState)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "absolute top-2 right-10",
        //   x-data="{ open: false }"
        onMouseEnter: ()=>setShowInfo(true),
        onMouseLeave: ()=>setShowInfo(false),
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                className: "",
                onFocus: ()=>setShowInfo(true),
                onBlur: ()=>setShowInfo(false),
                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "material-icons-outlined ml-2 text-base",
                    children: "info"
                })
            }),
            showInfo && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "z-10 absolute top-full left-32 transform -translate-x-1/2",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "bg-slate-500 p-2 overflow-hidden mt-2",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "text-sm text-gray-200 font-light whitespace-nowrap w-full text-left px-4 py-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "w-full pt-1 pb-1 block font-semibold",
                                children: "Your password must have :"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "w-full pt-1 pb-1 block",
                                children: "8 Or more character"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "w-full pt-1 pb-1 block",
                                children: "Upper and lowercase letters"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "w-full pt-1 pb-1 block",
                                children: "At list one number"
                            })
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const SignUp_InfoButton = (InfoButton);

;// CONCATENATED MODULE: ./src/Components/SignUp/RedefineInput.tsx





const RedefineInput = ({ label , name , placeHolder , value , onChange , type , required ,  })=>{
    const { 0: showPassword , 1: setShowPassword  } = (0,external_react_.useState)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "w-full lg:w-1/2 px-3",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                htmlFor: name,
                className: "block text-base font-medium text-gray-700",
                children: [
                    label,
                    " ",
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "text-rose-500",
                        children: `${required ? `*` : ""}`
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: `${type === "password" ? "relative mb-2" : "mt-2"} `,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                        type: showPassword ? "text" : type,
                        id: name,
                        name: name,
                        placeholder: placeHolder,
                        value: value,
                        onChange: onChange,
                        className: "form-input"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(SignUp_InfoButton, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(SignUp_EyeButton, {
                        showPassword: showPassword,
                        setShowPassword: setShowPassword
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_formik_.ErrorMessage, {
                name: name
            })
        ]
    });
};
/* harmony default export */ const SignUp_RedefineInput = (RedefineInput);


/***/ }),

/***/ 7554:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const RedefineSelect = ({ label , name , options , onChange , required , value ,  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-full lg:w-1/2 px-3",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                htmlFor: name,
                className: "block text-base font-medium text-gray-700",
                children: [
                    label,
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-rose-500",
                        children: `${required ? `*` : ""}`
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "mt-1",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                    className: "form-input",
                    id: name,
                    onChange: onChange,
                    value: value,
                    children: options === null || options === void 0 ? void 0 : options.map((opt)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                            value: opt.id,
                            children: opt.name
                        }, opt.id))
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_1__.ErrorMessage, {
                name: name
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RedefineSelect);


/***/ }),

/***/ 3125:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "E": () => (/* binding */ queryParam),
/* harmony export */   "H": () => (/* binding */ paths)
/* harmony export */ });
const queryParam = {
    TEAM: "team",
    INDIVIDUAL: "individual"
};
const paths = {
    HOME: "/home",
    PRODUCT: "/product",
    SPECIAL_REQUEST: "/special_request",
    PRODUCT_LISTING: "/product-list",
    NOT_FOUND: "/not-found",
    CHECKOUT: "/checkout",
    MY_ACCOUNT: "/my-account",
    SIGN_UP: "/CreateAccount/SignUp",
    THANK_YOU: "/thank-you",
    CART: "/cart.html",
    BRAND: "/brands.html",
    WISHLIST: "/wishlist",
    WRITE_A_REVIEW: "/writereview/writereview",
    REQUEST_CONSULTATION: "/itempage/RequestConsultationProof",
    CUSTOMIZE_LOGO: "/customize",
    PRODUCT_COMPARE: "/compare"
};


/***/ }),

/***/ 8443:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

/* harmony default export */ async function __WEBPACK_DEFAULT_EXPORT__() {
    const { data: location  } = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].get("https://geolocation-db.com/json/");
    return location;
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7328:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var Components_SignUp_RedefineFwInput__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2628);
/* harmony import */ var Components_SignUp_RedefineInput__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1221);
/* harmony import */ var Components_SignUp_RedefineSelect__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7554);
/* harmony import */ var constants_paths_constant__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3125);
/* harmony import */ var constants_store_constant__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7297);
/* harmony import */ var constants_validationMessages__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4108);
/* harmony import */ var helpers_getLocation__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8443);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6183);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var services_user_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1488);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_13__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([helpers_getLocation__WEBPACK_IMPORTED_MODULE_9__, hooks__WEBPACK_IMPORTED_MODULE_10__, services_user_service__WEBPACK_IMPORTED_MODULE_12__]);
([helpers_getLocation__WEBPACK_IMPORTED_MODULE_9__, hooks__WEBPACK_IMPORTED_MODULE_10__, services_user_service__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














const _SignupSchema = yup__WEBPACK_IMPORTED_MODULE_13__.object().shape({
    firstname: yup__WEBPACK_IMPORTED_MODULE_13__.string().required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_8__/* .signupPageMessages.firstname.required */ .C0.firstname.required),
    lastName: yup__WEBPACK_IMPORTED_MODULE_13__.string().required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_8__/* .signupPageMessages.lastName.required */ .C0.lastName.required),
    companyId: yup__WEBPACK_IMPORTED_MODULE_13__.string().when("showIndustries", {
        is: true,
        then: yup__WEBPACK_IMPORTED_MODULE_13__.string().required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_8__/* .signupPageMessages.companyId.required */ .C0.companyId.required)
    }),
    email: yup__WEBPACK_IMPORTED_MODULE_13__.string().email().required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_8__/* .signupPageMessages.email.required */ .C0.email.required),
    password: yup__WEBPACK_IMPORTED_MODULE_13__.string().required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_8__/* .signupPageMessages.password.required */ .C0.password.required),
    confirmPassword: yup__WEBPACK_IMPORTED_MODULE_13__.string().test("passwords-match", constants_validationMessages__WEBPACK_IMPORTED_MODULE_8__/* .signupPageMessages.confirmPassword.mustMatch */ .C0.confirmPassword.mustMatch, function(value) {
        return this.parent.password === value;
    }),
    storeCustomerAddress: yup__WEBPACK_IMPORTED_MODULE_13__.array().of(yup__WEBPACK_IMPORTED_MODULE_13__.object().shape({
        address1: yup__WEBPACK_IMPORTED_MODULE_13__.string().required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_8__/* .signupPageMessages.storeCustomerAddress.address1.required */ .C0.storeCustomerAddress.address1.required),
        address2: yup__WEBPACK_IMPORTED_MODULE_13__.string().required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_8__/* .signupPageMessages.storeCustomerAddress.address2.required */ .C0.storeCustomerAddress.address2.required),
        city: yup__WEBPACK_IMPORTED_MODULE_13__.string().required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_8__/* .signupPageMessages.storeCustomerAddress.city.required */ .C0.storeCustomerAddress.city.required),
        state: yup__WEBPACK_IMPORTED_MODULE_13__.string().required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_8__/* .signupPageMessages.storeCustomerAddress.state.required */ .C0.storeCustomerAddress.state.required),
        postalCode: yup__WEBPACK_IMPORTED_MODULE_13__.string().required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_8__/* .signupPageMessages.storeCustomerAddress.postalCode.required */ .C0.storeCustomerAddress.postalCode.required),
        phone: yup__WEBPACK_IMPORTED_MODULE_13__.string().required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_8__/* .signupPageMessages.storeCustomerAddress.phone.required */ .C0.storeCustomerAddress.phone.required),
        countryName: yup__WEBPACK_IMPORTED_MODULE_13__.string().required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_8__/* .signupPageMessages.storeCustomerAddress.countryName.required */ .C0.storeCustomerAddress.countryName.required)
    })).min(1)
});
const _SignUpInitials = {
    showIndustries: false,
    id: 0,
    details: "",
    rowVersion: "",
    location: "",
    ipAddress: "",
    macAddress: "",
    firstname: "",
    lastName: "",
    email: "",
    password: "",
    confirmPassword: "",
    companyName: "",
    companyId: 0,
    sharedCustomerId: 0,
    customerType: "",
    storeId: 0,
    isTaxableuser: false,
    storeCustomerAddress: [
        {
            id: 0,
            rowVersion: "",
            location: "",
            ipAddress: "",
            macAddress: "",
            customerId: 0,
            firstname: "",
            lastName: "",
            email: "",
            address1: "",
            address2: "",
            suite: "",
            city: "",
            state: "",
            postalCode: "",
            phone: "",
            fax: "",
            countryName: "",
            countryCode: "",
            addressType: "",
            isDefault: false,
            recStatus: "A"
        }, 
    ],
    recStatus: "A"
};
const SignUp = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_11__.useRouter)();
    const { 0: stateContries , 1: setStateContries  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({
        state: null,
        country: null
    });
    const { 0: industries , 1: setIndustries  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);
    const display = "";
    /* -------------------------------- STATES ------------------------------  */ const { layout: storeLayout , id: storeId  } = (0,hooks__WEBPACK_IMPORTED_MODULE_10__/* .useTypedSelector */ .ix)((state)=>state.store);
    /* ------------------------------- FUNCTIONS ------------------------------  */ const loginSubmitHandler = async (enteredInputs)=>{
        const location = await (0,helpers_getLocation__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
        const payload = {
            storeCustomerModel: {
                ...enteredInputs,
                location: `${location.city}, ${location.state}, ${location.country_name}, ${location.postal}`,
                ipAddress: location.IPv4,
                storeId: storeId,
                customerType: "corporate",
                storeCustomerAddress: [
                    {
                        ...enteredInputs.storeCustomerAddress[0],
                        addressType: "b",
                        firstname: enteredInputs.firstname,
                        lastName: enteredInputs.lastName,
                        email: enteredInputs.email,
                        recStatus: "A"
                    }, 
                ],
                recStatus: "A"
            }
        };
        (0,services_user_service__WEBPACK_IMPORTED_MODULE_12__/* .CreateNewAccount */ .pY)(payload).then(()=>router.push(constants_paths_constant__WEBPACK_IMPORTED_MODULE_6__/* .paths.HOME */ .H.HOME));
    // .catch((err) => console.log('err', err));
    // .finally(() => console.log('close loader'));
    };
    const getStatesList = (id)=>{
        (0,services_user_service__WEBPACK_IMPORTED_MODULE_12__/* .GetStatesList */ .Mo)(id).then((state)=>{
            setStateContries((country)=>({
                    ...country,
                    state: state
                }));
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        (0,services_user_service__WEBPACK_IMPORTED_MODULE_12__/* .GetCountriesList */ .gF)().then((countries)=>{
            setStateContries({
                state: null,
                country: countries
            });
            return countries[0].id;
        }).then(getStatesList);
        (0,services_user_service__WEBPACK_IMPORTED_MODULE_12__/* .GetIndustriesList */ ._w)().then((indus)=>setIndustries(indus));
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    /* -------------------------------- VIEW ------------------------------  */ const CreateMyAccountForm = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_1__.Formik, {
        initialValues: {
            ..._SignUpInitials,
            showIndustries: storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_7__/* ._Store.type3 */ .up.type3
        },
        onSubmit: loginSubmitHandler,
        validationSchema: _SignupSchema,
        children: ({ values , handleChange , setFieldValue  })=>{
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_1__.Form, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-full mx-auto max-w-7xl",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-wrap -mx-3 gap-y-6",
                        children: [
                            storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_7__/* ._Store.type3 */ .up.type3 && industries !== null && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_SignUp_RedefineSelect__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                label: "Country",
                                placeHolder: "Select Country",
                                name: "companyId",
                                value: values.companyId,
                                options: industries,
                                onChange: (event)=>{
                                    setFieldValue("companyId", event.target.value);
                                    getStatesList(+(event === null || event === void 0 ? void 0 : event.target.value));
                                },
                                required: false
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_SignUp_RedefineInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                required: false,
                                label: "First Name",
                                placeHolder: "Enter Your First Name",
                                name: "firstname",
                                value: values.firstname,
                                type: "text",
                                onChange: (event)=>handleChange(event)
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_SignUp_RedefineInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                required: false,
                                label: "Last Name",
                                placeHolder: "Enter Your Last Name",
                                name: "lastName",
                                value: values.lastName,
                                type: "text",
                                onChange: (event)=>handleChange(event)
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_SignUp_RedefineInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                required: false,
                                label: "Company Name",
                                placeHolder: "Enter Your Company Name",
                                name: "companyName",
                                value: values.companyName,
                                type: "text",
                                onChange: (event)=>handleChange(event)
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_SignUp_RedefineInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                required: false,
                                label: "Email Address",
                                placeHolder: "Enter Email Address",
                                name: "email",
                                value: values.email,
                                type: "text",
                                onChange: (event)=>handleChange(event)
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_SignUp_RedefineInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                required: false,
                                label: "Password",
                                placeHolder: "",
                                name: "password",
                                value: values.password,
                                type: "password",
                                onChange: (event)=>handleChange(event)
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_SignUp_RedefineInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                required: false,
                                label: "Confirm Password",
                                placeHolder: "",
                                name: "confirmPassword",
                                value: values.confirmPassword,
                                type: "password",
                                onChange: (event)=>handleChange(event)
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_SignUp_RedefineInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                required: false,
                                label: "Phone Number",
                                placeHolder: "Enter Your Phone Number",
                                name: "storeCustomerAddress[0].phone",
                                value: values.storeCustomerAddress[0].phone,
                                type: "text",
                                onChange: (event)=>handleChange(event)
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_SignUp_RedefineInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                required: false,
                                label: "Address 1",
                                placeHolder: "Enter Your Address 1",
                                name: "storeCustomerAddress[0].address1",
                                value: values.storeCustomerAddress[0].address1,
                                type: "text",
                                onChange: (event)=>handleChange(event)
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_SignUp_RedefineInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                required: false,
                                label: "Address 2",
                                placeHolder: "Enter Your Address 2",
                                name: "storeCustomerAddress[0].address2",
                                value: values.storeCustomerAddress[0].address2,
                                type: "text",
                                onChange: (event)=>handleChange(event)
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_SignUp_RedefineInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                required: false,
                                label: "Zip Code",
                                placeHolder: "Enter Your Zip Code",
                                name: "storeCustomerAddress[0].postalCode",
                                value: values.storeCustomerAddress[0].postalCode,
                                type: "text",
                                onChange: (event)=>handleChange(event)
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_SignUp_RedefineInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                required: false,
                                label: "City",
                                placeHolder: "Enter Your City",
                                name: "storeCustomerAddress[0].city",
                                value: values.storeCustomerAddress[0].city,
                                type: "text",
                                onChange: (event)=>handleChange(event)
                            }),
                            stateContries.country !== null && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_SignUp_RedefineSelect__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                label: "Country",
                                placeHolder: "Select Country",
                                name: "storeCustomerAddress[0].countryName",
                                value: values.storeCustomerAddress[0].countryName,
                                options: stateContries.country,
                                onChange: (event)=>{
                                    setFieldValue("storeCustomerAddress[0].countryName", event.target.value);
                                    getStatesList(+(event === null || event === void 0 ? void 0 : event.target.value));
                                },
                                required: false
                            }),
                            stateContries.state !== null && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_SignUp_RedefineSelect__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                label: "State",
                                placeHolder: "Select State",
                                name: "storeCustomerAddress[0].state",
                                value: values.storeCustomerAddress[0].state,
                                options: stateContries.state,
                                onChange: (event)=>setFieldValue("storeCustomerAddress[0].state", +event.target.value),
                                required: false
                            }),
                            storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_7__/* ._Store.type3 */ .up.type3 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_SignUp_RedefineFwInput__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                label: `Please tell us about your company, and how you would like to use
          the Patagonia co-branded gear`,
                                placeHolder: "",
                                name: "details",
                                value: values.details,
                                onChange: (event)=>handleChange(event),
                                type: "text",
                                required: false
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full lg:w-full px-3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    type: "submit",
                                    className: "btn btn-primary",
                                    children: "Submit"
                                })
                            })
                        ]
                    })
                })
            });
        }
    });
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_7__/* ._Store.type2 */ .up.type2) {
        if (display === undefined) {
            router.push("/home");
        }
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                display === constants_paths_constant__WEBPACK_IMPORTED_MODULE_6__/* .queryParam.TEAM */ .E.TEAM && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                    className: "container mx-auto mt-8 mb-8",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_1__.Formik, {
                            initialValues: _SignUpInitials,
                            onSubmit: loginSubmitHandler,
                            children: ({ values , handleChange  })=>{
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_1__.Form, {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "w-full mx-auto max-w-7xl",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "text-xl md:text-2xl lg:text-sub-title font-sub-title pb-2 mb-4 border-b border-b-gray-300",
                                                children: "Personal Information"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex flex-wrap -mx-3 gap-y-6 mb-8",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_SignUp_RedefineInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                        label: "First Name",
                                                        placeHolder: "First Name",
                                                        name: "firstName",
                                                        value: values.firstname,
                                                        onChange: (event)=>handleChange(event),
                                                        type: "text",
                                                        required: true
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_SignUp_RedefineInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                        label: "Last Name",
                                                        placeHolder: "Last Name",
                                                        name: "lastName",
                                                        value: values.lastName,
                                                        onChange: (event)=>handleChange(event),
                                                        type: "text",
                                                        required: true
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_SignUp_RedefineInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                        label: "Email Address",
                                                        placeHolder: "Email Address",
                                                        name: "email",
                                                        value: values.email,
                                                        onChange: (event)=>handleChange(event),
                                                        type: "text",
                                                        required: true
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_SignUp_RedefineInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                        label: "Password",
                                                        placeHolder: "Password",
                                                        name: "password",
                                                        value: values.password,
                                                        onChange: (event)=>handleChange(event),
                                                        type: "password",
                                                        required: true
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_SignUp_RedefineInput__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                        label: "Confirm Password",
                                                        placeHolder: "Confirm Password",
                                                        name: "confirmPassword",
                                                        value: values.confirmPassword,
                                                        onChange: (event)=>handleChange(event),
                                                        type: "password",
                                                        required: true
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                });
                            }
                        })
                    })
                }),
                display === constants_paths_constant__WEBPACK_IMPORTED_MODULE_6__/* .queryParam.INDIVIDUAL */ .E.INDIVIDUAL && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                        className: "container mx-auto mt-8 mb-8",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "",
                            children: CreateMyAccountForm
                        })
                    })
                })
            ]
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_7__/* ._Store.type1 */ .up.type1 || storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_7__/* ._Store.type4 */ .up.type4 || storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_7__/* ._Store.type3 */ .up.type3) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "container mx-auto bg-gray-100 mb-6 ",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "gird grid-cols-1 lg:flex lg:items-center gap-6 lg:py-8 lg:px-12 px-4 py-4 lg:my-5",
                children: CreateMyAccountForm
            })
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SignUp);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2296:
/***/ ((module) => {

module.exports = require("formik");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 7564:
/***/ ((module) => {

module.exports = import("chalk");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9483,6183,4108], () => (__webpack_exec__(7328)));
module.exports = __webpack_exports__;

})();