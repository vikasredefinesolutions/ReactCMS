"use strict";
exports.id = 1915;
exports.ids = [1915];
exports.modules = {

/***/ 1915:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var constants_validationMessages__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4108);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6183);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_1__]);
hooks__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




// const defaultDileveryAddres = {
//   firstName: 'John',
//   lastName: 'Smith',
//   companyName: 'Redefine',
//   streetAddress: 'Street4, Waltham',
//   address2: '',
//   city: 'Minnesota',
//   state: 'MP',
//   zipCode: '76051',
//   Country: 'United Kingdom',
//   phone: '+1 98567-59863',
// };
const cardArray = [
    {
        name: "VISA",
        image: "images/card-visa.webp"
    },
    {
        name: "AMEX",
        image: "images/card-american-express.webp"
    },
    {
        name: "MASTERCARD",
        image: "images/card-master.webp"
    },
    {
        name: "DISCOVER",
        image: "images/card-discover.webp"
    }, 
];
const CheckoutController = ()=>{
    const { 0: address , 1: setAddress  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    const customer = (0,hooks__WEBPACK_IMPORTED_MODULE_1__/* .useTypedSelector */ .ix)((state)=>state.user.customer);
    const isLoggedIn = true;
    const { 0: showEmail , 1: setShowEmail  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(true);
    const { 0: showPassword , 1: setShowPassword  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { 0: showForgetPassword , 1: setShowForgetPassword  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { 0: showShippingScreen , 1: setShowShippingScreen  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { 0: shippingAdress , 1: setShippingAdress  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
    const { 0: useShippingAddress , 1: setUseShippingAddress  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(true);
    const { 0: billingAdress , 1: setBillingAdress  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
    const { 0: cardDetails , 1: setCardDetails  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const { 0: showCVVHelpCard , 1: setShowCVVHelpCard  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { 0: purchaseOrder , 1: setPurchaseOrder  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { 0: showChangeAddressPopup , 1: setShowChangeAddressPopup  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(NaN);
    const { 0: showAddAccount , 1: setShowAddAccount  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const validationSchema = yup__WEBPACK_IMPORTED_MODULE_3__.object().shape({
        email: yup__WEBPACK_IMPORTED_MODULE_3__.string().email(constants_validationMessages__WEBPACK_IMPORTED_MODULE_0__/* .checkoutUserLoginMessages.email.email */ .V.email.email).required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_0__/* .checkoutUserLoginMessages.email.required */ .V.email.required)
    });
    const passwordValidationSchema = yup__WEBPACK_IMPORTED_MODULE_3__.object().shape({
        password: yup__WEBPACK_IMPORTED_MODULE_3__.string().min(3, constants_validationMessages__WEBPACK_IMPORTED_MODULE_0__/* .checkoutPasswordMessages.password.min */ .UT.password.min).required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_0__/* .checkoutPasswordMessages.password.required */ .UT.password.required)
    });
    const newAccountPasswordValidationSchema = yup__WEBPACK_IMPORTED_MODULE_3__.object().shape({
        password: yup__WEBPACK_IMPORTED_MODULE_3__.string().min(3, constants_validationMessages__WEBPACK_IMPORTED_MODULE_0__/* .checkoutNewAccountPasswordMessages.password.min */ .$P.password.min).required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_0__/* .checkoutNewAccountPasswordMessages.password.required */ .$P.password.required),
        passwordConfirmation: yup__WEBPACK_IMPORTED_MODULE_3__.string().oneOf([
            yup__WEBPACK_IMPORTED_MODULE_3__.ref("password"),
            null
        ], constants_validationMessages__WEBPACK_IMPORTED_MODULE_0__/* .checkoutNewAccountPasswordMessages.passwordConfirmation.mustMatch */ .$P.passwordConfirmation.mustMatch)
    });
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (isLoggedIn && address.length > 0) {
            setShippingAdress(address[0]);
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        isLoggedIn,
        address
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (useShippingAddress) {
            setBillingAdress(shippingAdress);
        } else if (showShippingScreen) {
            setShowChangeAddressPopup(2);
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        useShippingAddress,
        shippingAdress
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (customer.customerAddress) {
            setAddress(customer.customerAddress);
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        customer.customerAddress
    ]);
    function creditCardType(cc) {
        var re = new RegExp("^4");
        if (cc.match(re) != null) return "VISA";
        if (/^(5[1-5][0-9]{14}|2(22[1-9][0-9]{12}|2[3-9][0-9]{13}|[3-6][0-9]{14}|7[0-1][0-9]{13}|720[0-9]{12}))$/.test(cc)) return "MASTERCARD";
        re = new RegExp("^3[47]");
        if (cc.match(re) != null) return "AMEX";
        re = new RegExp("^(6011|622(12[6-9]|1[3-9][0-9]|[2-8][0-9]{2}|9[0-1][0-9]|92[0-5]|64[4-9])|65)");
        if (cc.match(re) != null) return "DISCOVER";
        return "";
    }
    const closeShippingPopup = ()=>{
        if (showChangeAddressPopup === 2) {
            setUseShippingAddress(true);
        }
        setShowChangeAddressPopup(NaN);
    };
    const changeAddres = (address)=>{
        (showChangeAddressPopup === 1 ? setShippingAdress : setBillingAdress)(address);
        setShowChangeAddressPopup(NaN);
    };
    return {
        creditCardType,
        setShowEmail,
        setShowPassword: isLoggedIn ? setShowPassword : setShowAddAccount,
        setShowForgetPassword,
        setShowShippingScreen,
        setShippingAdress,
        setUseShippingAddress,
        setCardDetails,
        setShowCVVHelpCard,
        setPurchaseOrder,
        setShowChangeAddressPopup,
        setBillingAdress,
        closeShippingPopup,
        changeAddres,
        setShowAddAccount,
        useShippingAddress,
        cardArray,
        passwordValidationSchema,
        newAccountPasswordValidationSchema,
        addressArray: address,
        showEmail,
        showPassword,
        showForgetPassword,
        billingAdress,
        showCVVHelpCard,
        cardDetails,
        purchaseOrder,
        showChangeAddressPopup,
        validationSchema,
        showShippingScreen,
        shippingAdress,
        showAddAccount
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CheckoutController);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;