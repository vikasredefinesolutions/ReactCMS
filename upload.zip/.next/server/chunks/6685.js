"use strict";
exports.id = 6685;
exports.ids = [6685];
exports.modules = {

/***/ 5788:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/*Component Name: ElementAccordionDisplay
Component Functional Details: User can create or update ElementAccordionDisplay master details from here.
Created By: Vikas Patel
Created Date: 16th September 2022
Modified By: <Modified By Name>
Modified Date: <Modified Date> */ //import { useEffect, useState } from 'react';

const ElementAccordionDisplay = ({ acValues  })=>{
    const iconArr = {
        keyboard_arrow_up: "keyboard_arrow_down",
        keyboard_arrow_down: "keyboard_arrow_up",
        remove_circle_outline: "add_circle_outline",
        add_circle_outline: "remove_circle_outline"
    };
    const showHideAccordion = (event)=>{
        if (event.target.querySelector(".pointer-class")) {
            let symbolobj = event.target.querySelector(".pointer-class");
            symbolobj.innerHTML = iconArr[symbolobj.innerHTML];
            if (event.currentTarget.querySelector(".ac-description").classList.contains("hidden")) event.currentTarget.querySelector(".ac-description").classList.remove("hidden");
            else event.currentTarget.querySelector(".ac-description").classList.add("hidden");
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: acValues.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: acValues.map((acValue, index)=>{
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                    className: "mb-4 last:mb-0 hasarr clonnable border-b border-black",
                    onClick: showHideAccordion,
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                            className: "w-full flex justify-between items-center text-left font-bold font-heading px-2 py-4 border-0 hover:border-0",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "text-defaule-text",
                                    children: acValue.title
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "material-icons-outlined ml-3 pointer-class",
                                    children: acValue.openstatus == "Yes" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                        children: acValue.icon == "caret" ? "keyboard_arrow_down" : "remove_circle_outline"
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                        children: acValue.icon == "caret" ? "keyboard_arrow_up" : "add_circle_outline"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: `text-defaule-text px-2 mt-2 pb-4 ac-description ${acValue.openstatus != "Yes" ? "hidden" : ""}`,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-defaule-text mt-2",
                                dangerouslySetInnerHTML: {
                                    __html: acValue.desc
                                }
                            })
                        })
                    ]
                }, index);
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ElementAccordionDisplay);


/***/ }),

/***/ 5827:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_responsive_carousel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4508);
/* harmony import */ var react_responsive_carousel__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_responsive_carousel__WEBPACK_IMPORTED_MODULE_1__);
/*Component Name: ElementCarousel
Component Functional Details: Element for Component ElementCarousel  
Created By: Vikas Patel
Created Date: 17th September 2022
Modified By: <Modified By Name>
Modified Date: <Modified Date> */ 


const ElementCarouselDisplay = ({ bannerArr  })=>{
    const showArrow = bannerArr.showArrow != undefined ? bannerArr.showArrow == "On" ? true : false : true;
    const showIndicators = bannerArr.showIndicators != undefined ? bannerArr.showIndicators == "On" ? true : false : true;
    const showThumb = bannerArr.showThumb != undefined ? bannerArr.showThumb == "On" ? true : false : true;
    const autoPlay = bannerArr.autoPlay != undefined ? bannerArr.autoPlay == "On" ? true : false : true;
    const infiniteLoop = bannerArr.infiniteLoop != undefined ? bannerArr.infiniteLoop == "On" ? true : false : true;
    const stopOnHover = bannerArr.stopOnHover != undefined ? bannerArr.stopOnHover == "On" ? true : false : true;
    const showStatus = bannerArr.showStatus != undefined ? bannerArr.showStatus == "On" ? true : false : true;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            class: "mainsection container mx-auto mt-20",
            children: Object.keys(bannerArr).length > 0 && bannerArr.images != null && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_responsive_carousel__WEBPACK_IMPORTED_MODULE_1__.Carousel, {
                renderArrowPrev: (clickHandler, hasPrev, labelPrev)=>hasPrev && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "absolute top-1/2 -translate-y-1/2 left-4 z-10 flex items-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            onClick: clickHandler,
                            className: "bg-light-gray bg-opacity-90 flex justify-center items-center w-10 h-10 rounded-md shadow-md focus:outline-none",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                viewBox: "0 0 20 20",
                                fill: "currentColor",
                                className: "chevron-left w-10 h-10",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                    fillRule: "evenodd",
                                    d: "M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z",
                                    clipRule: "evenodd"
                                })
                            })
                        })
                    }),
                renderArrowNext: (clickHandler, hasNext, labelNext)=>hasNext && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "absolute top-1/2 -translate-y-1/2 right-4 z-10 flex items-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            onClick: clickHandler,
                            className: "bg-light-gray bg-opacity-90 flex justify-center items-center w-10 h-10 rounded-md shadow-md focus:outline-none",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                viewBox: "0 0 20 20",
                                fill: "currentColor",
                                className: "chevron-right w-10 h-10",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                    fillRule: "evenodd",
                                    d: "M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z",
                                    clipRule: "evenodd"
                                })
                            })
                        })
                    }),
                showStatus: showStatus,
                stopOnHover: stopOnHover,
                infiniteLoop: infiniteLoop,
                autoPlay: false,
                showArrows: showArrow,
                showIndicators: showIndicators,
                showThumbs: showThumb,
                children: bannerArr.images.map((image)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "relative",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "overflow-hidden",
                            children: [
                                image.image_or_video == "Image" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: image.image_url
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: image.video_type == "Youtube" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("iframe", {
                                        class: "w-full aspect-video",
                                        src: `https://www.youtube.com/embed/${image.video_url}?rel=0`,
                                        allow: "autoplay; encrypted-media",
                                        frameborder: "0"
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("iframe", {
                                        class: "p-0 w-full aspect-[7/3]",
                                        src: `https://player.vimeo.com/video/${image.video_url}?autoplay=1&amp;loop=1&amp;background=1&amp;muted=1`,
                                        allow: "autoplay; encrypted-media",
                                        frameborder: "0"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: `flex items-center absolute ${image.headline_font_size} inset-0 p-1 lg:p-4 justify-${image.text_pos ? image.text_pos : "center"} text-white`,
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        class: "",
                                        style: {
                                            background: `rgb(${image.text_bg_color}, ${image.bg_opacity})`,
                                            padding: "20px"
                                        },
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                class: "",
                                                children: image.headline
                                            }),
                                            image.button_display == "Yes" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        href: image.button_link,
                                                        target: image.button_link_window ? "_blank" : "",
                                                        className: `btn ${image.button_text_transform} ${image.button_size} ${image.button_style}`,
                                                        rel: "noreferrer",
                                                        children: image.button_text
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    }, image);
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ElementCarouselDisplay);


/***/ }),

/***/ 6637:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "ts": () => (/* binding */ updateSetProperties)
});

// UNUSED EXPORTS: displayCarousel, displayClass, displaySection, removeWidthClass, showMsg

// NAMESPACE OBJECT: ./src/Components/Home/DynamicFunction.jsx
var DynamicFunction_namespaceObject = {};
__webpack_require__.r(DynamicFunction_namespaceObject);
__webpack_require__.d(DynamicFunction_namespaceObject, {
  "boximage": () => (boximage),
  "multipleImages": () => (multipleImages),
  "numberingdiv": () => (numberingdiv)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./src/Components/Home/ElementAccordionDisplay.jsx
var ElementAccordionDisplay = __webpack_require__(5788);
// EXTERNAL MODULE: external "react-dom/server"
var server_ = __webpack_require__(1736);
;// CONCATENATED MODULE: ./src/Components/Home/DynamicFunction.jsx
const numberingdiv = (dataArr)=>{
    let strHTML = "";
    if (dataArr.length > 0) {
        let count = 1;
        dataArr.forEach(function(item) {
            strHTML += '<div class="flex items-start mb-6">';
            strHTML += '<div class="mr-10 flex-shrink-0 flex justify-center items-center w-12 h-12 rounded-full bg-gray-500 text-gray-50 font-bold font-heading">' + count + "</div>";
            strHTML += '<div class="max-w-xs">';
            strHTML += '<div class="text-box-p leading-loose">';
            strHTML += item.Description;
            strHTML += "</div>";
            strHTML += "</div>";
            strHTML += "</div>";
        });
    }
    return strHTML;
};
const boximage = (dataArr)=>{
    let strHTML = "";
    if (dataArr.length > 0) {
        dataArr.forEach(function(item) {
            let className;
            if (item.colcount == 2) className = "lg:w-1/2";
            else if (item.colcount == 3) className = "lg:w-1/3";
            else className = "lg:w-1/4";
            strHTML += '<div class="w-full ' + className + ' px-3 md:w-1/3 mt-6">';
            strHTML += '<div class="flex justify-center pb-5">';
            strHTML += '<div class="btn-primary rounded-full w-10 h-10 flex justify-center items-center text-base text-white font-semibold">' + item.index + "</div>";
            strHTML += "</div>";
            strHTML += '<div class="border border-gray-50 px-2 py-2">';
            if (item.Image !== undefined) {
                strHTML += '<div class="flex justify-center">';
                strHTML += '<a title="' + item.Image_link + '">';
                strHTML += '<img class="w-full isinput img-editable alttitle" src="' + item.Image + '"/>';
                strHTML += "</a>";
                strHTML += "</div>";
            }
            if (item.Headline !== undefined && item.Headline !== "") {
                strHTML += '<div class="text-center bg-white w-full">';
                strHTML += '<div class="text-base p-4">' + item.Headline + "</div>";
                strHTML += "</div>";
            }
            if (item.Button_display != undefined && item.Button_display == "Yes") {
                strHTML += '<div class="mt-5 mb-5">';
                strHTML += '<a target="" href="' + item.Button_link + '" class="' + item.Button_size + " " + item.Button_style + '">';
                strHTML += item.Button_text;
                strHTML += "</a>";
                strHTML += "</div>";
            }
            // <div class="mb-5">
            //         <a title="" target="" href="javascript:void(0);" inpname="first_btn" inplnname="first_btn_link" inpclname="first_btn_cls" class="px-6 py-3 text-green-700 font-semibold uppercase bg-neutral-900 hover:bg-gray-600 hrefurl isinput changebtn" data-nofollow="N" contenteditable="true">
            //           lorem impluse
            //         </a>
            //       </div>
            strHTML += "</div>";
            strHTML += "</div>";
        });
    }
    return strHTML;
// <div class="w-full lg:w-1/4 px-3 md:w-1/3 mt-6 isinput">
//   <div class="border border-gray-50 px-2 py-2">
//     <div class="flex justify-center">
//       Image
//     </div>
//     <div class="text-center bg-white w-full">
//       <div class="text-base p-4">Headline</div>
//       <div class="mb-5">
//         Button
//       </div>
//     </div>
//   </div>
// </div>
};
const multipleImages = (dataArr)=>{
    let strHTML = "";
    if (dataArr.length > 0) {
        dataArr.forEach(function(item) {
            strHTML += '<div class="w-full lg:w-1/3 p-4">';
            strHTML += '<div class="flex justify-center pb-5">';
            strHTML += '<div class="btn-primary rounded-full w-10 h-10 flex justify-center items-center text-base text-white font-semibold">' + item.index + "</div>";
            strHTML += "</div>";
            strHTML += '<div class="border border-gray-50 px-2 py-2">';
            if (item.Image !== undefined) {
                strHTML += '<div class="flex justify-center">';
                strHTML += '<a title="' + item.Image_link + '">';
                strHTML += '<img class="w-full" src="' + item.Image + '"/>';
                strHTML += "</a>";
                strHTML += "</div>";
            }
            if (item.Headline != undefined && item.Headline != "") {
                strHTML += '<div class="text-center bg-white w-full">';
                strHTML += '<div class="text-base p-4">' + item.Headline + "</div>";
                strHTML += "</div>";
            }
            // if(item.Button_display != undefined && item.Button_display == "Yes")
            // {
            //     strHTML += '<div class="mt-5 mb-5">';
            //     strHTML += '<a target="" href="'+item.Button_link+'" class="'+item.Button_size+' '+item.Button_style+'">';
            //     strHTML += item.Button_text;
            //     strHTML += '</a>'
            //     strHTML += '</div>';
            // }
            // <div class="mb-5">
            //         <a title="" target="" href="javascript:void(0);" inpname="first_btn" inplnname="first_btn_link" inpclname="first_btn_cls" class="px-6 py-3 text-green-700 font-semibold uppercase bg-neutral-900 hover:bg-gray-600 hrefurl isinput changebtn" data-nofollow="N" contenteditable="true">
            //           lorem impluse
            //         </a>
            //       </div>
            strHTML += "</div>";
            strHTML += "</div>";
        });
    }
    return strHTML;
// <div class="w-full lg:w-1/4 px-3 md:w-1/3 mt-6 isinput">
//   <div class="border border-gray-50 px-2 py-2">
//     <div class="flex justify-center">
//       Image
//     </div>
//     <div class="text-center bg-white w-full">
//       <div class="text-base p-4">Headline</div>
//       <div class="mb-5">
//         Button
//       </div>
//     </div>
//   </div>
// </div>
};

;// CONCATENATED MODULE: ./src/Components/Home/Helper.jsx




const updateSetProperties = (element)=>{
    let x = document.getElementById("div" + element.no);
    if (element.selectedVal != undefined && element.selectedVal != "") {
        //      let elProperties;
        Object.entries(element.selectedVal).map(([key, value])=>{
            if (value.type == "text") {
                if (x.querySelectorAll("#" + key).length > 0) {
                    x.querySelectorAll("#" + key)[0].innerHTML = value.value;
                }
            }
            if (value.type == "image") {
                if (x.querySelectorAll("#" + key).length > 0) {
                    if (x.querySelectorAll("#" + key + "_img").length > 0) {
                        x.querySelectorAll("#" + key + "_img")[0].src = value.value;
                    } else {
                        x.querySelectorAll("#" + key)[0].innerHTML = '<a href="javascript:void(0)" id="' + key + '_img_link"><img id="' + key + '_img" class="" src="' + value.value + '" alt="" title="" /> </a>';
                    }
                }
            }
            if (value.type == "alt") {
                //let propname = key.replace("_alt", "");
                if (x.querySelectorAll("#" + key).length > 0) {
                    if (x.querySelectorAll("#" + key + "_img").length > 0) {
                        x.querySelectorAll("#" + key + "_img")[0].alt = value.value;
                        x.querySelectorAll("#" + key + "_img")[0].title = value.value;
                    } else {
                        x.querySelectorAll("#" + key)[0].innerHTML = '<a href="javascript:void(0)" id="' + key + '_img_link"><img id="' + key + '_img" class="" src="" alt="' + value.value + '" title="' + value.value + '" /> </a>';
                    }
                }
            }
            if (value.type == "appearance") {
                let propname = value.value;
                if (element.properties.TextAppearance.fields != undefined) {
                    let fields = element.properties.TextAppearance.fields.split(",");
                    let textBgColor = propname.text_bg_color ?? "";
                    let bgOpacity = propname.bg_opacity ?? "1";
                    let fontSize = propname.font_size ?? "";
                    let textPos = propname.text_pos ?? "center";
                    fields.forEach((el)=>{
                        x.querySelectorAll("#" + el + "_pos")[0].className = "flex items-center absolute " + fontSize + " inset-0 p-1 lg:p-4 text-white justify-" + textPos;
                        x.querySelectorAll("#" + el + "_bg")[0].style = "background: rgb(" + textBgColor + ", " + bgOpacity + "); padding: 20px";
                        x.querySelectorAll("#" + el)[0].className = "pb-2";
                    });
                }
            }
            if (value.type == "link") {
                if (x.querySelectorAll("#" + key).length > 0) {
                    if (x.querySelectorAll("#" + key + "_img_link").length > 0) {
                        x.querySelectorAll("#" + key + "_img_link")[0].href = value.value;
                    } else {
                        x.querySelectorAll("#" + key)[0].innerHTML = '<a href="' + value.value + '" id="' + key + '_img_link"><img id="' + key + '_img" class="" src=""/> </a>';
                    }
                }
            }
            if (value.type == "Youtube") {
                if (x.querySelectorAll("#" + key).length > 0) {
                    x.querySelectorAll("#" + key)[0].innerHTML = '<iframe class="w-full aspect-video" src="https://www.youtube.com/embed/' + value.value + '?rel=0" allow="autoplay; encrypted-media" frameborder="0"></iframe>';
                }
            }
            if (value.type == "Vimeo") {
                if (x.querySelectorAll("#" + key).length > 0) {
                    x.querySelectorAll("#" + key)[0].innerHTML = '<iframe src="https://player.vimeo.com/video/' + value.value + '?background=1" frameborder="0" allow="autoplay; fullscreen" allowfullscreen="" style="" class="w-full aspect-video"></iframe>';
                }
            }
            if (value.type == "text") {
                if (x.querySelectorAll("#" + key).length > 0) {
                    x.querySelectorAll("#" + key)[0].innerHTML = value.value;
                }
            }
            if (value.type == "btn_size") {
                let propName = key.replace("_size", "");
                if (x.querySelectorAll("#" + propName).length > 0) {
                    x.querySelectorAll("#" + propName)[0].classList.add(value.value);
                }
            }
            if (value.type == "btn_transform") {
                let propName1 = key.replace("_text_transform", "");
                if (x.querySelectorAll("#" + propName1).length > 0) {
                    x.querySelectorAll("#" + propName1)[0].classList.add(value.value);
                }
            }
            if (value.type == "btn_link") {
                let propName2 = key.replace("_link", "");
                if (x.querySelectorAll("#" + propName2).length > 0) {
                    x.querySelectorAll("#" + propName2)[0].href = value.value;
                }
            }
            if (value.type == "btn_style") {
                let propName3 = key.replace("_style", "");
                if (x.querySelectorAll("#" + propName3).length > 0) {
                    x.querySelectorAll("#" + propName3)[0].classList.add(value.value);
                }
            }
            if (value.type == "btn_size") {
                let propName4 = key.replace("_size", "");
                if (x.querySelectorAll("#" + propName4).length > 0) {
                    x.querySelectorAll("#" + propName4)[0].classList.add(value.value);
                }
            }
            if (value.type == "btn_link_target") {
                let propName5 = key.replace("_window", "");
                if (x.querySelectorAll("#" + propName5).length > 0) {
                    x.querySelectorAll("#" + propName5)[0].target = value.value;
                }
            }
            if (value.type == "btn_display") {
                if (value.value == "No") {
                    let propName6 = key.replace("_display", "");
                    if (x.querySelectorAll("#" + propName6).length > 0) {
                        x.querySelectorAll("#" + propName6)[0].remove();
                    }
                }
            }
            if (value.type == "accordion" && key != "FullAccordion") {
                // loop for accordion ittem
                let ourComponetiNString = server_.renderToStaticMarkup(/*#__PURE__*/ jsx_runtime_.jsx(ElementAccordionDisplay/* default */.Z, {
                    acValues: value.value
                }));
                if (x.querySelectorAll("#" + value.type).length > 0) {
                    x.querySelectorAll("#" + value.type)[0].innerHTML = ourComponetiNString;
                }
            }
            if (value.type == "side_change" && key == "Sidechange") {
                x.querySelectorAll("#left-section")[0].classList.remove("lg:order-2");
                x.querySelectorAll("#left-section")[0].classList.remove("lg:order-1");
                x.querySelectorAll("#right-section")[0].classList.remove("lg:order-2");
                x.querySelectorAll("#right-section")[0].classList.remove("lg:order-1");
                x.querySelectorAll("#left-section")[0].classList.add(value.value.left ?? "lg:order-1");
                x.querySelectorAll("#right-section")[0].classList.add(value.value.right ?? "lg:order-2");
            //             console.log(value);
            }
            if (value.type == "carousel") {
                if (window.location.href.includes("Page/edit") && !window.location.href.includes("Page/edit/optimize")) {
                    let showIndicators = value.value.showIndicators ?? "On";
                    let showArrow = value.value.showArrow ?? "On";
                    let showStatus = value.value.showStatus ?? "On";
                    let showThumb = value.value.showThumb ?? "On";
                    let strHTML = displayCarousel(showIndicators, showArrow, showStatus, showThumb, value.value);
                    x.querySelectorAll("#banner_display")[0].innerHTML = strHTML;
                }
            }
            if (value.type == "dynamic") {
                if (element.properties[value.type] !== undefined) {
                    let functionName = element.properties[value.type].html;
                    let strHTML1 = DynamicFunction_namespaceObject[functionName](value.value, element);
                    x.querySelectorAll("#" + element.properties[value.type].html)[0].innerHTML = strHTML1;
                // if(element.properties[value.type].html == "boximage")
                // {
                //   let strHTML = boxHTMLDisplay(value.value);
                //   x.querySelectorAll("#"+element.properties[value.type].html)[0].innerHTML = strHTML;
                // }
                // else if(element.properties[value.type].html == "multipleImages")
                // {
                //   let strHTML = multipleImages(value.value);
                //   x.querySelectorAll("#"+element.properties[value.type].html)[0].innerHTML = strHTML;
                // }
                }
            }
            if (key == "SectionImageText") {
                if (element.properties[key] !== undefined) {
                    let finalArr = value.value;
                    let classArr = [];
                    let column = 0;
                    if (!Object.keys(finalArr).includes("Right")) {
                        column = column + 1;
                    } else if (finalArr.Right.display == "Yes") {
                        column = column + 1;
                    }
                    if (!Object.keys(finalArr).includes("Center")) {
                        column = column + 1;
                    } else if (finalArr.Center.display == "Yes") {
                        column = column + 1;
                    }
                    if (!Object.keys(finalArr).includes("Left")) {
                        column = column + 1;
                    } else if (finalArr.Left.display == "Yes") {
                        column = column + 1;
                    }
                    if (column == 3) {
                        classArr = [
                            "lg:w-1/3",
                            "px-3",
                            "md:w-1/2"
                        ];
                    } else if (column == 2) {
                        classArr = [
                            "lg:w-1/2",
                            "px-3",
                            "md:w-1/2"
                        ];
                    } else if (column == 1) {
                        classArr = [];
                    }
                    // classArr = [];
                    if (Object.keys(finalArr).includes("Left")) {
                        if (finalArr.Left.display === "Yes") {
                            displayClass("sectionLeft", classArr, x);
                            displaySection(finalArr.Left, "Left", x);
                            x.querySelectorAll("#sectionLeft")[0].classList.remove("hidden");
                        } else {
                            x.querySelectorAll("#sectionLeft")[0].classList.add("hidden");
                        }
                    } else {
                        x.querySelectorAll("#sectionLeft")[0].innerHTML = '<div class="p-4 lg:p-8 flex w-full items-center"></div>';
                    }
                    if (Object.keys(finalArr).includes("Center")) {
                        if (finalArr.Center.display == "Yes") {
                            displayClass("sectionCenter", classArr, x);
                            displaySection(finalArr.Center, "Center", x);
                            x.querySelectorAll("#sectionCenter")[0].classList.remove("hidden");
                        } else {
                            x.querySelectorAll("#sectionCenter")[0].classList.add("hidden");
                        }
                    } else {
                        x.querySelectorAll("#sectionCenter")[0].innerHTML = '<div class="p-4 lg:p-8 flex w-full items-center"></div>';
                    }
                    if (Object.keys(finalArr).includes("Right")) {
                        if (finalArr.Right.display == "Yes") {
                            displayClass("sectionRight", classArr, x);
                            displaySection(finalArr.Right, "Right", x);
                            x.querySelectorAll("#sectionRight")[0].classList.remove("hidden");
                        } else {
                            x.querySelectorAll("#sectionRight")[0].classList.add("hidden");
                        }
                    } else {
                        x.querySelectorAll("#sectionRight")[0].innerHTML = '<div class="p-4 lg:p-8 flex w-full items-center"></div>';
                    }
                }
            }
        // layout
        // sidechange
        // Here we will copy all properties and write condition to display image/text
        // sequence and layout options
        });
        let imgDisplay = true;
        let textDisplay = true;
        let layoutAdjust = false;
        if (Object.keys(element.selectedVal).includes("ElementConfiguration_Image_display")) {
            if (element.selectedVal.ElementConfiguration_Image_display.value == "No") {
                imgDisplay = false;
                x.querySelectorAll("#left-section")[0].classList.add("hidden");
                x.querySelectorAll("#right-section")[0].classList.remove("lg:w-1/2");
                x.querySelectorAll("#right-section")[0].classList.remove("lg:w-3/5");
                x.querySelectorAll("#right-section")[0].classList.remove("lg:w-2/3");
                x.querySelectorAll("#right-section")[0].classList.remove("lg:w-3/4");
                x.querySelectorAll("#right-section")[0].classList.remove("lg:w-4/5");
                x.querySelectorAll("#right-section")[0].classList.remove("lg:w-5/6");
            }
        }
        if (Object.keys(element.selectedVal).includes("ElementConfiguration_Text_display")) {
            if (element.selectedVal.ElementConfiguration_Text_display.value == "No") {
                textDisplay = false;
                x.querySelectorAll("#right-section")[0].classList.add("hidden");
                removeWidthClass(x, "Left");
            }
        }
        if (textDisplay && imgDisplay) {
            //from here code is pending
            if (Object.keys(element.selectedVal).includes("ElementConfiguration_Image_position")) {
                // check if image position is Left Right
                x.querySelectorAll("#left-section")[0].classList.remove("lg:order-2");
                x.querySelectorAll("#right-section")[0].classList.remove("lg:order-1");
                x.querySelectorAll("#left-section")[0].classList.remove("lg:order-1");
                x.querySelectorAll("#right-section")[0].classList.remove("lg:order-2");
                if (element.selectedVal.ElementConfiguration_Image_position.value == "Left") {
                    layoutAdjust = true;
                    x.querySelectorAll("#left-section")[0].classList.add("lg:order-1");
                    x.querySelectorAll("#right-section")[0].classList.add("lg:order-2");
                } else if (element.selectedVal.ElementConfiguration_Image_position.value == "Right") {
                    layoutAdjust = true;
                    x.querySelectorAll("#left-section")[0].classList.add("lg:order-2");
                    x.querySelectorAll("#right-section")[0].classList.add("lg:order-1");
                } else if (element.selectedVal.ElementConfiguration_Image_position.value == "Top") {
                    x.querySelectorAll("#left-section")[0].classList.add("lg:order-2");
                    x.querySelectorAll("#right-section")[0].classList.add("lg:order-1");
                } else if (element.selectedVal.ElementConfiguration_Image_position.value == "Bottom") {
                    x.querySelectorAll("#left-section")[0].classList.add("lg:order-1");
                    x.querySelectorAll("#right-section")[0].classList.add("lg:order-2");
                }
            }
            if (layoutAdjust && Object.keys(element.selectedVal).includes("Layout")) {
                let layout = element.selectedVal.Layout;
                removeWidthClass(x);
                if (layout == "50-50") {
                    x.querySelectorAll("#left-section")[0].classList.add("lg:w-1/2");
                    x.querySelectorAll("#right-section")[0].classList.add("lg:w-1/2");
                } else if (layout == "33-66") {
                    x.querySelectorAll("#left-section")[0].classList.add("lg:w-1/3");
                    x.querySelectorAll("#right-section")[0].classList.add("lg:w-2/3");
                } else if (layout == "25-75") {
                    x.querySelectorAll("#left-section")[0].classList.add("lg:w-1/4");
                    x.querySelectorAll("#right-section")[0].classList.add("lg:w-3/4");
                }
            }
        }
    }
};
const displayCarousel = (showIndicators, showArrow, showStatus, showThumb, dataArr)=>{
    let strHTML = `<div class="carousel-root">
  <div class="carousel carousel-slider" style="width: 100%;">`;
    if (showIndicators == "On") {
        strHTML += '<ul class="control-dots">';
        if (dataArr.images != undefined && dataArr.images.length > 0) {
            dataArr.images.map((data, index)=>{
                if (index == 0) strHTML += `<li class="dot selected" role="button" tabindex="0" aria-label="slide item 1" value="0"></li>`;
                else strHTML += `<li class="dot" role="button" tabindex="0" aria-label="slide item 2" value="` + index + `"></li>`;
                strHTML += `</ul>`;
            });
        }
    }
    if (showArrow == "On") {
        strHTML += `<button type="button" aria-label="previous slide / item"
      class="control-arrow control-prev control-disabled"></button>`;
    }
    strHTML += `<div class="slider-wrapper axis-horizontal">`;
    strHTML += `<ul class="slider animated" style="transform: translate3d(0px, 0px, 0px); transition-duration: 350ms;">`;
    if (dataArr.images != undefined && dataArr.images.length > 0) {
        dataArr.images.map((data)=>{
            strHTML += `
          <li class="slide selected previous">
              <div>`;
            if (data.image_or_video == undefined || data.image_or_video == "Image") {
                strHTML += `<img src="` + data.image_url + `">`;
            } else {
                if (data.video_type == "Youtube") {
                    strHTML += `<iframe class="w-full aspect-video" src="https://www.youtube.com/embed/` + data.video_url + `?rel=0" allow="autoplay; encrypted-media" frameborder="0"></iframe>`;
                } else if (data.video_type == "Vimeo") {
                    strHTML += `<iframe class="w-full aspect-video" src="https://player.vimeo.com/video/` + data.video_url + `?background=1"></iframe>`;
                }
            }
            strHTML += `<p class="legend">` + data.headline + `</p>
              </div>
          </li>`;
        });
    }
    strHTML += `</ul>
      </div>`;
    if (showArrow == "On") {
        strHTML += `<button type="button" aria-label="next slide / item" class="control-arrow control-next"></button>`;
    }
    if (showStatus == "On") {
        strHTML += `<p class="carousel-status">1 of 3</p>`;
    }
    strHTML += `</div>`;
    if (showThumb == "On") {
        strHTML += `
              <div class="carousel">
                  <div class="thmbs-wrapper axis-vertical"><button type="button"
                          class="control-arrow control-prev control-disabled" aria-label="previous slide / item"></button>
                      <ul class="thumbs animated" style="transform: translate3d(0px, 0px, 0px); transition-duration: 350ms;">`;
        if (dataArr.images != undefined && dataArr.images.length > 0) {
            dataArr.images.map((data)=>{
                strHTML += `
                                  <li class="thumb selected" aria-label="slide item 1" style="width: 80px;" role="button" tabindex="0">
                                      <img
                                          src="` + data.image_url + `">
                                  </li>`;
            });
        }
        strHTML += `</ul><button type="button" class="control-arrow control-next control-disabled"
                          aria-label="next slide / item"></button>
                  </div>
              </div>`;
    }
    strHTML += `</div>`;
    return strHTML;
};
const displayClass = (divid, classArr, x)=>{
    x.querySelectorAll("#" + divid)[0].classList.remove("lg:w-1/3");
    x.querySelectorAll("#" + divid)[0].classList.remove("px-3");
    x.querySelectorAll("#" + divid)[0].classList.remove("md:w-1/2");
    x.querySelectorAll("#" + divid)[0].classList.remove("lg:w-1/2");
    classArr.forEach((value)=>{
        x.querySelectorAll("#" + divid)[0].classList.add(value);
    });
};
const displaySection = (obj, side, x)=>{
    let strHTML = "";
    if (obj.contentType == "Image") {
        strHTML += '<div class="flex">';
        strHTML += '<a title="' + obj.image_alt + '" href="' + obj.image_link + '" class="hrefurl no-underline">';
        strHTML += '<img class="w-full" src="' + obj.image + '" alt="' + obj.image_alt + '" title="' + obj.image_alt + '">';
        strHTML += '<div class="text-center w-full bg-gray-50">';
        if (obj.headline != "" && obj.headline != null) strHTML += '<div class="text-base font-semibold p-4">' + obj.headline + "</div>";
        strHTML += "</div>";
        //strHTML += '</div>';
        strHTML += "</a>";
        strHTML += "</div>";
    } else {
        strHTML += '<div class="p-4 lg:p-8 flex w-full items-center">';
        strHTML += '<div class="w-full">';
        strHTML += '<div class="text-sub-title">' + obj.headline + "</div>";
        strHTML += '<div class="text-default-text mt-2">' + obj.description + "</div>";
        strHTML += "</div>";
        strHTML += "</div>";
    }
    x.querySelectorAll("#section" + side)[0].innerHTML = strHTML;
};
const removeWidthClass = (x, type = "Both")=>{
    if (type == "Left" || type == "Both") {
        x.querySelectorAll("#left-section")[0].classList.remove("lg:w-1/2");
        x.querySelectorAll("#left-section")[0].classList.remove("lg:w-1/3");
        x.querySelectorAll("#left-section")[0].classList.remove("lg:w-1/4");
    }
    if (type == "Left" || type == "Both") {
        x.querySelectorAll("#right-section")[0].classList.remove("lg:w-1/2");
        x.querySelectorAll("#right-section")[0].classList.remove("lg:w-2/3");
        x.querySelectorAll("#right-section")[0].classList.remove("lg:w-3/4");
    }
};
const showMsg = ()=>{
    alert("s");
};


/***/ }),

/***/ 9510:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "N": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var _services_page_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1106);
/* harmony import */ var _services_product_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2433);
/* harmony import */ var Controllers_ProductController__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3474);
/* harmony import */ var Controllers_AppController__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(405);
/* harmony import */ var helpers_common_helper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4822);
/* harmony import */ var helpers_global_console__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3650);
/* harmony import */ var page_config__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3521);
/* harmony import */ var show_config__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2118);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_page_service__WEBPACK_IMPORTED_MODULE_0__, _services_product_service__WEBPACK_IMPORTED_MODULE_1__, Controllers_ProductController__WEBPACK_IMPORTED_MODULE_2__, Controllers_AppController__WEBPACK_IMPORTED_MODULE_3__, helpers_common_helper__WEBPACK_IMPORTED_MODULE_4__, helpers_global_console__WEBPACK_IMPORTED_MODULE_5__]);
([_services_page_service__WEBPACK_IMPORTED_MODULE_0__, _services_product_service__WEBPACK_IMPORTED_MODULE_1__, Controllers_ProductController__WEBPACK_IMPORTED_MODULE_2__, Controllers_AppController__WEBPACK_IMPORTED_MODULE_3__, helpers_common_helper__WEBPACK_IMPORTED_MODULE_4__, helpers_global_console__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const getServerSideProps = async (context)=>{
    var ref;
    const domain = (0,helpers_common_helper__WEBPACK_IMPORTED_MODULE_4__/* .domainToShow */ .M_)({
        domain: (ref = context.req) === null || ref === void 0 ? void 0 : ref.rawHeaders[1],
        showProd: page_config__WEBPACK_IMPORTED_MODULE_6__/* .__domain.isSiteLive */ .Pq.isSiteLive
    });
    let store = null;
    const { slug , slugID  } = (0,helpers_common_helper__WEBPACK_IMPORTED_MODULE_4__/* .extractSlugName */ .zL)(context.params);
    store = await Controllers_AppController__WEBPACK_IMPORTED_MODULE_3__/* .FetchStoreDetails */ .ii(domain, slug);
    if (!store) {
        (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_5__/* .highLightError */ .Eg)({
            error: "No store id found",
            component: "D:AAASNext_RedefineCommerceFrontWebsrcpages[slug]getServerSideProps.ts"
        });
    }
    const { data  } = await (0,_services_page_service__WEBPACK_IMPORTED_MODULE_0__/* .getPageType */ .C)({
        store_id: (store === null || store === void 0 ? void 0 : store.storeId) || 0,
        slug
    });
    if (data === null) {
        throw new Error("No Store-Id found");
    }
    let components = null;
    const pageType = data.data.type;
    let pageData = null;
    let seo = null;
    ////////////////////////////////////////////////
    /////////// Page Type Checks
    ////////////////////////////////////////////////
    if (pageType === "topic") {
        var ref1;
        pageData = {};
        pageData["seDescription"] = (ref1 = data.data) === null || ref1 === void 0 ? void 0 : ref1.meta_description;
        pageData["seKeyWords"] = data.data.meta_keywords;
        pageData["seTitle"] = data.data.meta_title;
        pageData["id"] = data.data.id;
        components = await (0,_services_page_service__WEBPACK_IMPORTED_MODULE_0__/* .getPageComponents */ .e)({
            page_id: data.data.id
        });
        pageData["components"] = components === null || components === void 0 ? void 0 : components.data;
    }
    if (pageType === "product") {
        pageData = await (0,Controllers_ProductController__WEBPACK_IMPORTED_MODULE_2__/* .getProductDetailProps */ .Y)({
            storeId: store === null || store === void 0 ? void 0 : store.storeId,
            seName: slug,
            isAttributeSaparateProduct: store.isAttributeSaparateProduct
        });
        (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_5__/* .conditionalLog */ .wH)({
            show: show_config__WEBPACK_IMPORTED_MODULE_7__/* ._showConsoles.productDetails */ .YH.productDetails,
            data: pageData,
            name: show_config__WEBPACK_IMPORTED_MODULE_7__/* .__fileNames.productDetails */ .eg.productDetails,
            type: "FUNCTION"
        });
    }
    if ("brand,category".includes(pageType)) {
        const seo1 = await (0,_services_product_service__WEBPACK_IMPORTED_MODULE_1__/* .FetchBrandProductList */ .wJ)({
            storeId: (store === null || store === void 0 ? void 0 : store.storeId) || 0,
            seName: slug
        });
        let filterOptionforfaceteds = [];
        if (slugID) {
            // @ts-ignore: Unreachable code error
            const keys = context.params.slug.split(",");
            const values = slugID[0].split(",");
            keys.forEach((res, index)=>values[index].split("~").forEach((val)=>{
                    filterOptionforfaceteds.push({
                        name: res,
                        value: val
                    });
                }));
        }
        let product = [];
        const filter = {
            storeID: (store === null || store === void 0 ? void 0 : store.storeId) || 0,
            brandId: data.data.id,
            customerId: 0,
            filterOptionforfaceteds: filterOptionforfaceteds
        };
        const BrandFilt = await (0,_services_product_service__WEBPACK_IMPORTED_MODULE_1__/* .FetchFiltersJsonByBrand */ ._7)(filter);
        const _filters = [];
        for(const key in BrandFilt){
            const element = BrandFilt[key];
            if (element.length > 0 && key !== "getlAllProductList") {
                _filters.push({
                    label: element[0].label || "",
                    options: element
                });
            } else if (key === "getlAllProductList") {
                product = element;
            }
        }
        const page = {};
        pageData = {};
        page["brandId"] = data.data.id;
        page["seo"] = seo1;
        page["filters"] = _filters;
        page["product"] = product;
        page["checkedFilters"] = filterOptionforfaceteds;
        pageData = page;
    }
    return {
        props: {
            pageType,
            pageData,
            slug
        }
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3474:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Y": () => (/* binding */ getProductDetailProps)
/* harmony export */ });
/* unused harmony export FetchProductDetails */
/* harmony import */ var helpers_global_console__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3650);
/* harmony import */ var services_product_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2433);
/* harmony import */ var show_config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2118);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([helpers_global_console__WEBPACK_IMPORTED_MODULE_0__, services_product_service__WEBPACK_IMPORTED_MODULE_1__]);
([helpers_global_console__WEBPACK_IMPORTED_MODULE_0__, services_product_service__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



const getProductDetailProps = async (payload)=>{
    return await FetchProductDetails(payload);
};
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////// SERVER SIDE FUNCTIONS ---------------------------------------
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
const FetchProductDetails = async (payload)=>{
    let productColors = null;
    let productDetails = null;
    let productSizeChart = null;
    let productDiscountTablePrices = null;
    let productSEOtags = null;
    let productsAlike = null;
    let productInventoryList = null;
    let doNotExist = null;
    // let productReviews: null;
    // let productAlikes: null;
    try {
        // Request - 1
        productDetails = await (0,services_product_service__WEBPACK_IMPORTED_MODULE_1__/* .FetchProductById */ .f)({
            seName: payload.seName,
            storeId: payload.storeId,
            productId: 0
        });
        if ((productDetails === null || productDetails === void 0 ? void 0 : productDetails.id) === null) {
            doNotExist = productDetails.productDoNotExist;
            productDetails = null;
        }
        if (productDetails === null || productDetails === void 0 ? void 0 : productDetails.id) {
            // Request - 2,3,4,5
            await Promise.allSettled([
                (0,services_product_service__WEBPACK_IMPORTED_MODULE_1__/* .FetchColors */ .jW)({
                    productId: productDetails.id,
                    storeId: payload.storeId,
                    isAttributeSaparateProduct: payload.isAttributeSaparateProduct
                }),
                (0,services_product_service__WEBPACK_IMPORTED_MODULE_1__/* .FetchSizeChartById */ .eB)(productDetails.id),
                (0,services_product_service__WEBPACK_IMPORTED_MODULE_1__/* .FetchDiscountTablePrices */ .e_)({
                    seName: payload.seName,
                    storeId: payload.storeId,
                    customerId: 28,
                    attributeOptionId: 1380
                }),
                (0,services_product_service__WEBPACK_IMPORTED_MODULE_1__/* .FetchProductSEOtags */ .Ie)({
                    seName: payload.seName,
                    storeId: payload.storeId
                }),
                (0,services_product_service__WEBPACK_IMPORTED_MODULE_1__/* .FetchSimilartProducts */ .lA)({
                    productId: productDetails.id,
                    storeId: payload.storeId
                }), 
            ]).then((values)=>{
                (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_0__/* .conditionalLog */ .wH)({
                    data: values,
                    type: "CONTROLLER",
                    name: show_config__WEBPACK_IMPORTED_MODULE_2__/* .__fileNames.productDetails */ .eg.productDetails,
                    show: show_config__WEBPACK_IMPORTED_MODULE_2__/* ._showConsoles.productDetails */ .YH.productDetails
                });
                productColors = values[0].status === "fulfilled" ? values[0].value : null;
                productSizeChart = values[1].status === "fulfilled" ? values[1].value : null;
                productDiscountTablePrices = values[2].status === "fulfilled" ? values[2].value : null;
                productSEOtags = values[3].status === "fulfilled" ? values[3].value : null;
                productsAlike = values[4].status === "fulfilled" ? values[4].value : null;
            });
            // Request - 6
            if (productColors !== null) {
                productColors;
                const allColorAttributes = productColors.map((color)=>color.attributeOptionId);
                productInventoryList = await (0,services_product_service__WEBPACK_IMPORTED_MODULE_1__/* .FetchInventoryById */ .oe)({
                    productId: productDetails.id,
                    attributeOptionId: allColorAttributes
                });
            }
        }
        // Request - 7
        // await  ---> Fetch Product Reviews
        (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_0__/* .conditionalLog */ .wH)({
            data: {
                details: productDetails,
                colors: productColors,
                sizes: productSizeChart,
                discount: productDiscountTablePrices,
                SEO: productSEOtags,
                inventory: productInventoryList,
                doNotExist: doNotExist,
                alike: productsAlike
            },
            type: "CONTROLLER",
            name: show_config__WEBPACK_IMPORTED_MODULE_2__/* .__fileNames.productDetails */ .eg.productDetails,
            show: show_config__WEBPACK_IMPORTED_MODULE_2__/* ._showConsoles.productDetails */ .YH.productDetails
        });
    } catch (error) {
        (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_0__/* .highLightError */ .Eg)({
            error,
            component: `Product Controller`
        });
    }
    return {
        doNotExist: doNotExist,
        details: productDetails,
        colors: productColors,
        sizes: productSizeChart,
        discount: productDiscountTablePrices,
        SEO: productSEOtags,
        inventory: productInventoryList,
        alike: productsAlike
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5140:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export getServerSideProps */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var Components_Home_ElementAccordionDisplay__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5788);
/* harmony import */ var Components_Home_ElementCarouselDisplay__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5827);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6183);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _Components_Home_Helper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6637);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_3__]);
hooks__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
//import React, { useState, useEffect, useRef } from "react";






const Home = (props)=>{
    var ref, ref1;
    const storeId = (0,hooks__WEBPACK_IMPORTED_MODULE_3__/* .useTypedSelector */ .ix)((state)=>state.store.id);
    const slug = (ref = props.props) === null || ref === void 0 ? void 0 : ref.slug;
    const pageData = (ref1 = props.props) === null || ref1 === void 0 ? void 0 : ref1.pageData;
    const { 0: componentHtml , 1: setComponentHtml  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)([]);
    // const pathArray = document.location.pathname.split('/');
    // const slug = pathArray.at(-1);
    // const [pageData, setPageData] = useState([]);
    // const [componentHtml, setComponentHtml] = useState([]);
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        // let pageId = pageData.id;
        document.title = pageData === null || pageData === void 0 ? void 0 : pageData.seTitle;
        if (pageData !== undefined) {
            setComponentHtml(pageData === null || pageData === void 0 ? void 0 : pageData.components);
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    // const getPageData = (pageId) => {
    //   const requestOptions = {
    //     method: 'POST',
    //     headers: { 'Content-Type': 'application/json' },u
    //     body: {}
    //   };
    //   fetch(
    //     `https://www.redefinecommerce.net/API/api/topics/${pageId}`,
    //     requestOptions,
    //   )
    //     .then((response) => response.json())
    //     .then((data) => {
    //       if (data.success) {
    //          setPageData(data.data);
    //       }
    //     });
    //}
    const loadBackgroundDefault = (element)=>{
        if (element.selectedVal != undefined) {
            if (Object.keys(element.selectedVal).length > 0) {
                const bgPropertyName = Object.keys(element.properties).find((key)=>element.properties[key] === "background");
                const attributes = Object.entries(element.selectedVal).map(([key, value])=>{
                    if (key == bgPropertyName) return value;
                })[0];
                if (attributes != undefined && Object.keys(attributes).length > 0) {
                    if (attributes.type == "color") {
                        return attributes.value;
                    } else if (attributes.type == "image") {
                        return 'url("' + attributes.value + '")';
                    } else if (attributes.type == "none") {
                        return "none";
                    }
                }
            }
            return "none";
        }
        return "none";
    };
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        componentHtml.map((element, index)=>{
            //let x = ReactDOM.findDOMNode(refArray.current[element.uid]);
            //  x.querySelectorAll('#div'+element.no)[0].innerHTML = element.uid;
            _Components_Home_Helper__WEBPACK_IMPORTED_MODULE_5__/* .updateSetProperties */ .ts(element, index);
        });
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        componentHtml
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
                    children: pageData.components.length > 0 ? pageData.components.map((componentValue, index)=>{
                        const backgroundDefault = loadBackgroundDefault(componentValue);
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: `commondiv ${componentValue.visibility == "off" ? "hidden" : ""}`,
                            style: {
                                background: backgroundDefault
                            },
                            id: `div${componentValue.no}`,
                            children: Object.keys(componentValue.selectedVal).includes("carousel") ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_Home_ElementCarouselDisplay__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    bannerArr: componentValue.selectedVal.carousel.value
                                })
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                                    class: "mainsection container mx-auto mt-20",
                                    children: Object.keys(componentValue.selectedVal).includes("FullAccordion") ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                            class: "mt-4 w-full",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_Home_ElementAccordionDisplay__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                acValues: componentValue.selectedVal.FullAccordion.value
                                            })
                                        })
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "commondiv",
                                            dangerouslySetInnerHTML: {
                                                __html: componentValue.html
                                            }
                                        })
                                    })
                                })
                            })
                        }, index);
                    // return <div key={index} className="text-center p-5 border my-2" dangerouslySetInnerHTML={{ __html: comphtml }}></div>
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                            classname: "mainsection taillwind_content_block_22"
                        })
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                id: "wrapperloading",
                style: {
                    position: "fixed",
                    "z-index": "10000000"
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    id: "loading"
                })
            })
        ]
    });
};
const getServerSideProps = ()=>{
    return {
        props: {
            title: "Vikas"
        }
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Home);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1106:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C": () => (/* binding */ getPageType),
/* harmony export */   "e": () => (/* binding */ getPageComponents)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var helpers_global_console__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3650);
/* harmony import */ var show_config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2118);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__, helpers_global_console__WEBPACK_IMPORTED_MODULE_1__]);
([axios__WEBPACK_IMPORTED_MODULE_0__, helpers_global_console__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



const getPageType = async (Req)=>{
    const url = "https://www.redefinecommerce.net/API/api/front/get-page-type";
    try {
        const page = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(url, Req);
        (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_1__/* .conditionalLog */ .wH)({
            data: page.data,
            name: "getPageType",
            type: "API",
            show: page.data === null
        });
        return page;
    } catch (error) {
        const page1 = {
            data: null
        };
        (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_1__/* .conditionalLog */ .wH)({
            data: error,
            name: "getPageType",
            type: "API",
            show: show_config__WEBPACK_IMPORTED_MODULE_2__/* ._showConsoles.services.productDetails */ .YH.services.productDetails,
            error: true
        });
        return page1;
    }
};
const getPageComponents = async (Req)=>{
    const url = `https://www.redefinecommerce.net/API/api/front/topic/component/get/${Req.page_id}`;
    const page = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].get(url);
    return page;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;