"use strict";
exports.id = 4253;
exports.ids = [4253];
exports.modules = {

/***/ 8689:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var constants_validationMessages__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4108);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var services_address_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3411);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([services_address_service__WEBPACK_IMPORTED_MODULE_4__]);
services_address_service__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const AddAddress = ({ closePopupHandler , submitHandler , editData  })=>{
    const { 0: country , 1: setCountry  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
    const { 0: state , 1: setState  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
    const { 0: initialValues , 1: setInitialValues  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({
        firstname: "",
        lastName: "",
        email: "",
        address1: "",
        address2: "",
        suite: "",
        city: "",
        state: "",
        postalCode: "",
        phone: "",
        fax: "",
        countryName: "",
        isDefault: false,
        companyName: ""
    });
    const validationSchema = yup__WEBPACK_IMPORTED_MODULE_5__.object().shape({
        firstname: yup__WEBPACK_IMPORTED_MODULE_5__.string().required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_1__/* .addressMessages.firstName.required */ .zh.firstName.required),
        lastName: yup__WEBPACK_IMPORTED_MODULE_5__.string().required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_1__/* .addressMessages.lastName.required */ .zh.lastName.required),
        email: yup__WEBPACK_IMPORTED_MODULE_5__.string().email().required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_1__/* .addressMessages.email.required */ .zh.email.required),
        address1: yup__WEBPACK_IMPORTED_MODULE_5__.string().required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_1__/* .addressMessages.address1.required */ .zh.address1.required),
        city: yup__WEBPACK_IMPORTED_MODULE_5__.string().required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_1__/* .addressMessages.city.required */ .zh.city.required),
        state: yup__WEBPACK_IMPORTED_MODULE_5__.string().required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_1__/* .addressMessages.state.required */ .zh.state.required),
        postalCode: yup__WEBPACK_IMPORTED_MODULE_5__.string().required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_1__/* .addressMessages.postalCode.required */ .zh.postalCode.required),
        phone: yup__WEBPACK_IMPORTED_MODULE_5__.string().required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_1__/* .addressMessages.phone.required */ .zh.phone.required),
        fax: yup__WEBPACK_IMPORTED_MODULE_5__.string().required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_1__/* .addressMessages.fax.required */ .zh.fax.required),
        countryName: yup__WEBPACK_IMPORTED_MODULE_5__.string().required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_1__/* .addressMessages.countryName.required */ .zh.countryName.required),
        companyName: yup__WEBPACK_IMPORTED_MODULE_5__.string().required(constants_validationMessages__WEBPACK_IMPORTED_MODULE_1__/* .addressMessages.companyName.required */ .zh.companyName.required)
    });
    const loadState = async (countryName)=>{
        const id = country.find((res)=>res.name.toLowerCase() === countryName.toLowerCase());
        if (id) {
            const state = await (0,services_address_service__WEBPACK_IMPORTED_MODULE_4__/* .getStatesList */ .yU)(id.id);
            setState(state);
            return state;
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        if (editData && country.length > 0) {
            loadState(editData.countryName).then(()=>{
                setInitialValues({
                    firstname: editData.firstname,
                    lastName: editData.lastName,
                    email: editData.email,
                    address1: editData.address1,
                    address2: editData.address2,
                    suite: editData.suite,
                    city: editData.city,
                    state: editData.state,
                    postalCode: editData.postalCode,
                    phone: editData.phone,
                    fax: editData.fax,
                    countryName: editData.countryName,
                    isDefault: editData.isDefault,
                    companyName: editData.companyName
                });
            });
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        editData,
        country
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        (0,services_address_service__WEBPACK_IMPORTED_MODULE_4__/* .getCountryList */ .Jp)().then((res)=>setCountry(res));
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        id: "AddNewAddress",
        "aria-hidden": "true",
        className: "overflow-y-auto overflow-x-hidden fixed inset-0 z-50 justify-center items-center h-modal max-h-screen",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-full h-full bg-black bg-opacity-50 flex items-center justify-center",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "relative w-full max-w-2xl",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "relative bg-white rounded-lg shadow max-h-screen overflow-y-auto",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex justify-between items-start p-4 rounded-t border-b dark:border-gray-600",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    className: "text-xl font-semibold text-gray-900 dark:text-white",
                                    children: "Add New Address"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    type: "button",
                                    className: "text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-600 dark:hover:text-white",
                                    "data-modal-toggle": "AddNewAddress",
                                    onClick: closePopupHandler,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                        className: "w-5 h-5",
                                        fill: "currentColor",
                                        viewBox: "0 0 20 20",
                                        xmlns: "http://www.w3.org/2000/svg",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                            fillRule: "evenodd",
                                            d: "M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z",
                                            clipRule: "evenodd"
                                        })
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_2__.Formik, {
                            onSubmit: submitHandler,
                            validationSchema: validationSchema,
                            initialValues: initialValues,
                            enableReinitialize: true,
                            children: ({ errors , touched , values , handleChange , handleBlur , handleSubmit , submitForm , setFieldValue ,  })=>{
                                /*#__PURE__*/ return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "p-6 space-y-6",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                                className: "mt-4 sm:max-w-2xl",
                                                onSubmit: handleSubmit,
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("fieldset", {
                                                        className: "w-full",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                className: "text-base",
                                                                children: "Country"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "relative mt-2",
                                                                children: [
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                                        id: "country",
                                                                        name: "countryName",
                                                                        autoComplete: "country-name",
                                                                        className: "form-input",
                                                                        value: values.countryName,
                                                                        onChange: (e)=>{
                                                                            handleChange(e);
                                                                            loadState(e.target.value);
                                                                        },
                                                                        onBlur: handleBlur,
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                                children: "Select Country"
                                                                            }),
                                                                            country.map((res, index)=>{
                                                                                /*#__PURE__*/ return react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                                    children: res === null || res === void 0 ? void 0 : res.name
                                                                                }, index);
                                                                            })
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "text-red-500 text-s mt-1",
                                                                        children: touched.countryName && errors.countryName
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "mt-4 grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "sm:col-span-3",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                        htmlFor: "city",
                                                                        className: "block text-base",
                                                                        children: "First Name"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "mt-1",
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                            value: values.firstname,
                                                                            name: "firstname",
                                                                            id: "firstname",
                                                                            className: "form-input",
                                                                            onChange: handleChange,
                                                                            onBlur: handleBlur
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "text-red-500 text-s mt-1",
                                                                        children: touched.firstname && errors.firstname
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "sm:col-span-3",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                        htmlFor: "region",
                                                                        className: "block text-base",
                                                                        children: "Last Name"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "mt-1",
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                            name: "lastName",
                                                                            id: "region",
                                                                            className: "form-input",
                                                                            value: values.lastName,
                                                                            onChange: handleChange,
                                                                            onBlur: handleBlur
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "text-red-500 text-s mt-1",
                                                                        children: touched.lastName && errors.lastName
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("fieldset", {
                                                        className: "w-full mt-4",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "street-address",
                                                                className: "text-base",
                                                                children: "Email"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "mt-2 mb-2",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    id: "street-address",
                                                                    name: "email",
                                                                    value: values.email,
                                                                    autoComplete: "street-address",
                                                                    placeholder: "Email",
                                                                    className: "form-input",
                                                                    onChange: handleChange,
                                                                    onBlur: handleBlur
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "text-red-500 text-s mt-1",
                                                                children: touched.email && errors.email
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("fieldset", {
                                                        className: "w-full mt-4",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "street-address",
                                                                className: "text-base",
                                                                children: "Street Address"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "mt-2 mb-2",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    id: "street-address",
                                                                    name: "address1",
                                                                    value: values.address1,
                                                                    autoComplete: "street-address",
                                                                    placeholder: "Street Address",
                                                                    className: "form-input",
                                                                    onChange: handleChange,
                                                                    onBlur: handleBlur
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "text-red-500 text-s mt-1",
                                                                children: touched.address1 && errors.address1
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "text-indigo-600 mt-2 mb-2",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                            title: "Add Address Line 2",
                                                            children: "+ Add Address Line 2"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("fieldset", {
                                                        className: "w-full mt-4",
                                                        style: {
                                                            display: "none"
                                                        },
                                                        id: "AddAddressLine",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "street-address",
                                                                className: "text-base",
                                                                children: "Street Address"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "mt-2",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    id: "street-address",
                                                                    name: "street-address",
                                                                    autoComplete: "street-address",
                                                                    placeholder: "Street Address",
                                                                    className: "form-input"
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("fieldset", {
                                                        className: "w-full mt-4",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "Apt-suit",
                                                                className: "text-base",
                                                                children: "Apt/Suit/Other(optional)"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "mt-2",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    id: "Apt-suit",
                                                                    name: "suite",
                                                                    value: values.suite,
                                                                    autoComplete: "Apt-suit",
                                                                    placeholder: "Apt/Suit/Other(optional)",
                                                                    className: "form-input",
                                                                    onChange: handleChange,
                                                                    onBlur: handleBlur
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "text-red-500 text-s mt-1",
                                                                children: touched.suite && errors.suite
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "mt-4 grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "sm:col-span-3",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                        htmlFor: "Zip-code",
                                                                        className: "text-base",
                                                                        children: "Zip Code"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "mt-1",
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                            id: "Zip-code",
                                                                            name: "postalCode",
                                                                            autoComplete: "Zip-code",
                                                                            value: values.postalCode,
                                                                            placeholder: "Zip Code",
                                                                            className: "form-input",
                                                                            onChange: handleChange,
                                                                            onBlur: handleBlur
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "text-red-500 text-s mt-1",
                                                                        children: touched.postalCode && errors.postalCode
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "sm:col-span-3",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                        htmlFor: "Phone Number",
                                                                        className: "text-base",
                                                                        children: "Company Name"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "mt-1",
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                            id: "Phone Number",
                                                                            name: "companyName",
                                                                            autoComplete: "Phone Number",
                                                                            placeholder: "1-(000)-000-0000",
                                                                            value: values.companyName,
                                                                            className: "form-input",
                                                                            onChange: handleChange,
                                                                            onBlur: handleBlur
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "text-red-500 text-s mt-1",
                                                                        children: touched.phone && errors.phone
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "mt-4 grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "sm:col-span-3",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                        htmlFor: "Phone Number",
                                                                        className: "text-base",
                                                                        children: "Phone Number"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "mt-1",
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                            id: "Phone Number",
                                                                            name: "phone",
                                                                            autoComplete: "Phone Number",
                                                                            placeholder: "1-(000)-000-0000",
                                                                            value: values.phone,
                                                                            className: "form-input",
                                                                            onChange: handleChange,
                                                                            onBlur: handleBlur
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "text-red-500 text-s mt-1",
                                                                        children: touched.phone && errors.phone
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "sm:col-span-3",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                        htmlFor: "region",
                                                                        className: "block text-base",
                                                                        children: "Fax"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "mt-1",
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                            name: "fax",
                                                                            id: "region",
                                                                            className: "form-input",
                                                                            onChange: handleChange,
                                                                            value: values.fax,
                                                                            onBlur: handleBlur
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "text-red-500 text-s mt-1",
                                                                        children: touched.fax && errors.fax
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "mt-4 grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "sm:col-span-3",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                        htmlFor: "city",
                                                                        className: "block text-base",
                                                                        children: "City"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "mt-1",
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                            name: "city",
                                                                            value: values.city,
                                                                            id: "city",
                                                                            className: "form-input",
                                                                            onChange: handleChange,
                                                                            onBlur: handleBlur
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "text-red-500 text-s mt-1",
                                                                        children: touched.city && errors.city
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "sm:col-span-3",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                        htmlFor: "region",
                                                                        className: "block text-base",
                                                                        children: "State / Province"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "mt-1",
                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                                            id: "state",
                                                                            name: "state",
                                                                            autoComplete: "country-name",
                                                                            className: "form-input",
                                                                            onChange: handleChange,
                                                                            onBlur: handleBlur,
                                                                            value: values.state,
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                                    children: "Select State"
                                                                                }),
                                                                                state.map((res, index)=>{
                                                                                    /*#__PURE__*/ return react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                                        children: res === null || res === void 0 ? void 0 : res.name
                                                                                    }, index);
                                                                                })
                                                                            ]
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "text-red-500 text-s mt-1",
                                                                        children: touched.state && errors.state
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "mt-4",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                            className: "block text-base",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    type: "checkbox",
                                                                    checked: values.isDefault,
                                                                    onChange: (e)=>setFieldValue("isDefault", e.target.checked)
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    className: "ml-1 text-base",
                                                                    children: "Set as default"
                                                                })
                                                            ]
                                                        })
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex items-center justify-between p-6 space-x-2 rounded-b border-t border-gray-200 dark:border-gray-600",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    "data-modal-toggle": "AddNewAddress",
                                                    className: "btn btn-outline-primary",
                                                    onClick: closePopupHandler,
                                                    children: "Cancel"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    "data-modal-toggle": "AddNewAddress",
                                                    onClick: submitForm,
                                                    className: "btn btn-primary",
                                                    children: "Save"
                                                })
                                            ]
                                        })
                                    ]
                                });
                            }
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AddAddress);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8443:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

/* harmony default export */ async function __WEBPACK_DEFAULT_EXPORT__() {
    const { data: location  } = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].get("https://geolocation-db.com/json/");
    return location;
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3411:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Jp": () => (/* binding */ getCountryList),
/* harmony export */   "VR": () => (/* binding */ deleteCustomerAddress),
/* harmony export */   "ap": () => (/* binding */ udpateIsDefaultAddress),
/* harmony export */   "cX": () => (/* binding */ CreateUserAddress),
/* harmony export */   "yE": () => (/* binding */ UpdateUserAddress),
/* harmony export */   "yU": () => (/* binding */ getStatesList)
/* harmony export */ });
/* harmony import */ var _utils_axios_util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(795);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__]);
_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const CreateUserAddress = async (request)=>{
    const url = `/StoreCustomer/storecustomercreateaddress.json`;
    const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__/* .SendAsyncV2 */ .y)({
        url: url,
        method: "POST",
        data: request
    });
    return res;
};
const getCountryList = async ()=>{
    const url = "/StoreCustomer/getcustomercountry.json";
    const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__/* .SendAsyncV2 */ .y)({
        url: url,
        method: "POST"
    });
    return res.data;
};
const getStatesList = async (id)=>{
    const url = `/StoreCustomer/getcustomerstatebycountryid/${id}.json`;
    const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__/* .SendAsyncV2 */ .y)({
        url: url,
        method: "GET"
    });
    return res.data;
};
const udpateIsDefaultAddress = async (payload)=>{
    const url = "/StoreCustomer/setcustomeraddressdefault.json";
    const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__/* .SendAsyncV2 */ .y)({
        url: url,
        method: "POST",
        data: payload
    });
    return res.data;
};
const UpdateUserAddress = async (request)=>{
    const url = `/StoreCustomer/updatestorecustomeraddress.json`;
    const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__/* .SendAsyncV2 */ .y)({
        url: url,
        method: "POST",
        data: request
    });
    return res;
};
const deleteCustomerAddress = async (request)=>{
    const url = "/StoreCustomer/deletestorecustomeraddress.json";
    const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__/* .SendAsyncV2 */ .y)({
        url: url,
        method: "POST",
        data: request
    });
    return res;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;