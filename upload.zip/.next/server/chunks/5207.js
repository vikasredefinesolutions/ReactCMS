"use strict";
exports.id = 5207;
exports.ids = [5207];
exports.modules = {

/***/ 5207:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_FilterBar_layout3__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2289);
/* harmony import */ var _components_Filters_Layout3__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5202);
/* harmony import */ var _components_PorudctComponent_Product_layout2__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(39);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_PorudctComponent_Product_layout2__WEBPACK_IMPORTED_MODULE_3__]);
_components_PorudctComponent_Product_layout2__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const Layout3 = ({ filters , products , checkedFilters , totalCount , showFilter , showSortMenu , productView , skuList , setShowSortMenu , setShowFilter , setProductView , colorChangeHandler , handleChange , loadMore , sortProductJson , clearFilters , compareCheckBoxHandler  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        id: "",
        className: "",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "container mx-auto",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "bg-white",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex flex-wrap -mx-3",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-full md:w-3/12 px-3 lg:w-2/12",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                    className: "md:!hidden btn btn-lg btn-secondary !py-2 !flex w-full items-center justify-between",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "",
                                            children: "Filter"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "toggleicon",
                                            children: "-"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Filters_Layout3__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                    filters: filters,
                                    handleChange: handleChange,
                                    checkedFilters: checkedFilters
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-full md:w-9/12 px-3 lg:w-10/12",
                            "x-data": "{ selected : 1 }",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FilterBar_layout3__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                    totalCount,
                                    showSortMenu,
                                    sortProductJson,
                                    sortOpenHandler: setShowSortMenu,
                                    setProductView,
                                    productView,
                                    setShowFilter
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    "aria-labelledby": "products-heading",
                                    className: "mt-8",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "mt-8 relative gridlistview",
                                        id: "gridview",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "relative w-full pb-6 -mb-6",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                                    role: "list",
                                                    className: productView === "grid" ? "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 mb-8" : "m-0 p-0 list-none",
                                                    children: products.map((product, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_PorudctComponent_Product_layout2__WEBPACK_IMPORTED_MODULE_3__["default"], {
                                                            productView: productView,
                                                            skuList: skuList,
                                                            compareCheckBoxHandler: compareCheckBoxHandler,
                                                            product: product,
                                                            colorChangeHandler: colorChangeHandler
                                                        }, index))
                                                })
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "py-20 border-t border-t-gray-300 text-center",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "mb-8",
                                                        children: [
                                                            "You've seen ",
                                                            products.length,
                                                            " Products out of ",
                                                            totalCount
                                                        ]
                                                    }),
                                                    totalCount > products.length && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        type: "submit",
                                                        onClick: loadMore,
                                                        className: "btn btn-lg btn-secondary",
                                                        children: "View More"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout3);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;