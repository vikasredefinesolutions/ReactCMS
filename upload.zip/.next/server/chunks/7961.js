"use strict";
exports.id = 7961;
exports.ids = [7961];
exports.modules = {

/***/ 7961:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ properties)
/* harmony export */ });
const properties = {
    breadcrumb: {
        position: "Left",
        bg_color: "#4e4e4e",
        hover_bg_color: "#4e4e4e",
        text_color: "#g4g4g4",
        hover_text_color: "#4e4e4e"
    },
    banner_box_top: {
        html: "<div>Entire HTML goes Here</div>"
    },
    banner: {
        type: "type1"
    },
    banner_box_bottom: {
        html: "<div>Entire HTML goes Here</div>"
    },
    filter_box: {
        layout: "sidefilter"
    },
    result_box: {
        layout: "unset",
        showGrid: false
    },
    product_list_box: {
        box_count: 3,
        column_select: 4,
        alignment: "Center",
        product_info: {
            brand: true,
            product_name: {
                display: true,
                font_size: "small",
                text_style: "normal",
                color: "#4e4e4e"
            },
            price: true,
            color: {
                display: false,
                view_option: "rounded / square"
            },
            short_description: {
                display: true,
                font_size: "small",
                text_style: "normal"
            },
            product_rating: true
        },
        availability: true,
        add_to_cart: true,
        tags: false
    }
};


/***/ })

};
;