"use strict";
exports.id = 6183;
exports.ids = [6183];
exports.modules = {

/***/ 6183:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "dz": () => (/* binding */ useWindowDimensions),
/* harmony export */   "ix": () => (/* binding */ useTypedSelector),
/* harmony export */   "ol": () => (/* binding */ useActions)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _redux_actions_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9686);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_redux_actions_redux__WEBPACK_IMPORTED_MODULE_3__]);
_redux_actions_redux__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


// eslint-disable-next-line import/named


// Use throughout your app instead of plain `useDispatch` and `useSelector`
const useActions = ()=>{
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useDispatch)();
    return (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.bindActionCreators)(_redux_actions_redux__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, dispatch);
};
const useTypedSelector = react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector;
function getWindowDimensions() {
    let height = 1920;
    let width = 1080;
    if (false) {}
    return {
        width,
        height
    };
}
function useWindowDimensions() {
    const { 0: windowDimensions , 1: setWindowDimensions  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(getWindowDimensions());
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        function handleResize() {
            setWindowDimensions(getWindowDimensions());
        }
        window.addEventListener("resize", handleResize);
        return ()=>window.removeEventListener("resize", handleResize);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    return windowDimensions;
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5704:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": () => (/* binding */ showComponents)
/* harmony export */ });
const showComponents = {
    header: {
        notification: false,
        breadCrumb: true,
        searchBar: true
    },
    page: {
        product: {
            similarProducts: true,
            reviews: true
        }
    },
    footer: {
        links: true,
        acceptablePayments: true,
        donation: true
    }
};


/***/ }),

/***/ 9686:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _asyncActions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(911);
/* harmony import */ var _slices_cart_slice__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9424);
/* harmony import */ var _slices_compare_slice__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3002);
/* harmony import */ var _slices_home_slice__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5578);
/* harmony import */ var _slices_loader_slice__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6813);
/* harmony import */ var _slices_modals_slice__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7454);
/* harmony import */ var _slices_product_slice__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8377);
/* harmony import */ var _slices_redefineStore_slice__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2328);
/* harmony import */ var _slices_success_slice__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4011);
/* harmony import */ var _slices_user_slice__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3754);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_asyncActions__WEBPACK_IMPORTED_MODULE_0__, _slices_cart_slice__WEBPACK_IMPORTED_MODULE_1__, _slices_redefineStore_slice__WEBPACK_IMPORTED_MODULE_7__, _slices_user_slice__WEBPACK_IMPORTED_MODULE_9__]);
([_asyncActions__WEBPACK_IMPORTED_MODULE_0__, _slices_cart_slice__WEBPACK_IMPORTED_MODULE_1__, _slices_redefineStore_slice__WEBPACK_IMPORTED_MODULE_7__, _slices_user_slice__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const actions = {
    ..._slices_redefineStore_slice__WEBPACK_IMPORTED_MODULE_7__/* .redefineStoreActions */ .d,
    ..._slices_product_slice__WEBPACK_IMPORTED_MODULE_6__/* .productActions */ .Jh,
    ..._asyncActions__WEBPACK_IMPORTED_MODULE_0__/* .allAsyncActions */ .n,
    ..._slices_user_slice__WEBPACK_IMPORTED_MODULE_9__/* .userActions */ .hI,
    ..._slices_cart_slice__WEBPACK_IMPORTED_MODULE_1__/* .storeActions */ .Tt,
    ..._slices_modals_slice__WEBPACK_IMPORTED_MODULE_5__/* .modalActions */ .nT,
    ..._slices_compare_slice__WEBPACK_IMPORTED_MODULE_2__/* .compareActions */ .r7,
    ..._slices_loader_slice__WEBPACK_IMPORTED_MODULE_4__/* .loaderActions */ .A,
    ..._slices_success_slice__WEBPACK_IMPORTED_MODULE_8__/* .successActions */ .Ey,
    ..._slices_home_slice__WEBPACK_IMPORTED_MODULE_3__/* .homeActions */ .q8
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (actions);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4447:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "fetchBrandList": () => (/* binding */ fetchBrandList)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var services_brand_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2449);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([services_brand_service__WEBPACK_IMPORTED_MODULE_1__]);
services_brand_service__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const fetchBrandList = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("brand/details", async (storeId)=>{
    try {
        const brand = await (0,services_brand_service__WEBPACK_IMPORTED_MODULE_1__/* .FetchBrands */ .O)(storeId);
        return brand;
    } catch (error) {
        throw new Error("No store found!!!");
    }
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7006:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddToCart": () => (/* binding */ AddToCart),
/* harmony export */   "fetchCartDetails": () => (/* binding */ fetchCartDetails)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var services_cart_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7591);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([services_cart_service__WEBPACK_IMPORTED_MODULE_1__]);
services_cart_service__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const fetchCartDetails = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("cart/details", async (customerId)=>{
    try {
        const cart = await (0,services_cart_service__WEBPACK_IMPORTED_MODULE_1__/* .fetchCart */ .x7)(customerId);
        return cart;
    } catch (error) {
        throw new Error("No Details found!!!");
    }
});
const AddToCart = async (payload)=>{
    try {
        const cart = await (0,services_cart_service__WEBPACK_IMPORTED_MODULE_1__/* .addToCart */ .Xq)(payload);
        return cart;
    } catch (error) {
        throw new Error("Try Again!!!");
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 911:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "n": () => (/* binding */ allAsyncActions)
/* harmony export */ });
/* harmony import */ var _brand_async__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4447);
/* harmony import */ var _cart_async__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7006);
/* harmony import */ var _redefineStore_async__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5660);
/* harmony import */ var _user_async__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4643);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_brand_async__WEBPACK_IMPORTED_MODULE_0__, _cart_async__WEBPACK_IMPORTED_MODULE_1__, _user_async__WEBPACK_IMPORTED_MODULE_3__]);
([_brand_async__WEBPACK_IMPORTED_MODULE_0__, _cart_async__WEBPACK_IMPORTED_MODULE_1__, _user_async__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const allAsyncActions = {
    ..._redefineStore_async__WEBPACK_IMPORTED_MODULE_2__,
    ..._brand_async__WEBPACK_IMPORTED_MODULE_0__,
    ..._user_async__WEBPACK_IMPORTED_MODULE_3__,
    ..._cart_async__WEBPACK_IMPORTED_MODULE_1__
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5660:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SetPageType": () => (/* binding */ SetPageType)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const SetPageType = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("pageType/details", (payload)=>{
    return {
        payload
    };
});


/***/ }),

/***/ 4643:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getStoreCustomer": () => (/* binding */ getStoreCustomer)
/* harmony export */ });
/* harmony import */ var services_user_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1488);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([services_user_service__WEBPACK_IMPORTED_MODULE_0__]);
services_user_service__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const getStoreCustomer = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__.createAsyncThunk)("user/details", async (customerId)=>{
    try {
        const customer = await (0,services_user_service__WEBPACK_IMPORTED_MODULE_0__/* .getStoreCustomer */ .em)(customerId);
        return customer;
    } catch (error) {
        throw new Error("No store found!!!");
    }
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9424:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tt": () => (/* binding */ storeActions),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export storeSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _asyncActions_cart_async__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7006);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_asyncActions_cart_async__WEBPACK_IMPORTED_MODULE_1__]);
_asyncActions_cart_async__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const initialState = {
    cart: []
};
const storeSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "cart",
    initialState,
    reducers: {},
    extraReducers: (builder)=>{
        builder.addCase(_asyncActions_cart_async__WEBPACK_IMPORTED_MODULE_1__.fetchCartDetails.fulfilled, (state, action)=>{
            state.cart = action.payload;
        });
    }
});
const storeActions = storeSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (storeSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3002:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "r7": () => (/* binding */ compareActions)
/* harmony export */ });
/* unused harmony export compareSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

// Define the initial state using that type
const initialState = {
    selectedImages: null
};
const compareSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "modals",
    initialState,
    reducers: {
        showCompareImage: (state, action)=>{
            const image = action.payload;
            if (state.selectedImages === null) {
                state.selectedImages = [
                    image
                ];
            }
            if (state.selectedImages !== null) {
                state.selectedImages[image.index] = image;
            }
        }
    }
});
const compareActions = compareSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (compareSlice.reducer);


/***/ }),

/***/ 5578:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "q8": () => (/* binding */ homeActions)
/* harmony export */ });
/* unused harmony export homeSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

// Define the initial state using that type
const initialState = {
    selected: {
        image: null
    }
};
const homeSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "home",
    initialState,
    reducers: {
        showFeaturedImage: (state, action)=>{
            const productIndex = action.payload.productIndex;
            if (state.selected.image === null) {
                state.selected.image = [
                    action.payload.imageDetails
                ];
            }
            state.selected.image[productIndex] = action.payload.imageDetails;
        }
    }
});
const homeActions = homeSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (homeSlice.reducer);


/***/ }),

/***/ 6813:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A": () => (/* binding */ loaderActions),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export loaderSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

// Define the initial state using that type
const initialState = {
    showLoader: false
};
const loaderSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "modals",
    initialState,
    reducers: {
        setShowLoader: (state, action)=>{
            state.showLoader = action.payload;
        }
    }
});
const loaderActions = loaderSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (loaderSlice.reducer);


/***/ }),

/***/ 7454:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "nT": () => (/* binding */ modalActions)
/* harmony export */ });
/* unused harmony export modalsSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

// Define the initial state using that type
const initialState = {
    sideMenu: "CLOSE"
};
const modalsSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "modals",
    initialState,
    reducers: {
        toggleSideMenu: (state, action)=>{
            state.sideMenu = action.payload;
        }
    }
});
const modalActions = modalsSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (modalsSlice.reducer);


/***/ }),

/***/ 8377:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Jh": () => (/* binding */ productActions),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export productSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var api_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1836);
/* eslint-disable no-unused-vars */ 

// Define the initial state using that type
const initialState = {
    selected: {
        productId: 297,
        inventory: null,
        image: {
            id: 0,
            imageUrl: "",
            altTag: ""
        },
        color: {
            productId: 0,
            attributeOptionId: 0,
            name: "",
            imageUrl: "",
            displayOrder: 0,
            altTag: "",
            moreImages: [
                {
                    displayOrder: 0,
                    imageUrl: "",
                    altTag: "",
                    id: 0
                }, 
            ],
            minQuantity: 0,
            multipleQuantity: 0
        }
    },
    product: {
        sizeChart: null,
        inventory: null,
        sizes: "",
        colors: null,
        brand: null,
        id: null,
        price: null,
        discounts: null,
        name: null
    },
    toCheckout: {
        minQty: 0,
        minQtyCheck: false,
        totalQty: 0,
        price: 0,
        availableOptions: null,
        currency: "$",
        sizeQtys: null,
        totalPrice: 0,
        additionalLogoCharge: 0,
        allowNextLogo: false,
        logo: {
            price: null
        },
        logos: null
    }
};
const productSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "product",
    initialState,
    reducers: {
        setPropertyValues: (state, action)=>{
            const propertyToSet = action.payload.propertyName;
            if (propertyToSet === "DISCOUNT") {
                state.product.discounts = action.payload.data;
            }
        },
        setColor: (state, action)=>{
            if (state.product.inventory) {
                var ref;
                const inventoryToShow = (ref = state.product.inventory) === null || ref === void 0 ? void 0 : ref.inventory.find((int)=>int.attributeOptionId === action.payload.attributeOptionId);
                if (inventoryToShow) {
                    state.selected.inventory = {
                        inventory: [
                            inventoryToShow
                        ],
                        sizes: state.selected.inventory.sizes
                    };
                }
            }
            state.selected.color = action.payload;
            state.toCheckout.minQty = action.payload.minQuantity;
            state.selected.productId = action.payload.productId;
        },
        setMinQty: (state, action)=>{
            state.toCheckout.minQty = action.payload;
        },
        setImage: (state, action)=>{
            state.selected.image = {
                ...action.payload,
                imageUrl: `${api_config__WEBPACK_IMPORTED_MODULE_1__/* ["default"].mediaBaseUrl */ .Z.mediaBaseUrl}${action.payload.imageUrl}`
            };
        },
        store_productDetails: (state, action)=>{
            state.product.brand = action.payload.brand;
            state.product.id = action.payload.product.id;
            state.product.name = action.payload.product.name;
            state.product.price = action.payload.product.price;
            state.product.sizes = action.payload.product.sizes;
            state.product.sizeChart = action.payload.product.sizeChart;
            state.product.discounts = action.payload.product.discounts;
            state.product.colors = action.payload.product.colors;
            state.product.inventory = action.payload.product.inventory;
        },
        toggleNextLogoButton: (state, action)=>{
            state.toCheckout.allowNextLogo = action.payload;
        },
        updatePrice: (state, action)=>{
            state.toCheckout.price = action.payload.price;
        },
        clearToCheckout: (state)=>{
            state.toCheckout = {
                logos: null,
                totalQty: 0,
                price: 0,
                minQty: 0,
                minQtyCheck: false,
                availableOptions: null,
                currency: "$",
                sizeQtys: null,
                totalPrice: 0,
                additionalLogoCharge: 0,
                allowNextLogo: false,
                logo: {
                    price: null
                }
            };
        },
        updateOptions: (state, action)=>{
            const addOrRemove = action.payload.addOrRemove;
            if (addOrRemove === "REMOVE") {
                var ref;
                state.toCheckout.availableOptions = ((ref = state.toCheckout.availableOptions) === null || ref === void 0 ? void 0 : ref.filter((opt)=>opt.value !== action.payload.value)) || null;
                state.toCheckout.allowNextLogo = true;
            }
            if (addOrRemove === "ADD") {
                var ref1;
                (ref1 = state.toCheckout.availableOptions) === null || ref1 === void 0 ? void 0 : ref1.push({
                    label: action.payload.label,
                    value: action.payload.value,
                    logo: {
                        url: action.payload.logo.url
                    }
                });
                state.toCheckout.allowNextLogo = true;
            }
        },
        updatePriceByLogo: (state, action)=>{
            const price = action.payload.price === "FREE" ? 0 : action.payload.price;
            const addOrSubtract = action.payload.type;
            if (addOrSubtract === "add") {
                state.toCheckout = {
                    ...state.toCheckout,
                    additionalLogoCharge: state.toCheckout.additionalLogoCharge + price * state.toCheckout.totalQty,
                    totalPrice: state.toCheckout.totalPrice + price * state.toCheckout.totalQty,
                    logo: {
                        price: state.toCheckout.logo.price ? [
                            ...state.toCheckout.logo.price,
                            action.payload.price
                        ] : [
                            action.payload.price
                        ]
                    }
                };
            }
            if (addOrSubtract === "subtract") {
                var ref;
                const removedPrice = (ref = state.toCheckout.logo.price) === null || ref === void 0 ? void 0 : ref.filter((price, index)=>{
                    if (index === action.payload.index) return false;
                    return true;
                });
                state.toCheckout = {
                    ...state.toCheckout,
                    additionalLogoCharge: state.toCheckout.additionalLogoCharge - price * state.toCheckout.totalQty,
                    totalPrice: state.toCheckout.totalPrice - price * state.toCheckout.totalQty,
                    logo: {
                        price: removedPrice || null
                    }
                };
            }
        },
        clearLogoUploadHistory: (state, action)=>{
            state.toCheckout.availableOptions = action.payload;
        },
        updateQuantities: (state, action)=>{
            var ref, ref1;
            let productName = action.payload.size;
            let productPrice = action.payload.price;
            let productQty = action.payload.qty;
            let totalQty = 0;
            let updatedSizeQtys;
            if (state.toCheckout.sizeQtys === null) {
                // IT CHECKOUT ARRAY DO NOT EXIST
                updatedSizeQtys = [
                    {
                        size: productName,
                        qty: productQty,
                        price: productPrice
                    }, 
                ];
                totalQty = productQty;
            } else {
                var ref2;
                // IF PRODUCT ALREDY EXISTS
                updatedSizeQtys = (ref2 = state.toCheckout.sizeQtys) === null || ref2 === void 0 ? void 0 : ref2.map((product)=>{
                    if (product.size === productName) {
                        totalQty += productQty;
                        return {
                            ...product,
                            qty: productQty
                        };
                    }
                    totalQty += product.qty;
                    return product;
                });
                // IF PRODUCT DO NOT EXIST IN THE CHECKOUT ARRAY
                const doesItemExist = state.toCheckout.sizeQtys.find((product)=>product.size === productName);
                if (!doesItemExist) {
                    updatedSizeQtys.push({
                        size: productName,
                        qty: productQty,
                        price: productPrice
                    });
                    totalQty += productQty;
                }
            }
            // LOGO CHARGE
            let updateAdditionalLogoCharge = 0;
            (ref = state.toCheckout.logo) === null || ref === void 0 ? void 0 : (ref1 = ref.price) === null || ref1 === void 0 ? void 0 : ref1.forEach((price)=>{
                if (price === "FREE") return updateAdditionalLogoCharge += 0;
                return updateAdditionalLogoCharge += price * totalQty;
            });
            if (totalQty >= state.toCheckout.minQty) {
                state.toCheckout.minQtyCheck = true;
            }
            if (totalQty < state.toCheckout.minQty) {
                state.toCheckout.minQtyCheck = false;
            }
            // TOTAL PRICE
            let totalPrice = totalQty * state.toCheckout.price + updateAdditionalLogoCharge;
            // STATE UPDATES
            state.toCheckout.additionalLogoCharge = updateAdditionalLogoCharge;
            state.toCheckout.sizeQtys = updatedSizeQtys || null;
            state.toCheckout.totalQty = totalQty;
            state.toCheckout.totalPrice = totalPrice;
        },
        updateQuantities2: (state, action)=>{
            let productName = action.payload.size;
            let productPrice = action.payload.price;
            let productQty = action.payload.qty;
            let color = action.payload.color;
            let totalQty = 0;
            let updatedSizeQtys;
            if (state.toCheckout.sizeQtys === null) {
                // IT CHECKOUT ARRAY DO NOT EXIST
                updatedSizeQtys = [
                    {
                        size: productName,
                        qty: productQty,
                        price: productPrice,
                        color: color
                    }, 
                ];
                totalQty = productQty;
            } else {
                var ref;
                updatedSizeQtys = (ref = state.toCheckout.sizeQtys) === null || ref === void 0 ? void 0 : ref.map((product)=>{
                    if (product.size === productName && product.color === color) {
                        totalQty += productQty;
                        return {
                            ...product,
                            qty: productQty
                        };
                    }
                    totalQty += product.qty;
                    return product;
                });
                const doesItemExist = state.toCheckout.sizeQtys.find((product)=>product.size === productName && product.color === color);
                if (!doesItemExist) {
                    updatedSizeQtys.push({
                        size: productName,
                        qty: productQty,
                        price: productPrice,
                        color: color
                    });
                    totalQty += productQty;
                }
            }
            // LOGO CHARGE
            let updateAdditionalLogoCharge = 0;
            // state.toCheckout.logo?.price?.forEach((price) => {
            //   if (price === 'FREE') return (updateAdditionalLogoCharge += 0);
            //   return (updateAdditionalLogoCharge += price * totalQty);
            // });
            // if (totalQty >= state.toCheckout.minQty) {
            //   state.toCheckout.minQtyCheck = true;
            // }
            // if (totalQty < state.toCheckout.minQty) {
            //   state.toCheckout.minQtyCheck = false;
            // }
            // TOTAL PRICE
            let totalPrice = totalQty * state.toCheckout.price + updateAdditionalLogoCharge;
            // STATE UPDATES
            state.toCheckout.additionalLogoCharge = updateAdditionalLogoCharge;
            state.toCheckout.sizeQtys = updatedSizeQtys || null;
            state.toCheckout.totalQty = totalQty;
            state.toCheckout.totalPrice = totalPrice;
        },
        updateLogoDetails: (state, action)=>{
            let logos = [];
            const upcomingLogo = action.payload;
            const oldLogos = state.toCheckout.logos;
            if (oldLogos === null) {
                logos.push({
                    no: 1,
                    logo: {
                        url: (upcomingLogo === null || upcomingLogo === void 0 ? void 0 : upcomingLogo.url) || "",
                        name: (upcomingLogo === null || upcomingLogo === void 0 ? void 0 : upcomingLogo.name) || ""
                    },
                    location: upcomingLogo.location || {
                        label: "",
                        value: ""
                    }
                });
            }
            if (oldLogos !== null) {
                logos = [
                    ...oldLogos
                ];
                const logoExist = oldLogos.find((logo)=>{
                    var ref;
                    return logo.location.value === ((ref = upcomingLogo.location) === null || ref === void 0 ? void 0 : ref.value);
                });
                if (logoExist) {
                    logos = logos.map((logo)=>{
                        var ref;
                        if (logo.location.value === ((ref = upcomingLogo.location) === null || ref === void 0 ? void 0 : ref.value)) {
                            return {
                                ...logo,
                                logo: {
                                    url: upcomingLogo.url || "",
                                    name: upcomingLogo.name || ""
                                }
                            };
                        }
                        return logo;
                    });
                }
                if (!logoExist) {
                    logos.push({
                        no: logos.length,
                        logo: {
                            url: (upcomingLogo === null || upcomingLogo === void 0 ? void 0 : upcomingLogo.url) || "",
                            name: (upcomingLogo === null || upcomingLogo === void 0 ? void 0 : upcomingLogo.name) || ""
                        },
                        location: upcomingLogo.location || {
                            value: "",
                            label: ""
                        }
                    });
                }
            }
            state.toCheckout.logos = logos;
        },
        updateCheckoutObject: (state, action)=>{
            state.toCheckout.totalPrice = action.payload.totalPrice;
            state.toCheckout.totalQty = action.payload.totalQty;
            state.toCheckout.sizeQtys = action.payload.sizeQtys;
        },
        storeDetails: (state, action)=>{
            state.product.brand = action.payload.brand;
            state.product.id = action.payload.product.id;
            state.product.name = action.payload.product.name;
            state.product.price = action.payload.product.price;
        },
        storeProductColor: (state, action)=>{
            state.product.colors = action.payload.colors;
        }
    }
});
const productActions = productSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (productSlice.reducer);


/***/ }),

/***/ 2328:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "d": () => (/* binding */ redefineStoreActions)
/* harmony export */ });
/* unused harmony export storeSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var constants_store_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7297);
/* harmony import */ var helpers_common_helper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4822);
/* harmony import */ var mock_store_mock__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5704);
/* harmony import */ var page_config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3521);
/* harmony import */ var _asyncActions_redefineStore_async__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5660);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([helpers_common_helper__WEBPACK_IMPORTED_MODULE_2__]);
helpers_common_helper__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






// Define the initial state using that type
const initialState = {
    id: null,
    isAttributeSaparateProduct: false,
    layout: null,
    storeTypeId: null,
    display: mock_store_mock__WEBPACK_IMPORTED_MODULE_3__/* .showComponents */ .I,
    pathName: "",
    companyName: "",
    currency: "$",
    seName: constants_store_constant__WEBPACK_IMPORTED_MODULE_1__/* ._SeName.nike */ .sS.nike,
    pageType: {},
    view: "DESKTOP",
    menuItems: null,
    brands: null
};
const storeSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "redesignStore",
    initialState,
    reducers: {
        store_storeDetails: (state, action)=>{
            const store = action.payload.store;
            state.id = store.storeId;
            state.layout = store.layout;
            state.pathName = store.pathName;
            state.brands = action.payload.brands;
            state.isAttributeSaparateProduct = action.payload.store.isAttributeSaparateProduct;
            state.layout = (0,helpers_common_helper__WEBPACK_IMPORTED_MODULE_2__/* .layoutToShow */ .lU)({
                layout: action.payload.store.code,
                showProd: page_config__WEBPACK_IMPORTED_MODULE_4__/* .__domain.isSiteLive */ .Pq.isSiteLive
            });
            // state.pageType = store.pageType;
            state.menuItems = action.payload.menuItems;
        },
        setView: (state, action)=>{
            state.view = action.payload;
        }
    },
    extraReducers: (builder)=>{
        builder.addCase(_asyncActions_redefineStore_async__WEBPACK_IMPORTED_MODULE_5__.SetPageType.fulfilled, (state, action)=>{
            state.pageType = action.payload.payload;
        });
    }
});
const redefineStoreActions = storeSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (storeSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4011:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ey": () => (/* binding */ successActions),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export successSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

// Define the initial state using that type
const initialState = {
    showModal: false,
    type: "",
    message: ""
};
const successSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "modals",
    initialState,
    reducers: {
        showModal: (state, action)=>{
            state.showModal = true;
            state.type = action.payload.type;
            state.message = action.payload.message;
        },
        hideModal: (state, action)=>{
            state.showModal = false;
            state.type = "";
            state.message = "";
        }
    }
});
const successActions = successSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (successSlice.reducer);


/***/ }),

/***/ 3754:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "hI": () => (/* binding */ userActions)
/* harmony export */ });
/* unused harmony export userSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _asyncActions_user_async__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4643);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_asyncActions_user_async__WEBPACK_IMPORTED_MODULE_1__]);
_asyncActions_user_async__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


// Define the initial state using that type
const initialState = {
    id: 123,
    customer: {
        firstname: "Husain",
        lastName: "Think",
        email: "husain@redefineindia.com",
        password: "12345678",
        confirmPassword: null,
        companyName: "Redefine",
        companyId: 30,
        tierId: 0,
        isRegistered: false,
        sharedCustomerId: 0,
        isLocked: false,
        navCustomerId: "",
        isSuperuser: false,
        customerType: "string",
        storeId: 4,
        isTaxableuser: false,
        storeCustomerAddress: [
            {
                customerId: 123,
                firstname: "string",
                lastName: "string",
                companyName: "string",
                email: "string",
                address1: "string",
                address2: "string",
                suite: "string",
                city: "string",
                state: "string",
                postalCode: "string",
                phone: "string",
                fax: "string",
                countryName: "string",
                countryCode: "1",
                addressType: "R",
                isDefault: false,
                recStatus: "A",
                createdDate: "2022-11-24T14:34:58.4113161+00:00",
                createdBy: 0,
                modifiedDate: null,
                modifiedBy: null,
                id: 268,
                rowVersion: "BHMFECnO2gg=",
                location: "string",
                ipAddress: "192.168.1.1",
                macAddress: "00-00-00-00-00-00"
            }, 
        ],
        recStatus: "A",
        createdDate: "2022-11-24T14:34:56.7734226+00:00",
        createdBy: 0,
        modifiedDate: null,
        modifiedBy: null,
        industryId: 0,
        id: 123,
        rowVersion: "lJQXDynO2gg=",
        location: "string",
        ipAddress: "192.168.1.1",
        macAddress: "00-00-00-00-00-00"
    }
};
const userSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "userDetails",
    initialState,
    reducers: {
        updateUserDetails: (state, action)=>{
            state.id = action.payload.id;
        },
        updateCustomer: (state, action)=>{
            state.customer = action.payload.customer;
        }
    },
    extraReducers: (builder)=>{
        builder.addCase(_asyncActions_user_async__WEBPACK_IMPORTED_MODULE_1__.getStoreCustomer.fulfilled, (state, action)=>{
            state.customer = action.payload;
        });
    }
});
const userActions = userSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (userSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2449:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "O": () => (/* binding */ FetchBrands)
/* harmony export */ });
/* harmony import */ var _utils_axios_util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(795);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__]);
_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const FetchBrands = async (storeId)=>{
    const url = `/Brand/getbrandbystoreid/${storeId}.json`;
    const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__/* .SendAsyncV2 */ .y)({
        url: url,
        method: "GET"
    });
    return res;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7591:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Xq": () => (/* binding */ addToCart),
/* harmony export */   "jT": () => (/* binding */ deleteItemCart),
/* harmony export */   "tD": () => (/* binding */ checkCoupon),
/* harmony export */   "x7": () => (/* binding */ fetchCart)
/* harmony export */ });
/* harmony import */ var _utils_axios_util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(795);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__]);
_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const fetchCart = async (customerId)=>{
    const url = `/Store/GetShoppingCartItemsDetail/${customerId}.json`;
    const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__/* .SendAsyncV2 */ .y)({
        url: url,
        method: "GET"
    });
    return res.data;
};
const addToCart = async (payload)=>{
    const url = `/Store/addtocart.json`;
    const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__/* .SendAsyncV2 */ .y)({
        url: url,
        method: "POST",
        data: payload
    });
    return res.data;
};
const checkCoupon = async (payload)=>{
    const url = `Store/CouponCode/GetCouponDetails.json`;
    const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__/* .SendAsyncV2 */ .y)({
        url: url,
        method: "POST",
        data: payload
    });
    return res;
};
const deleteItemCart = async (cartItemId)=>{
    const url = `/Store/RemoveRegisterCart/${cartItemId}.json`;
    const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__/* .SendAsyncV2 */ .y)({
        url: url,
        method: "GET"
    });
    return res;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1488:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Mo": () => (/* binding */ GetStatesList),
/* harmony export */   "SD": () => (/* binding */ UpdateWishList),
/* harmony export */   "Zq": () => (/* binding */ SubscribeToNewsLetter),
/* harmony export */   "_w": () => (/* binding */ GetIndustriesList),
/* harmony export */   "em": () => (/* binding */ getStoreCustomer),
/* harmony export */   "gF": () => (/* binding */ GetCountriesList),
/* harmony export */   "pY": () => (/* binding */ CreateNewAccount),
/* harmony export */   "w2": () => (/* binding */ signInUser)
/* harmony export */ });
/* unused harmony export AddToCart */
/* harmony import */ var _utils_axios_util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(795);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__]);
_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const signInUser = async (payload)=>{
    const url = `StoreCustomer/customerlogin.json`;
    const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__/* .SendAsyncV2 */ .y)({
        url: url,
        method: "POST",
        data: payload
    });
    return res.data;
};
const GetCountriesList = async ()=>{
    const url = `StoreCustomer/getcustomercountry.json`;
    const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__/* .SendAsyncV2 */ .y)({
        url: url,
        method: "POST"
    });
    return res.data;
};
const GetStatesList = async (id)=>{
    const url = `StoreCustomer/getcustomerstatebycountryid/${id}.json`;
    const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__/* .SendAsyncV2 */ .y)({
        url: url,
        method: "GET"
    });
    return res.data;
};
const GetIndustriesList = async ()=>{
    const url = `StoreCustomer/getcustomerindustry.json`;
    const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__/* .SendAsyncV2 */ .y)({
        url: url,
        method: "POST"
    });
    return res.data;
};
const UpdateWishList = async (productId)=>{
    const url = "/like";
    const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__/* .SendAsyncV2 */ .y)({
        url: url,
        method: "GET",
        data: productId
    });
    return res.data;
};
const SubscribeToNewsLetter = async (payload)=>{
    const url = "/subscribe";
    const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__/* .SendAsyncV2 */ .y)({
        url: url,
        method: "POST",
        data: payload
    });
    return res.data;
};
const CreateNewAccount = async (payload)=>{
    const url = "StoreCustomer/storecustomercreate.json";
    const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__/* .SendAsyncV2 */ .y)({
        url: url,
        method: "POST",
        data: payload
    });
    return res.data;
};
const AddToCart = async (payload)=>{
    const url = "/addToCart";
    const res = await SendAsyncV2({
        url: url,
        method: "POST",
        data: payload
    });
    return res.data;
};
const getStoreCustomer = async (customerId)=>{
    const url = `/StoreCustomer/get/${customerId}.json`;
    const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__/* .SendAsyncV2 */ .y)({
        url: url,
        method: "GET",
        data: customerId
    });
    return res.data;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;