"use strict";
exports.id = 1801;
exports.ids = [1801];
exports.modules = {

/***/ 1801:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const SideFilter = ({ filters , handleChange , checkedFilters  })=>{
    /*#__PURE__*/ return react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "relative",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "p-4",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex items-center justify-between",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "text-lg font-medium text-gray-900",
                        children: "Filters"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: filters && filters.map((filter, index)=>{
                        /*#__PURE__*/ return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: `py-4${index === 0 ? "" : " border-t border-neutral-300"}`,
                            "x-data": "{ open: true }",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "flex items-center justify-between w-full group mb-1",
                                    "aria-expanded": "true",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "text-sm text-gray-800 font-medium",
                                        children: filter.label
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "text-sm",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                        className: filter.label === "Color" ? "flex flex-wrap items-center gap-x-1.5 gap-y-2" : "pb-6 pt-2 space-y-3",
                                        children: filter.options.map((option, ind)=>{
                                            const checked = checkedFilters.findIndex((res)=>res.name === filter.label && res.value === option.name) > -1;
                                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                children: option.name || option.colorCode ? filter.label === "Color" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                    className: `w-8 h-8 border-2 hover:border-secondary p-0.5 ${checked && "border-secondary"}`,
                                                    style: {
                                                        background: option.colorCode
                                                    },
                                                    onClick: ()=>{
                                                        handleChange(filter.label, option.name, !checked);
                                                    }
                                                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                    className: "flex items-center",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                            id: `${option.name}-${ind}`,
                                                            name: filter.label,
                                                            value: option.name,
                                                            checked: checked,
                                                            type: "checkbox",
                                                            onChange: (e)=>{
                                                                const { name , value , checked  } = e.target;
                                                                handleChange(name, value, checked);
                                                            },
                                                            className: "h-4 w-4 border-gray-300 rounded text-indigo-600"
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                            htmlFor: `${option.name}-${ind}`,
                                                            className: "ml-3 text-sm text-gray-600",
                                                            children: [
                                                                option.name,
                                                                " (",
                                                                option === null || option === void 0 ? void 0 : option.productCount,
                                                                ")"
                                                            ]
                                                        })
                                                    ]
                                                }, ind) : null
                                            });
                                        })
                                    })
                                })
                            ]
                        }, index);
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SideFilter);


/***/ })

};
;