"use strict";
exports.id = 9483;
exports.ids = [9483];
exports.modules = {

/***/ 1836:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const dev = {
    api: {
        URL: "https://redefine-front-staging.azurewebsites.net/"
    },
    CLIENT_ID: "",
    mediaBaseUrl: "https://redefinecommerce.blob.core.windows.net",
    CMS: "https://www.redefinecommerce.net/API"
};
const stage = {
    api: {
        URL: "https://redefine-front-staging.azurewebsites.net/"
    },
    CLIENT_ID: "",
    mediaBaseUrl: "https://redefinecommerce.blob.core.windows.net",
    CMS: "https://www.redefinecommerce.net/API"
};
const prod = {
    api: {
        URL: "https://redefine-front-staging.azurewebsites.net/"
    },
    CLIENT_ID: "",
    mediaBaseUrl: "https://redefinecommerce.blob.core.windows.net",
    CMS: "https://www.redefinecommerce.net/API"
};
let config;
switch(process.env.REACT_APP_STAGE){
    case "dev":
        config = dev;
        break;
    case "staging":
        config = stage;
        break;
    case "production":
        config = prod;
        break;
    default:
        config = dev;
        break;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (config);


/***/ }),

/***/ 7297:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZF": () => (/* binding */ _StoreDomains),
/* harmony export */   "sS": () => (/* binding */ _SeName),
/* harmony export */   "up": () => (/* binding */ _Store)
/* harmony export */ });
const _Store = {
    type1: "cg",
    type2: "gamedaygear.com",
    type3: "pk",
    type4: "drivingi"
};
const _StoreDomains = {
    domain1: "corporategear",
    domain2: "gamedaygear.com",
    domain3: "pk",
    domain4: "drivingi"
};
const _SeName = {
    hundred: '"100th-anniversary-challenge-coin"',
    nike: "Nike-Men-s-Club-Fleece-Sleeve-Swoosh-Pullover-Hoodie"
};


/***/ }),

/***/ 4822:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M_": () => (/* binding */ domainToShow),
/* harmony export */   "R1": () => (/* binding */ removeDuplicates),
/* harmony export */   "Yl": () => (/* binding */ c_getSeName),
/* harmony export */   "lU": () => (/* binding */ layoutToShow),
/* harmony export */   "zL": () => (/* binding */ extractSlugName)
/* harmony export */ });
/* harmony import */ var page_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3521);
/* harmony import */ var _global_console__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3650);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_global_console__WEBPACK_IMPORTED_MODULE_1__]);
_global_console__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


function removeDuplicates(arr) {
    return arr.filter((arr, index, self)=>index === self.findIndex((t)=>t.seName === arr.seName));
}
function layoutToShow(payload) {
    let layout = page_config__WEBPACK_IMPORTED_MODULE_0__/* .__domain.layoutToDisplay */ .Pq.layoutToDisplay;
    if (payload.showProd && payload.layout) {
        layout === payload.layout;
    }
    (0,_global_console__WEBPACK_IMPORTED_MODULE_1__/* .conditionalLog */ .wH)({
        show: payload.layout ? false : true,
        type: "FUNCTION",
        name: "layoutToShow",
        data: payload.layout,
        error: true
    });
    return layout;
}
function domainToShow(payload) {
    let domain = page_config__WEBPACK_IMPORTED_MODULE_0__/* .__domain.localDomain */ .Pq.localDomain;
    if (payload.showProd && payload.domain) {
        domain === payload.domain;
    }
    (0,_global_console__WEBPACK_IMPORTED_MODULE_1__/* .conditionalLog */ .wH)({
        show: !payload.domain,
        type: "FUNCTION",
        name: "domainToShow",
        data: payload.domain,
        error: true
    });
    return domain;
}
const c_getSeName = (component)=>{
    const pathName = window.location.pathname;
    let slug = "";
    if (component === "PRODUCT DETAILS") {
        const withoutHTML = pathName.split(".")[0];
        slug = withoutHTML.split("/")[1];
    }
    if (component === "PRODUCT COMPARE") {
        slug = "";
    }
    return slug;
};
const extractSlugName = (contextParam)=>{
    let slug = "";
    let slugID = [];
    if (contextParam) {
        slugID = contextParam["slug-id"];
        if (slugID) {
            var ref;
            slug = ((ref = slugID.at(-1)) === null || ref === void 0 ? void 0 : ref.replace(".html", "")) || "";
        } else {
            const paramsSlug = contextParam;
            slug = paramsSlug ? (paramsSlug === null || paramsSlug === void 0 ? void 0 : paramsSlug.slug).replace(".html", "") : "";
        }
    }
    return {
        slug,
        slugID
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3650:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Eg": () => (/* binding */ highLightError),
/* harmony export */   "wH": () => (/* binding */ conditionalLog)
/* harmony export */ });
/* unused harmony export highLightResponse */
/* harmony import */ var chalk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7564);
/* harmony import */ var show_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2118);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([chalk__WEBPACK_IMPORTED_MODULE_0__]);
chalk__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// tslint:disable:no-console


const Error = {
    title: chalk__WEBPACK_IMPORTED_MODULE_0__["default"].bold.red,
    data: chalk__WEBPACK_IMPORTED_MODULE_0__["default"].rgb(247, 173, 173),
    border: chalk__WEBPACK_IMPORTED_MODULE_0__["default"].red
};
const Log = {
    title: chalk__WEBPACK_IMPORTED_MODULE_0__["default"].bold.cyan,
    data: chalk__WEBPACK_IMPORTED_MODULE_0__["default"].rgb(157, 212, 255),
    border: chalk__WEBPACK_IMPORTED_MODULE_0__["default"].cyan
};
const highLightResponse = ({ dataToShow , component , display =true  })=>{
    if (display === false) return;
    console.log(Log.border(`====================================================================================================================================================================`));
    console.log(Log.title(`Console.log:        ( ${component} )`));
    console.log(Log.border(`====================================================================================================================================================================`));
    const consoleMsg = Log.data(JSON.stringify(dataToShow, null, 3));
    console.log(consoleMsg);
    console.log(Log.border(`--------------------------------X--------------------------------X--------------------------------X--------------------------------X--------------------------------`));
};
const highLightError = ({ error , component  })=>{
    const ErrMsg = Error.data(JSON.stringify(error, null, 3));
    console.log(Error.border(`====================================================================================================================================================================`));
    console.log(Error.title(`Console.log: ERROR       ( ${component} )`));
    console.log(Error.border(`====================================================================================================================================================================`));
    console.log(ErrMsg);
    console.log(Error.border(`--------------------------------X--------------------------------X--------------------------------X--------------------------------X--------------------------------`));
};
const conditionalLog = ({ data , type , show , name , error =false  })=>{
    if (show_config__WEBPACK_IMPORTED_MODULE_1__/* .hideAllConsoles */ .Mf) return;
    if (show) {
        if (type === "API") {
            const errType = error ? "API Failed" : "No Data Found";
            const message = `${errType} : ${name}`;
            highLightError({
                error: data,
                component: message
            });
            return;
        }
        if (name === show_config__WEBPACK_IMPORTED_MODULE_1__/* .__fileNames.productDetails */ .eg.productDetails || name === show_config__WEBPACK_IMPORTED_MODULE_1__/* .__fileNames._app */ .eg._app || name === show_config__WEBPACK_IMPORTED_MODULE_1__/* .__fileNames.requestConsultation */ .eg.requestConsultation || name === show_config__WEBPACK_IMPORTED_MODULE_1__/* .__fileNames.compareProducts */ .eg.compareProducts || name === show_config__WEBPACK_IMPORTED_MODULE_1__/* .__fileNames.home */ .eg.home) {
            const message1 = `${type} : ${name}`;
            highLightResponse({
                dataToShow: data,
                component: message1
            });
        }
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3521:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ao": () => (/* binding */ __Header),
/* harmony export */   "K6": () => (/* binding */ sliderSettings),
/* harmony export */   "Pq": () => (/* binding */ __domain),
/* harmony export */   "vb": () => (/* binding */ __product)
/* harmony export */ });
/* harmony import */ var _constants_store_constant__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7297);

const __product = {
    imagesInRow: 7,
    descriptionLength: 500
};
const __Header = {
    mobileBreakPoint: 1024
};
const __domain = {
    isSiteLive: true,
    localDomain: _constants_store_constant__WEBPACK_IMPORTED_MODULE_0__/* ._StoreDomains.domain1 */ .ZF.domain1,
    layoutToDisplay: _constants_store_constant__WEBPACK_IMPORTED_MODULE_0__/* ._Store.type1 */ .up.type1
};
const sliderSettings = {
    similarProducts: {
        dots: false,
        infinite: true,
        speed: 500,
        slidesToShow: 5,
        slidesToScroll: 1
    }
};


/***/ }),

/***/ 2118:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Mf": () => (/* binding */ hideAllConsoles),
/* harmony export */   "YH": () => (/* binding */ _showConsoles),
/* harmony export */   "eg": () => (/* binding */ __fileNames)
/* harmony export */ });
const hideAllConsoles = false; // Will hide all the consoles except API Failures.
const __fileNames = {
    productDetails: "Product-Details",
    _app: "_app",
    requestConsultation: "Request-Consultation",
    compareProducts: "Compare-Products",
    home: "home"
};
const _showConsoles = {
    productDetails: false,
    _app: false,
    requestConsultation: false,
    compareProducts: false,
    home: false,
    services: {
        store: true,
        productDetails: true,
        compareProducts: true,
        header: true,
        page: true
    }
};


/***/ }),

/***/ 795:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "y": () => (/* binding */ SendAsyncV2)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var _api_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1836);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const axiosInstance = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: _api_config__WEBPACK_IMPORTED_MODULE_1__/* ["default"].api.URL */ .Z.api.URL,
    headers: {}
});
const SendAsyncV2 = (request)=>{
    return new Promise((resolve, reject)=>{
        axiosInstance.request(request).then((res)=>resolve(res)).catch((err)=>reject(err));
    });
};
axiosInstance.interceptors.request.use(async (request)=>{
    // request.headers = {
    //   'Content-Type': 'application/json',
    //   'Access-Control-Allow-Origin': '*',
    // };
    request.headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET,PUT,POST,DELETE,PATCH,OPTIONS"
    };
    if (request.data && request.data.files) {
        request.headers["Content-Type"] = "multipart/form-data";
    }
    return request;
});
axiosInstance.interceptors.response.use((response)=>{
    return response.data;
}, (error)=>{
    if (error.response && error.response.status === 401) {
        localStorage.clear();
        window.location.href = "/";
    }
    return Promise.reject(error.response.data);
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;