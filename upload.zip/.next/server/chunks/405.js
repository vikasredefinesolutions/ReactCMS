"use strict";
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 405:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OX": () => (/* binding */ FetchBrands),
/* harmony export */   "ii": () => (/* binding */ FetchStoreDetails)
/* harmony export */ });
/* unused harmony export FetchMenuItems */
/* harmony import */ var helpers_global_console__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3650);
/* harmony import */ var services_header_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6508);
/* harmony import */ var services_home_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8400);
/* harmony import */ var show_config__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2118);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([helpers_global_console__WEBPACK_IMPORTED_MODULE_0__, services_header_service__WEBPACK_IMPORTED_MODULE_1__, services_home_service__WEBPACK_IMPORTED_MODULE_2__]);
([helpers_global_console__WEBPACK_IMPORTED_MODULE_0__, services_header_service__WEBPACK_IMPORTED_MODULE_1__, services_home_service__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//////// SERVER SIDE FUNCTIONS ---------------------------------------
//////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
const FetchBrands = async (storeId)=>{
    return services_header_service__WEBPACK_IMPORTED_MODULE_1__/* .FetchBrands */ .OX({
        storeId
    });
};
const FetchMenuItems = async (storeId)=>{
    return [];
// HeaderService.FetchStoreMenu({ storeId });
};
const FetchStoreDetails = async (domain, pathName)=>{
    const store = {
        storeId: null,
        layout: null,
        pageType: "",
        pathName: "",
        code: "",
        isAttributeSaparateProduct: false
    };
    try {
        const res = await services_home_service__WEBPACK_IMPORTED_MODULE_2__/* .GetStoreID */ .aM(domain);
        if (res) {
            store.storeId = res.id;
            store.layout = res.code;
            store.pathName = pathName;
            store.code = res.code;
            store.isAttributeSaparateProduct = res.isAttributeSaparateProduct;
            return store;
        }
        (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_0__/* .conditionalLog */ .wH)({
            data: store,
            type: "CONTROLLER",
            name: show_config__WEBPACK_IMPORTED_MODULE_3__/* .__fileNames._app */ .eg._app,
            show: show_config__WEBPACK_IMPORTED_MODULE_3__/* ._showConsoles._app */ .YH._app
        });
        return null;
    } catch (error) {
        (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_0__/* .highLightError */ .Eg)({
            error,
            component: "_app Controller"
        });
        return null;
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2776:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": () => (/* binding */ headerInfo)
/* harmony export */ });
/* unused harmony export logo */
const headerInfo = {
    brand: {
        label: "Corporate Gear",
        logo: {
            url: "https://www.corporategear.com/images/logo.svg",
            alt: "Corporate Gear"
        }
    }
};
const logo = {
    header_layout: "3",
    enable_sticky_header: false,
    enable_fullwidth: true,
    overlay_header: false,
    header_bg_color: "#2d8bf1",
    header_text_color: "#2d8bf1",
    logo_resize: "10",
    desktop_image: "https://www.corporategear.com/images/logo.svg",
    desktop_logo_alt: "Corporate Gear",
    desktop_logo_resize: "75",
    mobile_image: "https://www.corporategear.com/images/logo.svg",
    mobile_logo_alt: "Corporate Gear",
    mobile_logo_resize: "50",
    desktop_logo_alignment: "Left",
    mobile_logo_alignment: "Center",
    image_title: "Corporate Gear",
    image_link: "https://www.corporategear.com/",
    navigation_link: [
        {
            title: "Brands",
            url: "https://www.corporategear.com/brands.html",
            visible: true
        },
        {
            title: "Men",
            url: "https://www.corporategear.com/men.html",
            visible: true
        },
        {
            title: "Women",
            url: "https://www.corporategear.com/women.html",
            visible: true
        },
        {
            title: "Golf",
            url: "https://www.corporategear.com/golf.html",
            visible: true
        },
        {
            title: "Accessories",
            url: "https://www.corporategear.com/accessories.html",
            visible: true
        },
        {
            title: "Consultation",
            url: "https://www.corporategear.com/consultation.html",
            visible: true
        },
        {
            title: "FAQ",
            url: "https://www.corporategear.com/faq.html",
            visible: true
        },
        {
            title: "Sale",
            url: "https://www.corporategear.com/sale.html",
            visible: true
        }, 
    ]
};


/***/ }),

/***/ 6508:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "By": () => (/* binding */ SearchFor),
/* harmony export */   "OX": () => (/* binding */ FetchBrands)
/* harmony export */ });
/* unused harmony exports FetchBannerDetails, FetchStoreMenu, FetchMenuTopics, FetchMenuCategories */
/* harmony import */ var api_config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1836);
/* harmony import */ var _mock_header_mock__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2776);
/* harmony import */ var _utils_axios_util__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(795);
/* harmony import */ var helpers_global_console__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3650);
/* harmony import */ var show_config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2118);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_axios_util__WEBPACK_IMPORTED_MODULE_2__, helpers_global_console__WEBPACK_IMPORTED_MODULE_3__]);
([_utils_axios_util__WEBPACK_IMPORTED_MODULE_2__, helpers_global_console__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





// eslint-disable-next-line no-unused-vars
const SearchFor = async (payload)=>{
    // const url = `/front/get-page-type?store_id=${payload.storeId}&slug=${payload.slug}`;
    // await SendAsyncV2<AxiosRequestConfig>({
    //   url: url,
    //   method: 'POST',
    //   data: {},
    // });
    return _mock_header_mock__WEBPACK_IMPORTED_MODULE_1__/* .headerInfo */ .I;
};
const FetchBrands = async ({ storeId  })=>{
    const url = `/Brand/getbrandbystoreid/${storeId}.json`;
    try {
        const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_2__/* .SendAsyncV2 */ .y)({
            url: url,
            method: "GET"
        });
        (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_3__/* .conditionalLog */ .wH)({
            data: res.data,
            name: "FetchBrands",
            type: "API",
            show: res.data === null || res.data.length === 0
        });
        return res.data;
    } catch (error) {
        (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_3__/* .conditionalLog */ .wH)({
            data: error,
            name: "FetchBrands",
            type: "API",
            show: show_config__WEBPACK_IMPORTED_MODULE_4__/* ._showConsoles.services.store */ .YH.services.store,
            error: true
        });
        return null;
    }
};
const FetchBannerDetails = async (payload)=>{
    const url = `https://redefine-front-dev.azurewebsites.net/Brand/getbannerdeatilsbystoreid.json?isbrand=${payload.isBrand}&storeid=${payload.storeId}&sename=${payload.sename}`;
    const res = await SendAsyncV2({
        url: url,
        method: "GET"
    });
    return res.data;
};
const FetchStoreMenu = async (payload)=>{
    const url = `${config.CMS}/api/store-menu/${payload.storeId}`;
    const res = await SendAsyncV2({
        url: url,
        method: "GET"
    });
    return res.data;
};
const FetchMenuTopics = async (payload)=>{
    const url = `${config.CMS}/api/topics/${payload.topicId}`;
    const res = await SendAsyncV2({
        url: url,
        method: "POST"
    });
    return res.data;
};
const FetchMenuCategories = async (payload)=>{
    const url = `${config.api.URL}Category/getcategorysbyparentid/${payload.categoryId}/${payload.storeId}.json`;
    const res = await SendAsyncV2({
        url: url,
        method: "GET"
    });
    return res.data;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8400:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "aM": () => (/* binding */ GetStoreID)
/* harmony export */ });
/* unused harmony exports FetchFeaturedProducts, fetchProducts, fetchProductById, FetchPageType */
/* harmony import */ var helpers_global_console__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3650);
/* harmony import */ var show_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2118);
/* harmony import */ var _utils_axios_util__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(795);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([helpers_global_console__WEBPACK_IMPORTED_MODULE_0__, _utils_axios_util__WEBPACK_IMPORTED_MODULE_2__]);
([helpers_global_console__WEBPACK_IMPORTED_MODULE_0__, _utils_axios_util__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



const FetchFeaturedProducts = async (payload)=>{
    const url = "/StoreProduct/getfeaturedproductitems.json";
    try {
        const res = await SendAsyncV2({
            url: url,
            method: "POST",
            data: payload
        });
        conditionalLog({
            data: res.data,
            name: "FetchProductsBySKUs",
            type: "API",
            show: res.data === null || res.data.length === 0
        });
        return res.data;
    } catch (error) {
        conditionalLog({
            data: error,
            name: "FetchProductsBySKUs",
            type: "API",
            show: _showConsoles.services.compareProducts,
            error: true
        });
        return null;
    }
};
const fetchProducts = async ()=>{
    const url = "/home";
    const res = await SendAsyncV2({
        url: url,
        method: "GET"
    });
    return res.data;
};
const fetchProductById = async ()=>{
    const url = "/product/";
    const res = await SendAsyncV2({
        url: url,
        method: "GET"
    });
    return res.data;
};
const GetStoreID = async (domain)=>{
    const url = `Store/getstorebydomain.json`;
    try {
        const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_2__/* .SendAsyncV2 */ .y)({
            url: url,
            method: "POST",
            data: {
                url: domain
            }
        });
        (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_0__/* .conditionalLog */ .wH)({
            data: res,
            name: "GetStoreID",
            type: "API",
            show: res.data === null
        });
        return res.data;
    } catch (error) {
        (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_0__/* .conditionalLog */ .wH)({
            data: error,
            type: "API",
            show: true,
            name: "GetStoreID",
            error: true
        });
        return null;
    }
};
const FetchPageType = async (payload)=>{
    const url = `/front/get-page-type?store_id=${payload.storeId}&slug=${payload.slug}`;
    try {
        const res = await SendAsyncV2({
            url: url,
            method: "POST",
            data: {}
        });
        conditionalLog({
            data: res.data,
            name: "FetchPageType",
            type: "API",
            show: res.data === null
        });
        return res;
    } catch (error) {
        conditionalLog({
            data: error,
            name: "FetchPageType",
            type: "API",
            show: _showConsoles.services.compareProducts,
            error: true
        });
        const res1 = {
            data: null
        };
        return res1;
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;