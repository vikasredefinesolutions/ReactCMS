"use strict";
exports.id = 7828;
exports.ids = [7828];
exports.modules = {

/***/ 7828:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var helpers_compare_helper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9596);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6183);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_1__]);
hooks__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const ProductListController = (data, slug, checkedFilters, brandId)=>{
    const { setShowLoader  } = (0,hooks__WEBPACK_IMPORTED_MODULE_1__/* .useActions */ .ol)();
    // const location = useLocation();
    const Router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { 0: allProduct , 1: setAllProduct  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(data.product);
    const perPageCount = 3;
    const { 0: currentCount , 1: setCurrentCount  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(perPageCount);
    const { 0: filterOption , 1: setFilterOption  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(checkedFilters || null);
    const { 0: filters , 1: setFilters  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(data.filters || null);
    const { 0: skuList , 1: setSkuList  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const getListingWithPagination = (data)=>{
        if (data) {
            return data.slice(0, perPageCount);
        }
        return [];
    };
    const { 0: product , 1: setProduct  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(getListingWithPagination(data.product) || null);
    const { 0: showSortMenu , 1: setShowSortMenu  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const { 0: productView , 1: setProductView  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("grid");
    const { 0: showFilter , 1: setShowFilter  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    function removeDuplicates(arr) {
        return arr.filter((item, index)=>arr.indexOf(item) === index);
    }
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (!allProduct) {
            setShowLoader(true);
        } else {
            setShowLoader(false);
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        allProduct
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        setShowLoader(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        slug,
        checkedFilters
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (localStorage) {
            setSkuList((0,helpers_compare_helper__WEBPACK_IMPORTED_MODULE_3__/* .getSkuList */ .NX)());
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    const compareCheckBoxHandler = (sku)=>{
        if (localStorage) {
            (0,helpers_compare_helper__WEBPACK_IMPORTED_MODULE_3__/* .AddRemoveToCompare */ .$D)(sku);
            setSkuList((0,helpers_compare_helper__WEBPACK_IMPORTED_MODULE_3__/* .getSkuList */ .NX)());
        }
    };
    const updateFilter = (filterOption)=>{
        setShowSortMenu(false);
        const nameArray = removeDuplicates(filterOption.map((res)=>res.name));
        const valueArray = [];
        nameArray.forEach((name)=>{
            const filteredValue = filterOption.filter((filter)=>filter.name === name);
            const filter = filteredValue.map((res)=>res.value).join("~");
            valueArray.push(filter);
        });
        if (nameArray.length > 0 && valueArray.length > 0) {
            const url = `/${nameArray.join(",")}/${valueArray.join(",")}/${brandId}/${slug}.html`;
            Router.replace(url);
            // Router.repla(url);
            setShowLoader(true);
        } else {
            Router.replace(`/${slug}.html`);
        }
    };
    const handleChange = (name, value, checked)=>{
        const index = filterOption.findIndex((filter)=>filter.name === name && filter.value === value);
        const newArray = [
            ...filterOption
        ];
        if (index < 0) {
            if (checked) {
                newArray.push({
                    name,
                    value
                });
            }
        } else if (!checked) {
            newArray.splice(index, 1);
        }
        setShowSortMenu(false);
        setFilterOption(newArray);
        updateFilter(newArray);
    };
    const colorChangeHandler = (productId, seName, color)=>{
        const storageString = localStorage.getItem("selectedProducts");
        const selectedProducts = storageString ? JSON.parse(storageString) : [];
        const index = selectedProducts.findIndex((product)=>product.productId === productId);
        const productObject = {
            productId,
            seName,
            color
        };
        if (index > -1) {
            selectedProducts[index] = productObject;
        } else {
            selectedProducts.push(productObject);
        }
        localStorage.setItem("selectedProducts", JSON.stringify(selectedProducts));
    };
    const loadMore = ()=>{
        const count = currentCount + perPageCount;
        const products = allProduct.slice(currentCount, count);
        setCurrentCount(count);
        setProduct((prev)=>[
                ...prev,
                ...products
            ]);
    };
    const clearFilters = ()=>{
        setFilterOption([]);
        updateFilter([]);
    };
    const sortProductJson = (type)=>{
        // setProduct([]);
        setCurrentCount(perPageCount);
        let newList = [
            ...allProduct
        ];
        if (type === 1) {
            newList = newList.sort((pro1, pro2)=>pro1.id > pro2.id ? 1 : -1);
        } else if (type === 2) {
            newList = newList.sort((pro1, pro2)=>pro1.salePrice > pro2.salePrice ? 1 : -1);
        } else if (type === 3) {
            newList = newList.sort((pro1, pro2)=>pro1.salePrice < pro2.salePrice ? 1 : -1);
        }
        setShowSortMenu(false);
        setAllProduct(newList);
        setProduct(getListingWithPagination(newList));
    };
    return {
        filters,
        product,
        totalCount: allProduct.length,
        showSortMenu,
        productView,
        showFilter,
        skuList,
        compareCheckBoxHandler,
        handleChange,
        colorChangeHandler,
        setFilters,
        setProduct,
        loadMore,
        sortProductJson,
        setShowSortMenu,
        setProductView,
        setShowFilter,
        clearFilters
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductListController);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;