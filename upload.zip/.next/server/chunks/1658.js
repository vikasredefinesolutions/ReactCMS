"use strict";
exports.id = 1658;
exports.ids = [1658];
exports.modules = {

/***/ 1658:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mock_properties_mock__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7961);
/* harmony import */ var pages_ProductList_components_PorudctComponent_Product__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6450);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_FilterBar_layout1__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8256);
/* harmony import */ var _components_Filters_filterChips__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1848);
/* harmony import */ var _components_Filters_flyoutFilter__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3916);
/* harmony import */ var _components_Filters_sideFilter__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1801);
/* harmony import */ var _components_PorudctComponent_ListView__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1719);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([pages_ProductList_components_PorudctComponent_Product__WEBPACK_IMPORTED_MODULE_2__, _components_FilterBar_layout1__WEBPACK_IMPORTED_MODULE_4__, _components_PorudctComponent_ListView__WEBPACK_IMPORTED_MODULE_8__]);
([pages_ProductList_components_PorudctComponent_Product__WEBPACK_IMPORTED_MODULE_2__, _components_FilterBar_layout1__WEBPACK_IMPORTED_MODULE_4__, _components_PorudctComponent_ListView__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const Layout1 = ({ filters , products , checkedFilters , totalCount , showFilter , showSortMenu , productView , skuList , setShowSortMenu , setShowFilter , setProductView , colorChangeHandler , handleChange , loadMore , sortProductJson , clearFilters , compareCheckBoxHandler  })=>{
    // console.log(products);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            id: "",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "bg-white",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "container mx-auto px-2 lg:px-0",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        "aria-labelledby": "products-heading",
                        className: "mt-8 overflow-hidden",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                id: "products-heading",
                                className: "sr-only",
                                children: "Products"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-wrap -mx-4",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: mock_properties_mock__WEBPACK_IMPORTED_MODULE_1__/* .properties.filter_box.layout */ .a.filter_box.layout !== "flyout" ? "w-full lg:w-3/12 px-4" : "",
                                        children: filters.length > 0 && (mock_properties_mock__WEBPACK_IMPORTED_MODULE_1__/* .properties.filter_box.layout */ .a.filter_box.layout === "flyout" ? showFilter && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Filters_flyoutFilter__WEBPACK_IMPORTED_MODULE_6__["default"], {
                                            filters: filters,
                                            handleChange: handleChange,
                                            checkedFilters: checkedFilters,
                                            closeFilter: setShowFilter
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Filters_sideFilter__WEBPACK_IMPORTED_MODULE_7__["default"], {
                                            filters: filters,
                                            handleChange: handleChange,
                                            checkedFilters: checkedFilters
                                        }))
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: `w-full${mock_properties_mock__WEBPACK_IMPORTED_MODULE_1__/* .properties.filter_box.layout */ .a.filter_box.layout === "flyout" ? "" : " lg:w-9/12"} px-4`,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_FilterBar_layout1__WEBPACK_IMPORTED_MODULE_4__["default"], {
                                                totalCount,
                                                showSortMenu,
                                                sortProductJson,
                                                sortOpenHandler: setShowSortMenu,
                                                setProductView,
                                                productView,
                                                setShowFilter
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Filters_filterChips__WEBPACK_IMPORTED_MODULE_5__["default"], {
                                                clearFilters,
                                                checkedFilters,
                                                handleChange
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "mt-8 relative",
                                                id: "gridview",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "relative w-full pb-6 -mb-6",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                                            role: "list",
                                                            className: `grid grid-cols-1 gap-6 lg:gap-8 mb-8${productView === "grid" ? " lg:grid-cols-" + mock_properties_mock__WEBPACK_IMPORTED_MODULE_1__/* .properties.product_list_box.box_count */ .a.product_list_box.box_count : ""}`,
                                                            children: products.map((product, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react__WEBPACK_IMPORTED_MODULE_3__.Fragment, {
                                                                    children: productView === "grid" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(pages_ProductList_components_PorudctComponent_Product__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                                                        skuList: skuList,
                                                                        compareCheckBoxHandler: compareCheckBoxHandler,
                                                                        product: product,
                                                                        colorChangeHandler: colorChangeHandler
                                                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_PorudctComponent_ListView__WEBPACK_IMPORTED_MODULE_8__["default"], {
                                                                        product: product,
                                                                        colorChangeHandler: colorChangeHandler
                                                                    })
                                                                }, index))
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "py-24 border-t border-t-gray-300",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                className: "text-center",
                                                                children: [
                                                                    "You've seen ",
                                                                    products.length,
                                                                    " Products out of",
                                                                    " ",
                                                                    totalCount
                                                                ]
                                                            }),
                                                            products.length < totalCount && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                onClick: loadMore,
                                                                type: "submit",
                                                                className: "mt-8 w-auto mx-auto bg-white border border-gray-800 py-3 px-24 flex items-center text-center justify-center text-base font-medium text-gray-800 hover:bg-blue-500 hover:border-blue-500 hover:text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500",
                                                                children: "View More"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout1);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;