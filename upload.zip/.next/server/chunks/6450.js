"use strict";
exports.id = 6450;
exports.ids = [6450];
exports.modules = {

/***/ 3632:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6183);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_2__]);
hooks__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const Price = ({ value , prices  })=>{
    let price = 0;
    const currency = (0,hooks__WEBPACK_IMPORTED_MODULE_2__/* .useTypedSelector */ .ix)((state)=>state.store.currency);
    if (value) prices === null ? price = 0 : price = +value;
    if (prices) {
        prices === null ? price = 0 : prices.msrp;
    }
    const toShow = price.toFixed(2);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            currency,
            toShow
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Price);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4374:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7372);
/* harmony import */ var _mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_icons_material_FavoriteBorderOutlined__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5967);
/* harmony import */ var _mui_icons_material_FavoriteBorderOutlined__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_FavoriteBorderOutlined__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var appComponents_modals_ForgotModal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5402);
/* harmony import */ var appComponents_modals_LoginModal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(365);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9648);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var services_wishlist_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3237);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([appComponents_modals_ForgotModal__WEBPACK_IMPORTED_MODULE_3__, appComponents_modals_LoginModal__WEBPACK_IMPORTED_MODULE_4__, axios__WEBPACK_IMPORTED_MODULE_5__, services_wishlist_service__WEBPACK_IMPORTED_MODULE_7__]);
([appComponents_modals_ForgotModal__WEBPACK_IMPORTED_MODULE_3__, appComponents_modals_LoginModal__WEBPACK_IMPORTED_MODULE_4__, axios__WEBPACK_IMPORTED_MODULE_5__, services_wishlist_service__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const Wishlist = ({ iswishlist , productId , price , color , name , wishlistId =0  })=>{
    const { 0: showModal , 1: setShowModal  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(null);
    const { 0: wishlist , 1: setWishlist  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
    const customerId = null;
    const wishlistHandler = async ()=>{
        if (!customerId) {
            setShowModal("login");
            return;
        }
        const { data  } = await axios__WEBPACK_IMPORTED_MODULE_5__["default"].get("https://geolocation-db.com/json/");
        const requestObject = {
            storeproductWishListModel: {
                id: 0,
                rowVersion: "",
                location: `${data.city}, ${data.state}, ${data.country_name}, ${data.postal}`,
                ipAddress: data.IPv4,
                macAddress: "00-00-00-00-00-00",
                customerId: customerId || 0,
                productId: productId,
                quantity: 1,
                name: name,
                color: color,
                price: price,
                recStatus: "A"
            }
        };
        (0,services_wishlist_service__WEBPACK_IMPORTED_MODULE_7__/* .AddToWishlist */ .h6)(requestObject);
        setWishlist(true);
    };
    const removeWishlistHandler = ()=>{
        if (wishlistId > 0) {
            (0,services_wishlist_service__WEBPACK_IMPORTED_MODULE_7__/* .removeWishlist */ .Ih)(wishlistId);
            setWishlist(false);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        setWishlist(iswishlist);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        iswishlist
    ]);
    const modalHandler = (arg)=>{
        setShowModal(arg);
    };
    const wishlistHtml = wishlist ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_1___default()), {
        sx: {
            color: "orange"
        },
        onClick: removeWishlistHandler
    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_FavoriteBorderOutlined__WEBPACK_IMPORTED_MODULE_2___default()), {
        onClick: wishlistHandler
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            showModal === "login" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_modals_LoginModal__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                modalHandler: modalHandler
            }),
            showModal === "forgot" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_modals_ForgotModal__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                modalHandler: modalHandler
            }),
            wishlistHtml
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Wishlist);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9596:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$D": () => (/* binding */ AddRemoveToCompare),
/* harmony export */   "NX": () => (/* binding */ getSkuList),
/* harmony export */   "VN": () => (/* binding */ getCompareLink)
/* harmony export */ });
/* unused harmony export checkCompare */
const AddRemoveToCompare = (sku)=>{
    if (localStorage) {
        const skuList = getSkuList();
        const index = skuList.findIndex((_sku)=>_sku === sku);
        if (index > -1) {
            skuList.splice(index, 1);
        } else {
            skuList.push(sku);
        }
        localStorage.setItem("compareList", JSON.stringify(skuList));
    }
};
const checkCompare = (sku)=>{
    if (localStorage) {
        const skuList = getSkuList();
        const index = skuList.indexOf((_sku)=>_sku === sku);
        if (index) {
            return true;
        }
    }
    return false;
};
const getCompareLink = ()=>{
    if (localStorage) {
        const skuList = getSkuList();
        return `/itempage/Productcomapre?SKU=${skuList.toString()}`;
    }
    return "";
};
const getSkuList = ()=>{
    const data = localStorage.getItem("compareList");
    return data ? JSON.parse(data) : [];
};


/***/ }),

/***/ 6450:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var api_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1836);
/* harmony import */ var appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2337);
/* harmony import */ var appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3632);
/* harmony import */ var appComponents_ui_Wishlist__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4374);
/* harmony import */ var helpers_compare_helper__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9596);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _ProductBox_controller__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3574);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_3__, appComponents_ui_Wishlist__WEBPACK_IMPORTED_MODULE_4__]);
([appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_3__, appComponents_ui_Wishlist__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









// import Price from '../reusables/Price';
// import Wishlist from '../ui/Wishlist';
const ProductComponent = ({ product , skuList , colorChangeHandler , compareCheckBoxHandler  })=>{
    const { currentProduct , origin , setCurrentProduct  } = (0,_ProductBox_controller__WEBPACK_IMPORTED_MODULE_7__["default"])({
        product,
        colorChangeHandler
    });
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        setCurrentProduct(product.getProductImageOptionList[0]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        product
    ]);
    // console.log(product);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
        className: "text-center flex",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "h-hull w-full",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex text-center lg:w-auto h-full",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "relative border border-gray-200 pb-4 w-full",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-full bg-white rounded-md overflow-hidden aspect-w-1 aspect-h-1",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Image__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    src: currentProduct.imageName,
                                    alt: "",
                                    className: "w-auto h-auto m-auto max-h-[400px]",
                                    height: 400,
                                    width: 350,
                                    cKey: currentProduct.id
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "absolute top-5 right-5 text-gray-800 p-1 z-25",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        className: "",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_ui_Wishlist__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                            productId: product.id,
                                            name: product.name,
                                            color: currentProduct.colorName,
                                            price: product.salePrice,
                                            wishlistId: product.wishListId,
                                            iswishlist: product.iswishlist
                                        })
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mt-6 relative",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "mt-1",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        className: "inline-block max-h-12",
                                        src: `${api_config__WEBPACK_IMPORTED_MODULE_1__/* ["default"].mediaBaseUrl */ .Z.mediaBaseUrl}/rdc${product.brandlogo.replace("/rdc", "")}`,
                                        alt: product.brandlogo
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "relative mt-1 text-anchor hover:text-anchor-hover h-14 text-ellipsis overflow-hidden line-clamp-2",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                        href: `${origin}/${product.sename}.html?v=product-detail&altview=1`,
                                        className: "relative underline min-h-[48px]",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "absolute inset-0"
                                                }),
                                                product.name
                                            ]
                                        })
                                    }, product.id)
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "mt-2 text-black text-base tracking-wider",
                                    children: [
                                        "MSRP ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            value: product.salePrice
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "form-group mt-2",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                        className: "checkbox-inline",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                checked: skuList.includes(product.sku),
                                                onChange: ()=>compareCheckBoxHandler(product.sku),
                                                type: "checkbox"
                                            }),
                                            " ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                children: skuList.length && skuList.includes(product.sku) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                    href: (0,helpers_compare_helper__WEBPACK_IMPORTED_MODULE_8__/* .getCompareLink */ .VN)(),
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                                        children: [
                                                            "Compare ",
                                                            skuList.length
                                                        ]
                                                    })
                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                    children: "Add to Compare"
                                                })
                                            })
                                        ]
                                    })
                                }),
                                product.getProductImageOptionList.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                    role: "list",
                                    className: "flex items-center mt-2 justify-center space-x-1",
                                    children: product.getProductImageOptionList.map((subRow, index)=>index < 6 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            className: `w-7 h-7 border-2${subRow.id === currentProduct.id ? " border-secondary" : ""}`,
                                            onClick: ()=>{
                                                colorChangeHandler(product.id, product.sename || "", subRow.colorName);
                                                setCurrentProduct(subRow);
                                            },
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                src: `${api_config__WEBPACK_IMPORTED_MODULE_1__/* ["default"].mediaBaseUrl */ .Z.mediaBaseUrl}${subRow.imageName}`,
                                                alt: "",
                                                title: "",
                                                className: "max-h-full m-auto"
                                            })
                                        }) : null)
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductComponent);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3574:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const ProductBoxController = ({ product , colorChangeHandler  })=>{
    const { 0: origin , 1: setOrigin  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
    const { 0: currentProduct , 1: setCurrentProduct  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(product.getProductImageOptionList[0]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        colorChangeHandler(product.id, product.sename || "", product.getProductImageOptionList[0].colorName);
        if (window !== undefined) {
            setOrigin(window.location.origin);
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        setCurrentProduct(product.getProductImageOptionList[0]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        product
    ]);
    return {
        currentProduct,
        origin,
        setCurrentProduct
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductBoxController);


/***/ }),

/***/ 3237:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ih": () => (/* binding */ removeWishlist),
/* harmony export */   "h6": () => (/* binding */ AddToWishlist),
/* harmony export */   "sA": () => (/* binding */ getWishlist)
/* harmony export */ });
/* harmony import */ var _utils_axios_util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(795);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__]);
_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const AddToWishlist = async (payload)=>{
    const url = "/StoreProductWishList/createstoreproductwishlist.json";
    const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__/* .SendAsyncV2 */ .y)({
        url: url,
        method: "POST",
        data: payload
    });
    return res.data;
};
const getWishlist = async (customerId)=>{
    const url = `/StoreProductWishList/getwishlistbycustomerid/${customerId}.json`;
    const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__/* .SendAsyncV2 */ .y)({
        url: url,
        method: "GET"
    });
    return res.data;
};
const removeWishlist = async (wishlistId)=>{
    const url = "/StoreProductWishList/deletewishlistbyid.json";
    const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_0__/* .SendAsyncV2 */ .y)({
        url: url,
        method: "DELETE",
        data: {
            wishlistId
        }
    });
    return res.data;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;