"use strict";
exports.id = 151;
exports.ids = [151];
exports.modules = {

/***/ 3544:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1480);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);



const IOSSwitch = _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default()((props)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Switch, {
        focusVisibleClassName: ".Mui-focusVisible",
        disableRipple: true,
        ...props
    }))(()=>({
        width: "4rem",
        height: 28,
        padding: 0,
        "& .MuiSwitch-switchBase": {
            padding: 0,
            margin: 2,
            transitionDuration: "200ms",
            "&.Mui-checked": {
                transform: "translateX(36px)",
                color: "#fff",
                "& + .MuiSwitch-track": {
                    backgroundColor: "#159e48",
                    opacity: 1,
                    border: 0
                },
                "&.Mui-disabled + .MuiSwitch-track": {
                    opacity: 0.5
                }
            },
            "&.Mui-focusVisible .MuiSwitch-thumb": {
                color: "#33cf4d",
                border: "6px solid #fff"
            }
        },
        "& .MuiSwitch-thumb": {
            boxSizing: "border-box",
            width: 24,
            height: 24,
            borderRadius: 4,
            opacity: "1 !important"
        },
        "& .MuiSwitch-track": {
            borderRadius: 4,
            backgroundColor: "#475569",
            opacity: 1,
            "&:after, &:before": {
                color: "white",
                fontSize: "0.7rem",
                position: "absolute",
                top: "6px"
            },
            "&:after": {
                content: "'Yes'",
                left: "10px"
            },
            "&:before": {
                content: "'No'",
                right: "10px"
            }
        }
    }));
const SwitchBox = ({ checked , onchange  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormControlLabel, {
        control: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(IOSSwitch, {
            onChange: onchange,
            sx: {
                m: 1
            },
            defaultChecked: checked
        }),
        label: ""
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SwitchBox);


/***/ }),

/***/ 151:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var appComponents_modals_AddAddress__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8689);
/* harmony import */ var appComponents_ui_switch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3544);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6183);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var services_address_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3411);
/* harmony import */ var _mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3188);
/* harmony import */ var _mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_icons_material_Edit__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6902);
/* harmony import */ var _mui_icons_material_Edit__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Edit__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var helpers_getLocation__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8443);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([appComponents_modals_AddAddress__WEBPACK_IMPORTED_MODULE_1__, hooks__WEBPACK_IMPORTED_MODULE_3__, services_address_service__WEBPACK_IMPORTED_MODULE_5__, helpers_getLocation__WEBPACK_IMPORTED_MODULE_8__]);
([appComponents_modals_AddAddress__WEBPACK_IMPORTED_MODULE_1__, hooks__WEBPACK_IMPORTED_MODULE_3__, services_address_service__WEBPACK_IMPORTED_MODULE_5__, helpers_getLocation__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






// import { SwitchProps } from '@mui/material/Switch';



const UserAddress = ()=>{
    const { getStoreCustomer  } = (0,hooks__WEBPACK_IMPORTED_MODULE_3__/* .useActions */ .ol)();
    const { 0: showAddressPopup , 1: setShowAddresss  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const { 0: showTab , 1: setShowTab  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("S");
    const { 0: editData , 1: setEditData  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(null);
    const address = (0,hooks__WEBPACK_IMPORTED_MODULE_3__/* .useTypedSelector */ .ix)((state)=>state.user.customer.customerAddress);
    const customerId = (0,hooks__WEBPACK_IMPORTED_MODULE_3__/* .useTypedSelector */ .ix)((state)=>state.user.id);
    const closePopupHandler = ()=>{
        setShowAddresss("");
        setEditData(null);
    };
    const getAddress = (type)=>{
        return address.filter((res)=>res.addressType === type);
    };
    const submitHandler = async (values)=>{
        const data = await (0,helpers_getLocation__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
        const obj = {
            storeCustomerAddressModel: {
                id: editData ? editData.id : 0,
                rowVersion: editData ? editData.rowVersion : "",
                location: `${data.city}, ${data.state}, ${data.country_name}, ${data.postal}`,
                ipAddress: data.IPv4,
                macAddress: "00-00-00-00-00-00",
                customerId: customerId || 0,
                firstname: values.firstname,
                lastName: values.lastName,
                email: values.email,
                address1: values.address1,
                address2: values.address2 || " ",
                suite: values.suite || " ",
                city: values.city,
                state: values.state,
                postalCode: values.postalCode,
                phone: values.phone,
                fax: values.fax,
                countryName: values.countryName,
                countryCode: "91",
                addressType: showAddressPopup,
                isDefault: values.isDefault,
                recStatus: "A",
                companyName: values.companyName || " "
            }
        };
        if (editData) {
            await (0,services_address_service__WEBPACK_IMPORTED_MODULE_5__/* .UpdateUserAddress */ .yE)(obj);
        } else {
            await (0,services_address_service__WEBPACK_IMPORTED_MODULE_5__/* .CreateUserAddress */ .cX)(obj);
        }
        await getStoreCustomer(customerId || 0);
        setShowAddresss("");
    };
    const deleteAddress = async (id, rowVersion)=>{
        const isConfirm = await confirm("Are you sure? You want to delete this.");
        const location = await (0,helpers_getLocation__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
        if (isConfirm) {
            const obj = {
                args: {
                    id: id,
                    rowVersion: rowVersion,
                    status: 0,
                    location: `${location.city}, ${location.state}, ${location.country_name}, ${location.postal}`,
                    ipAddress: location.IPv4,
                    macAddress: "00-00-00-00-00-00"
                }
            };
            (0,services_address_service__WEBPACK_IMPORTED_MODULE_5__/* .deleteCustomerAddress */ .VR)(obj);
            await getStoreCustomer(customerId || 0);
        }
    };
    const handleChange = async (checked, id)=>{
        const obj = {
            isDefault: checked,
            addressId: id,
            customerId: customerId || 0,
            addressType: showTab
        };
        await (0,services_address_service__WEBPACK_IMPORTED_MODULE_5__/* .udpateIsDefaultAddress */ .ap)(obj);
        await getStoreCustomer(customerId || 0);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                className: "container mx-auto bg-gray-100 px-6 py-6 mt-5 mb-5",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "max-w-7xl py-10 mx-auto",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        "x-data": "{activeTab:01, activeClass: 'tab py-2 mr-1 px-2 block hover:text-primary text-primary focus:outline-none text-default-text border-b-2 font-medium border-primary', inactiveClass : 'tab py-2 px-2 block text-default-text hover:text-primary focus:outline-none mr-1 rounded-sm font-medium border-slate-300 hover:border-primary' }",
                        className: "w-full",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                className: "w-full flex justify-center max-w-4xl mx-auto flex-wrap",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: "mr-0.5 md:mr-0 font-semibold",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            onClick: ()=>setShowTab("S"),
                                            className: `tab py-2 mr-1 px-2 block text-primary focus:outline-none text-default-text border-b-2 font-medium${showTab === "B" ? "" : " border-primary"}`,
                                            children: "Shipping Address"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: "mr-0.5 md:mr-0 font-semibold",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            onClick: ()=>setShowTab("B"),
                                            className: `tab py-2 mr-1 px-2 block text-primary focus:outline-none text-default-text border-b-2 font-medium${showTab === "S" ? "" : " border-primary"}`,
                                            children: "Billing Address"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "mx-auto pt-10",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "panel-01 tab-content pb-4",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "flex flex-wrap lg:-mx-3 gap-y-6",
                                            children: getAddress(showTab).map((address_obj, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "w-full lg:w-1/2 lg:px-3",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "border-2 border-gray-300",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "bg-gray-200 font-semibold border-b last:border-b-0 border-gray-300 flex flex-wrap p-2",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "w-2/5",
                                                                        children: "Name:"
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                        className: "",
                                                                        children: [
                                                                            address_obj.firstname,
                                                                            " ",
                                                                            address_obj.lastName
                                                                        ]
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "border-b last:border-b-0 border-gray-300 flex flex-wrap p-2",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "w-2/5",
                                                                        children: "Address:"
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                        className: "",
                                                                        children: [
                                                                            address_obj.address1,
                                                                            address_obj.address2,
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                                            [
                                                                                address_obj.city,
                                                                                address_obj.countryName,
                                                                                address_obj.postalCode, 
                                                                            ].join(", ")
                                                                        ]
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "border-b last:border-b-0 border-gray-300 flex flex-wrap p-2",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "w-2/5",
                                                                        children: "Make Primary:"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "flex items-center justify-end",
                                                                        "x-data": "{ checked: true }",
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-16 relative",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_ui_switch__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                                                onchange: (e)=>{
                                                                                    handleChange(e.target.checked, address_obj.id);
                                                                                },
                                                                                checked: address_obj.isDefault
                                                                            })
                                                                        })
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "border-b last:border-b-0 border-gray-300 flex flex-wrap p-2",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "w-2/5",
                                                                        children: "Action:"
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                        className: "flex flex-wrap gap-x-4",
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Edit__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                                                className: "text-primary",
                                                                                onClick: ()=>{
                                                                                    setShowAddresss(showTab);
                                                                                    setEditData(address_obj);
                                                                                }
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                                                onClick: ()=>deleteAddress(address_obj.id, address_obj.rowVersion),
                                                                                className: "text-red-500"
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                }, index))
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "mt-4 text-center",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                className: "btn btn-primary",
                                                type: "button",
                                                "data-modal-toggle": "AddNewAddress",
                                                onClick: ()=>setShowAddresss(showTab),
                                                children: [
                                                    "Add ",
                                                    showTab === "S" ? "Shipping" : "Billing",
                                                    " Address",
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                        className: "fa fa-plus ml-1",
                                                        "aria-hidden": "true"
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            }),
            showAddressPopup && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_modals_AddAddress__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                closePopupHandler,
                submitHandler,
                editData
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UserAddress);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;