"use strict";
exports.id = 3916;
exports.ids = [3916];
exports.modules = {

/***/ 3916:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const FlyOutFilter = ({ filters , checkedFilters , handleChange , closeFilter  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "bg-gray-100 fixed top-0 w-80 z-50 h-screen overflow-auto left-0",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "border-b border-b-neutral-300 p-2 sticky top-0 left-0 bg-gray-100 flex items-center justify-between",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "text-lg font-semibold text-gray-900",
                        children: "Filters"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            onClick: ()=>closeFilter(false),
                            className: "material-icons-outlined",
                            children: "close"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "p-4 pt-0",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                    className: "mt-4 filter-box filter-type",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: filters.map((filter, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: `py-4${index === 0 ? "" : " border-t border-neutral-300"}`,
                                "x-data": "{ open: true }",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        className: "flex items-center justify-between w-full group mb-1",
                                        "aria-expanded": "true",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "text-lg font-medium text-gray-900 hidden lg:block uppercase",
                                            children: filter.label
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "text-sm",
                                        "x-show": "open",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                            className: filter.label.toLowerCase() === "color" ? "flex flex-wrap items-center gap-x-1.5 gap-y-2" : "pb-6 pt-2 space-y-3",
                                            children: filter.options.map((option)=>{
                                                const checked = checkedFilters.findIndex((res)=>res.name === filter.label && res.value === option.name) > -1;
                                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                    children: option.name || option.colorCode ? filter.label === "Color" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        className: `w-8 h-8 border-2 hover:border-secondary p-0.5 ${checked && "border-secondary"}`,
                                                        style: {
                                                            background: option.colorCode
                                                        },
                                                        onClick: ()=>handleChange(filter.label, option.name, !checked)
                                                    }, index) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                                        className: "flex items-center",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                name: filter.label,
                                                                value: option.name,
                                                                checked: checked,
                                                                type: "checkbox",
                                                                onChange: (e)=>{
                                                                    const { name , value , checked  } = e.target;
                                                                    handleChange(name, value, checked);
                                                                },
                                                                className: "h-4 w-4 border-gray-300 rounded text-indigo-600 focus:ring-indigo-500"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                htmlFor: "brandfil-0",
                                                                className: "ml-3 text-black text-base",
                                                                children: [
                                                                    option.name,
                                                                    " (",
                                                                    option.productCount,
                                                                    ")"
                                                                ]
                                                            })
                                                        ]
                                                    }) : null
                                                });
                                            })
                                        })
                                    })
                                ]
                            }, index))
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FlyOutFilter);


/***/ })

};
;