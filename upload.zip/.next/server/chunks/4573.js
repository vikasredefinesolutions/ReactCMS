"use strict";
exports.id = 4573;
exports.ids = [4573];
exports.modules = {

/***/ 4573:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var appComponents_modals_AddAddress__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8689);
/* harmony import */ var helpers_getLocation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8443);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6183);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var services_address_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3411);
/* harmony import */ var services_user_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1488);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([appComponents_modals_AddAddress__WEBPACK_IMPORTED_MODULE_1__, helpers_getLocation__WEBPACK_IMPORTED_MODULE_2__, hooks__WEBPACK_IMPORTED_MODULE_3__, services_address_service__WEBPACK_IMPORTED_MODULE_6__, services_user_service__WEBPACK_IMPORTED_MODULE_7__]);
([appComponents_modals_AddAddress__WEBPACK_IMPORTED_MODULE_1__, helpers_getLocation__WEBPACK_IMPORTED_MODULE_2__, hooks__WEBPACK_IMPORTED_MODULE_3__, services_address_service__WEBPACK_IMPORTED_MODULE_6__, services_user_service__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






// import { updateCustomer } from 'redux/slices/user.slice';


const AddressPopupLayout1 = ({ showChangeAddressPopup , addressArray , changeAddres , closeShippingPopup  })=>{
    const { updateCustomer  } = (0,hooks__WEBPACK_IMPORTED_MODULE_3__/* .useActions */ .ol)();
    const { 0: addressType , 1: setAddressType  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)("");
    const customerId = (0,hooks__WEBPACK_IMPORTED_MODULE_3__/* .useTypedSelector */ .ix)((state)=>state.user.id);
    const closePopupHandler = ()=>{
        setAddressType("");
    };
    const submitHandler = async (values)=>{
        const data = await (0,helpers_getLocation__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
        const obj = {
            storeCustomerAddressModel: {
                id: 0,
                rowVersion: "",
                location: `${data.city}, ${data.state}, ${data.country_name}, ${data.postal}`,
                ipAddress: data.IPv4,
                macAddress: "00-00-00-00-00-00",
                customerId: customerId || 0,
                firstname: values.firstname,
                lastName: values.lastName,
                email: values.email,
                address1: values.address1,
                address2: values.address2 || " ",
                suite: values.suite || " ",
                city: values.city,
                state: values.state,
                postalCode: values.postalCode,
                phone: values.phone,
                fax: values.fax,
                countryName: values.countryName,
                countryCode: "91",
                addressType: addressType,
                isDefault: values.isDefault,
                recStatus: "A",
                companyName: values.companyName || " "
            }
        };
        await (0,services_address_service__WEBPACK_IMPORTED_MODULE_6__/* .CreateUserAddress */ .cX)(obj);
        const customer = await (0,services_user_service__WEBPACK_IMPORTED_MODULE_7__/* .getStoreCustomer */ .em)(customerId || 0);
        updateCustomer({
            customer
        });
        setAddressType("");
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                id: "shippingaddressModal",
                "aria-hidden": "true",
                className: "overflow-y-auto overflow-x-hidden fixed inset-0 z-50 justify-center items-center h-modal max-h-screen",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-full h-full bg-black bg-opacity-50 flex items-center justify-center",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "relative w-full max-w-xl",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "relative bg-white rounded-lg shadow max-h-screen overflow-y-auto",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex justify-between items-start p-4 rounded-t border-b dark:border-gray-600",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h3", {
                                            className: "text-xl font-semibold text-gray-900 dark:text-white",
                                            children: [
                                                "Change ",
                                                showChangeAddressPopup === 1 ? "Shipping" : "Billing",
                                                " ",
                                                "Address"
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            onClick: closeShippingPopup,
                                            type: "button",
                                            className: "text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-600 dark:hover:text-white",
                                            "data-modal-toggle": "shippingaddressModal",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                className: "w-5 h-5",
                                                fill: "currentColor",
                                                viewBox: "0 0 20 20",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                    fillRule: "evenodd",
                                                    d: "M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z",
                                                    clipRule: "evenodd"
                                                })
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "p-6 space-y-6",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "",
                                        id: "",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "flex flex-wrap -mx-3 gap-y-6",
                                            children: addressArray.filter((address)=>address.addressType === (showChangeAddressPopup === 1 ? "S" : "B")).map((address, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "w-full lg:w-1/2 px-3",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "bg-gray-100 border p-2 border-300",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "mb-3 ",
                                                                children: [
                                                                    address.firstname,
                                                                    " ",
                                                                    address.lastName,
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                                    address.address1,
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                                    [
                                                                        address.city,
                                                                        address.state,
                                                                        address.postalCode, 
                                                                    ].join(", "),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                                    address.countryName,
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                                    address.phone
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "mb-3",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                                    href: "/",
                                                                    className: "text-anchor",
                                                                    children: "Edit"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                    onClick: ()=>changeAddres(address),
                                                                    className: "btn btn-sm btn-primary",
                                                                    "data-modal-toggle": "shippingaddressModal",
                                                                    children: "SHIP TO THIS ADDRESS"
                                                                })
                                                            })
                                                        ]
                                                    })
                                                }, index))
                                        })
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex items-center justify-between p-6 space-x-2 rounded-b border-t border-gray-200 dark:border-gray-600",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            "data-modal-toggle": "shippingaddressModal",
                                            type: "button",
                                            onClick: closeShippingPopup,
                                            className: "btn btn-outline-primary",
                                            children: "Cancel"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            "data-modal-toggle": "addshippingaddressModal",
                                            type: "button",
                                            className: "btn btn-primary",
                                            onClick: ()=>setAddressType(showChangeAddressPopup === 1 ? "S" : "B"),
                                            children: "Add New Address"
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                })
            }),
            addressType && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_modals_AddAddress__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                closePopupHandler,
                submitHandler,
                editData: {}
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AddressPopupLayout1);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;