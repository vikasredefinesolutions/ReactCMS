"use strict";
exports.id = 8981;
exports.ids = [8981];
exports.modules = {

/***/ 8981:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants_store_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7297);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6183);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _layouts_layout1__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1658);
/* harmony import */ var _layouts_layout2__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7607);
/* harmony import */ var _layouts_layout3__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5207);
/* harmony import */ var _ProductListController__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7828);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_2__, _layouts_layout1__WEBPACK_IMPORTED_MODULE_4__, _layouts_layout2__WEBPACK_IMPORTED_MODULE_5__, _layouts_layout3__WEBPACK_IMPORTED_MODULE_6__, _ProductListController__WEBPACK_IMPORTED_MODULE_7__]);
([hooks__WEBPACK_IMPORTED_MODULE_2__, _layouts_layout1__WEBPACK_IMPORTED_MODULE_4__, _layouts_layout2__WEBPACK_IMPORTED_MODULE_5__, _layouts_layout3__WEBPACK_IMPORTED_MODULE_6__, _ProductListController__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const ProductList = ({ pageData , slug  })=>{
    const { checkedFilters  } = pageData;
    const { filters , product , totalCount , productView , showFilter , showSortMenu , skuList , compareCheckBoxHandler , handleChange , colorChangeHandler , loadMore , sortProductJson , setShowSortMenu , setProductView , setShowFilter , clearFilters ,  } = (0,_ProductListController__WEBPACK_IMPORTED_MODULE_7__["default"])(pageData, slug, checkedFilters || [], pageData.brandId);
    const storeLayout = (0,hooks__WEBPACK_IMPORTED_MODULE_2__/* .useTypedSelector */ .ix)((state)=>state.store.layout);
    let Layout = react__WEBPACK_IMPORTED_MODULE_3__.Fragment;
    if (storeLayout === _constants_store_constant__WEBPACK_IMPORTED_MODULE_1__/* ._Store.type1 */ .up.type1) {
        Layout = _layouts_layout1__WEBPACK_IMPORTED_MODULE_4__["default"];
    } else if (storeLayout === _constants_store_constant__WEBPACK_IMPORTED_MODULE_1__/* ._Store.type2 */ .up.type2) {
        Layout = _layouts_layout2__WEBPACK_IMPORTED_MODULE_5__["default"];
    } else if (storeLayout === _constants_store_constant__WEBPACK_IMPORTED_MODULE_1__/* ._Store.type3 */ .up.type3) {
        Layout = _layouts_layout3__WEBPACK_IMPORTED_MODULE_6__["default"];
    } else if (storeLayout === _constants_store_constant__WEBPACK_IMPORTED_MODULE_1__/* ._Store.type4 */ .up.type4) {
        Layout = _layouts_layout1__WEBPACK_IMPORTED_MODULE_4__["default"];
    }
    if (totalCount > 0) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Layout, {
            showSortMenu: showSortMenu,
            filters: filters,
            products: product,
            checkedFilters: checkedFilters,
            totalCount: totalCount,
            productView: productView,
            showFilter: showFilter,
            skuList: skuList,
            colorChangeHandler: colorChangeHandler,
            handleChange: handleChange,
            loadMore: loadMore,
            sortProductJson: sortProductJson,
            setShowSortMenu: setShowSortMenu,
            setProductView: setProductView,
            setShowFilter: setShowFilter,
            clearFilters: clearFilters,
            compareCheckBoxHandler: compareCheckBoxHandler
        });
    } else {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
            style: {
                padding: "150px"
            },
            className: "text-center",
            children: [
                " ",
                "No Product Found"
            ]
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductList);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;