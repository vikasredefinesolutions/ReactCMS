"use strict";
exports.id = 3019;
exports.ids = [3019];
exports.modules = {

/***/ 7388:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6183);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_1__]);
hooks__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const AskToLogin = ({ modalHandler  })=>{
    const { id  } = (0,hooks__WEBPACK_IMPORTED_MODULE_1__/* .useTypedSelector */ .ix)((state)=>state.user);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: id === null && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "mt-3 border border-gray-700 p-2 flex flex-wrap justify-between items-center gap-y-2",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "w-full md:w-1/2 text-lg font-bold text-gray-900",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "w-full block",
                            children: "LOGIN OR CREATE AN ACCOUNT"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "w-full block text-base font-normal",
                            children: "to see discounted pricing on this product."
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-full md:w-1/2 text-left flex justify-end",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        onClick: ()=>modalHandler("login"),
                        className: "btn btn-secondary !flex !py-4 items-center justify-center w-full uppercase",
                        children: "Login / Create an account"
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AskToLogin);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7719:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3632);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6183);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__, hooks__WEBPACK_IMPORTED_MODULE_3__]);
([appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__, hooks__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const CalculativeFigure = ()=>{
    var ref;
    const { totalPrice , totalQty , price , logo , additionalLogoCharge  } = (0,hooks__WEBPACK_IMPORTED_MODULE_3__/* .useTypedSelector */ .ix)((state)=>state.product.toCheckout);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "bg-gray-100 p-4 flex flex-wrap items-end justify-between gap-2 text-sm mb-6",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mb-2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "inline-block w-40",
                                children: "Quantity Selected:"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "font-semibold text-base",
                                children: totalQty
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mb-2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "inline-block w-40",
                                children: "Price Per Item:"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "font-semibold text-base",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    value: price
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mb-2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "inline-block w-40",
                                children: "First Logo:"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "font-semibold text-base",
                                children: `${((ref = logo.price) === null || ref === void 0 ? void 0 : ref.length) && logo.price[0] !== "FREE" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    value: logo.price[0]
                                }) : "FREE"}`
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mb-2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "inline-block w-40",
                                children: "Additional Logo(s):"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "font-semibold text-base",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    value: additionalLogoCharge
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "text-base",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "inline-block mb-2",
                        children: "Subtotal:"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "font-semibold text-xl lg:text-3xl",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                            value: totalPrice
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CalculativeFigure);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3830:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6183);
/* harmony import */ var mock_startModal_mock__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4021);
/* harmony import */ var _LogoOption__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2061);
/* harmony import */ var _NextLogoButton__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9182);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_3__, _LogoOption__WEBPACK_IMPORTED_MODULE_5__, _NextLogoButton__WEBPACK_IMPORTED_MODULE_6__]);
([hooks__WEBPACK_IMPORTED_MODULE_3__, _LogoOption__WEBPACK_IMPORTED_MODULE_5__, _NextLogoButton__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const CustomizeLogoOptions = ()=>{
    const { clearLogoUploadHistory , toggleNextLogoButton  } = (0,hooks__WEBPACK_IMPORTED_MODULE_3__/* .useActions */ .ol)();
    const { 0: nowOrLater , 1: setNowOrLater  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("later");
    const { currency  } = (0,hooks__WEBPACK_IMPORTED_MODULE_3__/* .useTypedSelector */ .ix)((state)=>state.product.toCheckout);
    const showPrice = (price)=>{
        if (price === "FREE") return `FREE`;
        return `${currency}${price}`;
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "mb-6",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                    htmlFor: "logo_later",
                    className: `block p-2 border mb-1 ${nowOrLater === "later" ? "border-secondary" : "border-slate-200"}`,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            type: "radio",
                            value: "later",
                            name: "customize_logo",
                            id: "logo_later",
                            checked: nowOrLater === "later",
                            onChange: ()=>setNowOrLater("later")
                        }),
                        "Customize Logo Later with Dedicated Account Specialist"
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                    htmlFor: "logo_now",
                    className: `block p-2 border mb-1 ${nowOrLater === "now" ? "border-secondary" : "border-slate-200"}`,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            type: "radio",
                            value: "now",
                            name: "customize_logo",
                            id: "logo_now",
                            checked: nowOrLater === "now",
                            onChange: ()=>{
                                setNowOrLater("now");
                                clearLogoUploadHistory(mock_startModal_mock__WEBPACK_IMPORTED_MODULE_4__/* .logoPositions.map */ .QW.map((logo)=>({
                                        logo: {
                                            url: logo.image.url
                                        },
                                        label: logo.label,
                                        value: logo.value
                                    })));
                            }
                        }),
                        "Customize Logo Now"
                    ]
                }),
                nowOrLater === "now" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_1__.Formik, {
                        initialValues: {
                            logos: [
                                ""
                            ]
                        },
                        onSubmit: ()=>{},
                        children: ({ values  })=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_1__.Form, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_1__.FieldArray, {
                                    name: "logos",
                                    render: (arrayHelpers)=>{
                                        var ref;
                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: [
                                                (ref = values.logos) === null || ref === void 0 ? void 0 : ref.map((val, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_LogoOption__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                                        index: index,
                                                        price: mock_startModal_mock__WEBPACK_IMPORTED_MODULE_4__/* .IndexLabels */ .Lp[index].price,
                                                        onRemove: ()=>{
                                                            arrayHelpers.remove(index);
                                                            toggleNextLogoButton(true);
                                                        },
                                                        title: `${mock_startModal_mock__WEBPACK_IMPORTED_MODULE_4__/* .IndexLabels */ .Lp[index].label} Logo (${showPrice(mock_startModal_mock__WEBPACK_IMPORTED_MODULE_4__/* .IndexLabels */ .Lp[index].price)})`,
                                                        id: `${index}-id`,
                                                        name: `${index}-name`
                                                    }, index)),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_NextLogoButton__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                                    cIndex: mock_startModal_mock__WEBPACK_IMPORTED_MODULE_4__/* .IndexLabels */ .Lp[values.logos.length],
                                                    arrayHelpers: arrayHelpers
                                                })
                                            ]
                                        });
                                    }
                                })
                            });
                        }
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CustomizeLogoOptions);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2972:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3632);
/* harmony import */ var constants_store_constant__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7297);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6183);
/* harmony import */ var _PriceTable__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1313);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__, hooks__WEBPACK_IMPORTED_MODULE_4__, _PriceTable__WEBPACK_IMPORTED_MODULE_5__]);
([appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__, hooks__WEBPACK_IMPORTED_MODULE_4__, _PriceTable__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const DiscountPricing = ({ showPriceTable , price  })=>{
    const { 0: showMsg , 1: setShowMsg  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { layout: storeLayout  } = (0,hooks__WEBPACK_IMPORTED_MODULE_4__/* .useTypedSelector */ .ix)((state)=>state.store);
    const { minQuantity  } = (0,hooks__WEBPACK_IMPORTED_MODULE_4__/* .useTypedSelector */ .ix)((state)=>state.product.selected.color);
    const unitUnits = minQuantity > 1 ? "units" : "unit";
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_3__/* ._Store.type4 */ .up.type4) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "mb-5",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "text-sm text-gray-900 bg-secondary flex flex-wrap justify-between items-center p-2 md:p-0 md:pl-2 mt-5",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "text-lg font-semibold text-white",
                                children: "Discount Pricing:"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                onClick: ()=>setShowMsg((show)=>!show),
                                className: "text-white py-1 md:px-2 flex flex-wrap text-sm font-semibold uppercase items-center",
                                "data-target": "#minimum-order",
                                id: "aMinOrder",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "MINIMUM ORDER :"
                                    }),
                                    ` ${minQuantity} ${unitUnits} per color`
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PriceTable__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}),
                    showMsg && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "text-xs p-3 pb-0",
                        id: "divMinorder",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                            children: [
                                "We reserve the right to reject orders that do not meet the",
                                minQuantity,
                                "piece minimum per style ",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                " and color, exceptions may apply for men’s and women’s companion styles per color."
                            ]
                        })
                    })
                ]
            })
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_3__/* ._Store.type1 */ .up.type1) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "mb-5",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "text-sm text-gray-900 bg-primary flex flex-wrap justify-between items-center p-2 md:p-0 md:pl-2 mt-5",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "text-lg font-semibold text-white",
                                children: "Discount Pricing:"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                onClick: ()=>setShowMsg((show)=>!show),
                                className: "text-white py-1 md:px-2 flex flex-wrap text-sm font-semibold uppercase items-center",
                                "data-target": "#minimum-order",
                                id: "aMinOrder",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "MINIMUM ORDER :"
                                    }),
                                    ` ${minQuantity} ${unitUnits} per color`
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "text-sm text-gray-900 flex flex-wrap justify-between items-center mt-2",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                className: "",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "text-lg font-semibold mr-1",
                                        children: [
                                            "Price: ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                value: price.msrp
                                            })
                                        ]
                                    }),
                                    "per item"
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                onClick: ()=>setShowMsg((show)=>!show),
                                className: "uppercase items-center",
                                "data-target": "#minimum-order",
                                id: "aMinOrder",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                    children: "DISCOUNT PRICING AVAILABLE!"
                                })
                            })
                        ]
                    }),
                    showPriceTable && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PriceTable__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}),
                    showMsg && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "text-xs p-3 pb-0",
                        id: "divMinorder",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                            children: [
                                "We reserve the right to reject orders that do not meet the",
                                " ",
                                minQuantity,
                                "piece minimum per style ",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                " and color, exceptions may apply for men’s and women’s companion styles per color."
                            ]
                        })
                    })
                ]
            })
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DiscountPricing);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2061:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6183);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_1__]);
hooks__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const dummyLogoImage = "images/logo-to-be-submitted.webp";
const LogoOption = ({ title , id , name , index , price , onRemove: removeHandler ,  })=>{
    const { updatePriceByLogo , updateOptions  } = (0,hooks__WEBPACK_IMPORTED_MODULE_1__/* .useActions */ .ol)();
    const { 0: logoStatus , 1: setLogoStatus  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);
    const { 0: selected , 1: setSelected  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);
    const { 0: fileToUpload , 1: setFileToUpload  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);
    const availableOptions = (0,hooks__WEBPACK_IMPORTED_MODULE_1__/* .useTypedSelector */ .ix)((state)=>state.product.toCheckout.availableOptions);
    const fileReader = (event)=>{
        var ref;
        if (((ref = event.currentTarget) === null || ref === void 0 ? void 0 : ref.files) === null) return;
        const file = {
            name: event.currentTarget.files[0].name,
            type: event.currentTarget.files[0].type,
            previewURL: URL.createObjectURL(event.currentTarget.files[0])
        };
        setFileToUpload(file);
        setLogoStatus("submitted");
    };
    const DisplayActions = ()=>{
        let text = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
        const actionHandler = (action)=>{
            if (!(selected === null || selected === void 0 ? void 0 : selected.value)) return;
            if (action === "later") {
                setLogoStatus("later");
                return;
            }
            if (action === "submitted") {
                setLogoStatus("submitted");
                return;
            }
            if (action === null) {
                setLogoStatus(null);
                setFileToUpload(null);
                return;
            }
        };
        switch(logoStatus){
            case null:
                text = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "",
                    onClick: ()=>actionHandler("later"),
                    children: "Add Logo Later"
                });
                break;
            case "later":
                text = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "",
                    children: "Logo to be submitted after order is placed"
                });
                break;
            case "submitted":
                text = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "",
                    onClick: ()=>actionHandler(null),
                    children: "Remove"
                });
                break;
            default:
                text = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "",
                    onClick: ()=>actionHandler("later"),
                    children: "Add Logo Later"
                });
                break;
        }
        return text;
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (logoStatus === "later" || logoStatus === "submitted") {
            updateOptions({
                value: selected.value,
                label: selected.label,
                addOrRemove: "REMOVE",
                logo: selected.logo
            });
            setSelected((opt)=>{
                if (opt === null) return null;
                return {
                    ...opt,
                    show: true
                };
            });
        }
        return ()=>{
            if (logoStatus === "later" || logoStatus === "submitted") {
                updateOptions({
                    value: selected.value,
                    label: selected.label,
                    addOrRemove: "ADD",
                    logo: selected.logo
                });
            }
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        logoStatus
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        updatePriceByLogo({
            type: "add",
            price,
            index
        });
        return ()=>{
            updatePriceByLogo({
                type: "subtract",
                price,
                index
            });
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "p-2 mb-2 border bg-gray-50 border-slate-200",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex items-center justify-between mb-4 gap-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "font-semibold text-lg mb-4",
                        children: title
                    }),
                    index !== 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "text-rose-600",
                            type: "button",
                            onClick: removeHandler,
                            children: "Remove"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mb-4 last:mb-0",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                        htmlFor: name,
                        className: "block mb-2",
                        children: "Select a location to print your logo :"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                        id: name,
                        className: "block w-full border border-gray-600 shadow-sm text-sm py-1 px-2 pr-10",
                        name: name,
                        disabled: selected === null || selected === void 0 ? void 0 : selected.show,
                        value: (selected === null || selected === void 0 ? void 0 : selected.value) || "",
                        onChange: (event)=>{
                            setSelected({
                                label: availableOptions.find((opt)=>opt.value === event.target.value).label,
                                value: event.target.value,
                                show: false,
                                logo: availableOptions.find((opt)=>opt.value === event.target.value).logo
                            });
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "",
                                children: "Select"
                            }),
                            (selected === null || selected === void 0 ? void 0 : selected.show) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: selected === null || selected === void 0 ? void 0 : selected.value,
                                children: selected === null || selected === void 0 ? void 0 : selected.label
                            }),
                            availableOptions === null || availableOptions === void 0 ? void 0 : availableOptions.map((location)=>{
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                    value: location.value,
                                    children: location.label
                                }, location.value);
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mb-4 last:mb-0",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                        htmlFor: "",
                        className: "block mb-2",
                        children: "Select your logo :"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-wrap items-center justify-between border border-gray-600 shadow-sm text-sm p-2",
                        children: [
                            logoStatus === null && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "",
                                children: "Upload Your Logo"
                            }),
                            logoStatus === "later" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: dummyLogoImage,
                                    alt: ""
                                })
                            }),
                            logoStatus === "submitted" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    className: "w-14 max-h-14",
                                    src: fileToUpload === null || fileToUpload === void 0 ? void 0 : fileToUpload.previewURL,
                                    alt: ""
                                })
                            }),
                            DisplayActions(),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        htmlFor: id,
                                        className: "inline-block bg-indigo-600 border-0 py-2 px-3 text-white",
                                        children: "Upload"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "file",
                                        name: id,
                                        id: id,
                                        // value={undefined}
                                        className: "sr-only",
                                        onChange: fileReader,
                                        accept: "image/*"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LogoOption);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9182:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6183);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_2__]);
hooks__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// import { FieldArrayRenderProps } from 'formik';



const NextLogoButton = ({ cIndex , arrayHelpers  })=>{
    const { toggleNextLogoButton  } = (0,hooks__WEBPACK_IMPORTED_MODULE_2__/* .useActions */ .ol)();
    const { allowNextLogo , currency  } = (0,hooks__WEBPACK_IMPORTED_MODULE_2__/* .useTypedSelector */ .ix)((state)=>state.product.toCheckout);
    const showPrice = (price)=>{
        if (price === "FREE") return `FREE`;
        return `${currency}${price}`;
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: allowNextLogo && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    className: "text-indigo-600 font-semibold",
                    onClick: ()=>{
                        arrayHelpers.push("");
                        toggleNextLogoButton(false);
                    },
                    type: "button",
                    children: `+ Add ${cIndex.label} Logo`
                }),
                ` (Additional ${showPrice(cIndex.price)} per item)`
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NextLogoButton);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1313:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_product_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2433);
/* harmony import */ var appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3632);
/* harmony import */ var constants_store_constant__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7297);
/* harmony import */ var helpers_common_helper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4822);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6183);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_product_service__WEBPACK_IMPORTED_MODULE_1__, appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__, helpers_common_helper__WEBPACK_IMPORTED_MODULE_4__, hooks__WEBPACK_IMPORTED_MODULE_5__]);
([_services_product_service__WEBPACK_IMPORTED_MODULE_1__, appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__, helpers_common_helper__WEBPACK_IMPORTED_MODULE_4__, hooks__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const QtyPriceTable = ()=>{
    const { setPropertyValues  } = (0,hooks__WEBPACK_IMPORTED_MODULE_5__/* .useActions */ .ol)();
    const { layout: storeLayout , id: storeId  } = (0,hooks__WEBPACK_IMPORTED_MODULE_5__/* .useTypedSelector */ .ix)((state)=>state.store);
    const customerId = (0,hooks__WEBPACK_IMPORTED_MODULE_5__/* .useTypedSelector */ .ix)((state)=>state.user.id);
    const selectedColor = (0,hooks__WEBPACK_IMPORTED_MODULE_5__/* .useTypedSelector */ .ix)((state)=>state.product.selected.color);
    const { discounts  } = (0,hooks__WEBPACK_IMPORTED_MODULE_5__/* .useTypedSelector */ .ix)((state)=>state.product.product);
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        if (storeId && customerId && storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_3__/* ._Store.type1 */ .up.type1) {
            (0,_services_product_service__WEBPACK_IMPORTED_MODULE_1__/* .FetchDiscountTablePrices */ .e_)({
                storeId: storeId,
                seName: (0,helpers_common_helper__WEBPACK_IMPORTED_MODULE_4__/* .c_getSeName */ .Yl)("PRODUCT DETAILS"),
                customerId: customerId || 0,
                attributeOptionId: selectedColor.attributeOptionId
            }).then((res)=>setPropertyValues({
                    propertyName: "DISCOUNT",
                    data: res
                }));
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        customerId,
        storeLayout
    ]);
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_3__/* ._Store.type1 */ .up.type1) {
        var ref;
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: customerId !== null && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "bg-gray-100 flex flex-wrap text-center border border-gray-300",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "hidden md:block text-left",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "p-1 px-2 border-r border-b border-gray-300 font-semibold",
                                children: "Quantity:"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "p-1 px-2 border-r border-gray-300 font-semibold",
                                children: "Price:"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex flex-wrap text-center grow",
                        children: discounts === null || discounts === void 0 ? void 0 : (ref = discounts.subRows) === null || ref === void 0 ? void 0 : ref.map((column)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "sm:w-1/5",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "p-1 px-2 border-b border-gray-300",
                                        children: column.displayQuantity
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "p-1 px-2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            value: column.discountPrice
                                        })
                                    })
                                ]
                            }, column.discountPrice))
                    })
                ]
            })
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_3__/* ._Store.type3 */ .up.type3) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "mb-4 border border-gray-300 text-center",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "bg-gray-300 p-2 font-semibold",
                    children: "QUANTITY DISCOUNT"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex flex-wrap justify-center py-3",
                    children: discounts === null || discounts === void 0 ? void 0 : discounts.subRows.map((row)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "border-r last:border-r-0 border-r-gray-300 px-2",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "",
                                    children: row.displayQuantity
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        value: row.discountPrice
                                    })
                                })
                            ]
                        }, row.displayQuantity))
                })
            ]
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_3__/* ._Store.type4 */ .up.type4) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "bg-gray-100 flex flex-wrap text-center border border-gray-300",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "hidden md:block text-left",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "p-1 px-2 border-r border-b border-gray-300 font-semibold",
                            children: "Quantity:"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "p-1 px-2 border-r border-gray-300 font-semibold",
                            children: "Price:"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex flex-wrap text-center grow gap-y-5",
                    children: discounts === null || discounts === void 0 ? void 0 : discounts.subRows.map((row)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-1/2 md:w-1/5",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "p-1 px-2 border-b border-gray-300",
                                    children: row.displayQuantity
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "p-1 px-2",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(appComponents_reusables_Price__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        value: row.discountPrice
                                    })
                                })
                            ]
                        }, row.displayQuantity))
                })
            ]
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (QtyPriceTable);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var constants_store_constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7297);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6183);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_3__]);
hooks__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const ProductSKU = ({ skuID  })=>{
    const storeLayout = (0,hooks__WEBPACK_IMPORTED_MODULE_3__/* .useTypedSelector */ .ix)((state)=>state.store.layout);
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_2__/* ._Store.type1 */ .up.type1) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "text-gray-700 pt-1 text-sm",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "font-semibold inline-block w-16",
                    children: "SKU "
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    children: [
                        ": ",
                        skuID
                    ]
                })
            ]
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_2__/* ._Store.type3 */ .up.type3) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "pb-4 flex items-center",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "font-bold inline-block w-24",
                    children: "SKU "
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    children: [
                        ": ",
                        skuID
                    ]
                })
            ]
        });
    }
    if (storeLayout === constants_store_constant__WEBPACK_IMPORTED_MODULE_2__/* ._Store.type4 */ .up.type4) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "text-black mb-2 text-sm flex items-center",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "font-bold w-12",
                    children: "SKU "
                }),
                " ",
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    children: [
                        ": ",
                        skuID
                    ]
                })
            ]
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductSKU);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9190:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6183);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_1__]);
hooks__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const SizePriceQtyTable = ({ inventory , editDetailsQuantity ,  })=>{
    const price = (0,hooks__WEBPACK_IMPORTED_MODULE_1__/* .useTypedSelector */ .ix)((state)=>state.product.product.price);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "overflow-x-auto max-h-screen",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                cellPadding: "0",
                cellSpacing: "0",
                className: "table-auto w-full text-xs text-center text-[#191919]",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                        className: "text-xs font-semibold border-b border-neutral-200",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                            className: "",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                    className: "px-2 py-4 w-32",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "",
                                        children: "Size"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                    className: "px-2 py-4 w-32",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "",
                                        children: "Price"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                    className: "px-2 py-4 w-32",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "",
                                        children: "Qty"
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                        className: "divide-y divide-slate-200"
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SizePriceQtyTable);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7027:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);


const SeoHead = (props)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                children: props.title
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "description",
                content: props.description
            }, "desc"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "keywords",
                content: props.keywords
            })
        ]
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SeoHead);


/***/ }),

/***/ 6531:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var Components_ProductDetails_AskToLogin__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7388);
/* harmony import */ var Components_ProductDetails_CalculativeFigure__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7719);
/* harmony import */ var Components_ProductDetails_CustomizeLogoOptions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3830);
/* harmony import */ var Components_ProductDetails_DiscountPricing__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2972);
/* harmony import */ var Components_ProductDetails_ProductSKU__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2);
/* harmony import */ var Components_ProductDetails_SizePriceQtyTable__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9190);
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6183);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var services_product_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2433);
/* harmony import */ var _services_cart_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7591);
/* harmony import */ var helpers_getLocation__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8443);
/* harmony import */ var helpers_global_console__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3650);
/* harmony import */ var _reusables_Image__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2337);
/* harmony import */ var _reusables_Price__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(3632);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([Components_ProductDetails_AskToLogin__WEBPACK_IMPORTED_MODULE_1__, Components_ProductDetails_CalculativeFigure__WEBPACK_IMPORTED_MODULE_2__, Components_ProductDetails_CustomizeLogoOptions__WEBPACK_IMPORTED_MODULE_3__, Components_ProductDetails_DiscountPricing__WEBPACK_IMPORTED_MODULE_4__, Components_ProductDetails_ProductSKU__WEBPACK_IMPORTED_MODULE_5__, Components_ProductDetails_SizePriceQtyTable__WEBPACK_IMPORTED_MODULE_6__, hooks__WEBPACK_IMPORTED_MODULE_7__, services_product_service__WEBPACK_IMPORTED_MODULE_9__, _services_cart_service__WEBPACK_IMPORTED_MODULE_10__, helpers_getLocation__WEBPACK_IMPORTED_MODULE_11__, helpers_global_console__WEBPACK_IMPORTED_MODULE_12__, _reusables_Price__WEBPACK_IMPORTED_MODULE_14__]);
([Components_ProductDetails_AskToLogin__WEBPACK_IMPORTED_MODULE_1__, Components_ProductDetails_CalculativeFigure__WEBPACK_IMPORTED_MODULE_2__, Components_ProductDetails_CustomizeLogoOptions__WEBPACK_IMPORTED_MODULE_3__, Components_ProductDetails_DiscountPricing__WEBPACK_IMPORTED_MODULE_4__, Components_ProductDetails_ProductSKU__WEBPACK_IMPORTED_MODULE_5__, Components_ProductDetails_SizePriceQtyTable__WEBPACK_IMPORTED_MODULE_6__, hooks__WEBPACK_IMPORTED_MODULE_7__, services_product_service__WEBPACK_IMPORTED_MODULE_9__, _services_cart_service__WEBPACK_IMPORTED_MODULE_10__, helpers_getLocation__WEBPACK_IMPORTED_MODULE_11__, helpers_global_console__WEBPACK_IMPORTED_MODULE_12__, _reusables_Price__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










// import { AddToCart } from 'services/user.service';





const StartOrderModal = ({ product , modalHandler , editDetails ,  })=>{
    const textRef = (0,react__WEBPACK_IMPORTED_MODULE_8__.useRef)(null);
    const { clearToCheckout , showModal , setShowLoader  } = (0,hooks__WEBPACK_IMPORTED_MODULE_7__/* .useActions */ .ol)();
    // ----------------------------STATES ---------------------------------------
    const { 0: allColors , 1: showAllColors  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(false);
    const { 0: inventory , 1: setInventory  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(null);
    const { name: colorName  } = (0,hooks__WEBPACK_IMPORTED_MODULE_7__/* .useTypedSelector */ .ix)((state)=>state.product.selected.color);
    const toCheckout = (0,hooks__WEBPACK_IMPORTED_MODULE_7__/* .useTypedSelector */ .ix)((state)=>state.product.toCheckout);
    const colors = (0,hooks__WEBPACK_IMPORTED_MODULE_7__/* .useTypedSelector */ .ix)((state)=>state.product.product.colors);
    const customerId = (0,hooks__WEBPACK_IMPORTED_MODULE_7__/* .useTypedSelector */ .ix)((state)=>state.user.customer.id);
    const selectedProduct = (0,hooks__WEBPACK_IMPORTED_MODULE_7__/* .useTypedSelector */ .ix)((state)=>state.product.selected);
    const showInventoryFor = (payload)=>{
        (0,services_product_service__WEBPACK_IMPORTED_MODULE_9__/* .FetchInventoryById */ .oe)(payload).then((res)=>setInventory(res))// .catch((err) => console.log('err', err))
        .finally(()=>setShowLoader(false));
    };
    const addToCartHandler = async ()=>{
        var ref, ref1;
        const location = await (0,helpers_getLocation__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)();
        const tempCustId = localStorage.getItem("tempCustomerId");
        const note = (ref = textRef.current) === null || ref === void 0 ? void 0 : ref.value;
        const cartLogoPersonModel = [];
        (ref1 = toCheckout.sizeQtys) === null || ref1 === void 0 ? void 0 : ref1.map((res)=>cartLogoPersonModel.push({
                attributeOptionId: 0,
                attributeOptionValue: res.size,
                code: "",
                price: res.price,
                quantity: res.qty,
                logoPrice: 0,
                logoQty: 0,
                logoFile: "string",
                estimateDate: new Date("2022-11-03T05:09:52.659Z"),
                isEmployeeLoginPrice: 0,
                cartLogoPersonDetailModels: [
                    {
                        location: `${location.city}, ${location.state}, ${location.country_name}, ${location.postal}`,
                        logoTotal: 0,
                        colorImagePath: "string",
                        logoUniqueId: "string",
                        price: 0,
                        logoColors: "string",
                        logoNotes: "string",
                        logoDate: new Date("2022-11-03T05:09:52.659Z"),
                        logoNames: "string",
                        digitalPrice: 0,
                        logoPositionImagePath: "string",
                        oldFilePath: "string",
                        originalLogoFilePath: "string"
                    }, 
                ]
            }));
        const cartObject = {
            addToCartModel: {
                customerId: customerId || (tempCustId ? ~~tempCustId : 0),
                productId: selectedProduct.productId,
                storeId: 4,
                shoppingCartItemModel: {
                    id: 0,
                    price: toCheckout.totalPrice,
                    quantity: toCheckout.totalQty,
                    weight: 0,
                    productType: 0,
                    discountPrice: 0,
                    logoTitle: selectedProduct.color.altTag,
                    logogImagePath: selectedProduct.color.imageUrl,
                    perQuantity: 0,
                    appQuantity: 0,
                    status: 2,
                    discountPercentage: 0,
                    productCustomizationId: 0,
                    itemNotes: note || "",
                    isEmployeeLoginPrice: 0
                },
                shoppingCartItemsDetailModels: [
                    {
                        attributeOptionName: "Color",
                        attributeOptionValue: selectedProduct.color.name,
                        attributeOptionId: selectedProduct.color.attributeOptionId
                    }, 
                ],
                cartLogoPersonModel: cartLogoPersonModel
            }
        };
        if (cartObject) {
            try {
                const res = await (0,_services_cart_service__WEBPACK_IMPORTED_MODULE_10__/* .addToCart */ .Xq)(cartObject);
                if (!customerId) {
                    localStorage.setItem("tempCustomerId", res);
                }
                showModal({
                    message: "Added to cart Successfully",
                    type: "Success"
                });
            } catch (error) {
                (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_12__/* .highLightError */ .Eg)({
                    error,
                    component: "StartOrderModal"
                });
            }
        }
        // .then((res) => setReviews(res))
        // .catch((err) => console.log('err', err))
        // .finally(() => console.log('close loader'));
        modalHandler(null);
    // router.push('/cart');
    };
    (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(()=>{
        if (colors === null) return;
        showInventoryFor({
            productId: colors[0].productId,
            attributeOptionId: [
                colors[0].attributeOptionId
            ]
        });
        return ()=>{
            clearToCheckout();
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        id: "startorderModal",
        className: "overflow-y-auto overflow-x-hidden fixed right-0 left-0 top-4 z-50 justify-center items-center h-modal md:h-full md:inset-0",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-full h-full bg-black bg-opacity-50 flex items-center justify-center",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "relative px-4 w-full max-w-3xl h-full md:h-auto",
                children: inventory && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "relative bg-white shadow max-h-screen overflow-y-auto",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex justify-between items-start p-5 rounded-t border-b sticky top-0 left-0 bg-white",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    className: "text-xl font-semibold text-gray-900 lg:text-2xl",
                                    children: product.name
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center",
                                    onClick: ()=>modalHandler(null),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                        className: "w-5 h-5",
                                        fill: "currentColor",
                                        viewBox: "0 0 20 20",
                                        xmlns: "http://www.w3.org/2000/svg",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                            fillRule: "evenodd",
                                            d: "M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z",
                                            clipRule: "evenodd"
                                        })
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "p-6",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex flex-wrap mb-6",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "w-full lg:w-1/2",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_ProductDetails_ProductSKU__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                                    skuID: product.sku
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "font-semibold",
                                                            children: "Color : "
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            children: colorName
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "w-full lg:w-1/2 lg:text-right",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "font-semibold",
                                                    children: "Item Total :"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "font-semibold",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_reusables_Price__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                                        value: toCheckout.totalPrice
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "mb-6",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                type: "button",
                                                onClick: ()=>showAllColors((show)=>!show),
                                                className: "text-indigo-500 text-sm font-semibold underline",
                                                children: allColors ? "Show less" : `See All ${colors === null || colors === void 0 ? void 0 : colors.length} Colors`
                                            })
                                        }),
                                        allColors && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            "x-show": "open",
                                            "x-cloak": true,
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "text-sm text-gray-600 bg-primary flex flex-wrap justify-between items-center p-2 md:p-0 md:pl-2 my-2",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "text-lg font-bold text-white",
                                                        children: "Available Colors:"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "flex flex-wrap gap-5 text-sm text-center px-2",
                                                    children: colors === null || colors === void 0 ? void 0 : colors.map((color)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "w-20",
                                                            onClick: ()=>showInventoryFor({
                                                                    productId: color.productId,
                                                                    attributeOptionId: [
                                                                        color.attributeOptionId
                                                                    ]
                                                                }),
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "border-2 border-slate-200 hover:border-secondary mb-1 last:mb-0",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_reusables_Image__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                                        src: color.imageUrl,
                                                                        alt: color.altTag,
                                                                        className: "w-full object-center object-cover"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "",
                                                                    style: {
                                                                        whiteSpace: "nowrap",
                                                                        overflow: "hidden",
                                                                        textOverflow: "ellipsis"
                                                                    },
                                                                    children: color.name
                                                                })
                                                            ]
                                                        }, color.productId))
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "mt-3",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                className: "sr-only",
                                                children: "Product information"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_ProductDetails_DiscountPricing__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                    showPriceTable: false,
                                                    price: {
                                                        salePrice: product.salePrice,
                                                        imap: product.imap,
                                                        msrp: product.msrp,
                                                        ourCost: product.ourCost
                                                    }
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_ProductDetails_AskToLogin__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                    modalHandler: modalHandler
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_ProductDetails_SizePriceQtyTable__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                    inventory: inventory,
                                    editDetailsQuantity: editDetails === null || editDetails === void 0 ? void 0 : editDetails.shoppingCartItemDetailsViewModels
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_ProductDetails_CustomizeLogoOptions__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Components_ProductDetails_CalculativeFigure__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            htmlFor: "",
                                            className: "block mb-2",
                                            children: "Notes :"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                            name: "",
                                            id: "",
                                            ref: textRef,
                                            className: "block w-full border border-gray-600 shadow-sm text-base py-2 px-4",
                                            rows: 10
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "p-6 pt-0",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    onClick: addToCartHandler,
                                    type: "button",
                                    className: "btn btn-lg btn-secondary !flex items-center justify-center w-full uppercase mb-2",
                                    children: "Add to Cart"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    onClick: ()=>modalHandler(null),
                                    type: "button",
                                    className: "block w-full text-gray-500 hover:text-gray-700",
                                    children: "Cancel"
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StartOrderModal);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8443:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

/* harmony default export */ async function __WEBPACK_DEFAULT_EXPORT__() {
    const { data: location  } = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].get("https://geolocation-db.com/json/");
    return location;
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4021:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Lp": () => (/* binding */ IndexLabels),
/* harmony export */   "QW": () => (/* binding */ logoPositions)
/* harmony export */ });
/* unused harmony export nullOrInitials */
const logoPositions = [
    {
        value: "rightSleeve",
        label: "Right Sleeve",
        selected: false,
        image: {
            url: "images/Right-Chest-70-191.jpg",
            alt: ""
        }
    },
    {
        value: "backYoke",
        label: "Back Yoke",
        selected: false,
        image: {
            url: "images/Right-Chest-70-191.jpg",
            alt: ""
        }
    },
    {
        value: "frontYoke",
        label: "Front Yoke",
        selected: false,
        image: {
            url: "images/Right-Chest-70-191.jpg",
            alt: ""
        }
    }, 
];
const IndexLabels = [
    {
        value: 0,
        label: "First",
        price: "FREE"
    },
    {
        value: 1,
        label: "Second",
        price: 6
    },
    {
        value: 2,
        label: "Third",
        price: 6
    },
    {
        value: 3,
        label: "Fourth",
        price: 6
    },
    {
        value: 4,
        label: "Fifth",
        price: 6
    },
    {
        value: 5,
        label: "Sixth",
        price: 6
    },
    {
        value: 6,
        label: "Seventh",
        price: 6
    }, 
];
const nullOrInitials = [
    {
        size: "sm",
        qty: 12,
        price: "100"
    },
    {
        size: "lg",
        qty: 122,
        price: "100"
    }, 
];


/***/ })

};
;