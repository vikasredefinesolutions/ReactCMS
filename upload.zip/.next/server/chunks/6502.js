"use strict";
exports.id = 6502;
exports.ids = [6502];
exports.modules = {

/***/ 6502:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var hooks__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6183);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([hooks__WEBPACK_IMPORTED_MODULE_0__]);
hooks__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const BrandController = ()=>{
    const { setShowLoader  } = (0,hooks__WEBPACK_IMPORTED_MODULE_0__/* .useActions */ .ol)();
    const alpha = Array.from(Array(26)).map((e, i)=>i + 65);
    const alphabets = alpha.map((x)=>String.fromCharCode(x).toLowerCase());
    const { 0: currentTab , 1: setCurrentTab  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const storeLayout = (0,hooks__WEBPACK_IMPORTED_MODULE_0__/* .useTypedSelector */ .ix)((state)=>state.store.layout);
    const getTabColor = ()=>{
        switch(currentTab){
            case 0:
                return "#FFA400";
            case 1:
                return "#00ce7c";
            case 2:
                return "#00b2e3";
            case 3:
                return "#003a70";
            case 4:
                return "#0a2240";
            default:
                break;
        }
    };
    return {
        alphabets,
        currentTab,
        storeLayout,
        setCurrentTab,
        getTabColor,
        setShowLoader
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BrandController);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;