"use strict";
exports.id = 7466;
exports.ids = [7466];
exports.modules = {

/***/ 7466:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _BrandController__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6502);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_BrandController__WEBPACK_IMPORTED_MODULE_2__]);
_BrandController__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const Stroe1LayouBrand = ({ brands , alphabets  })=>{
    const { alphabets: alphabts , currentTab , setCurrentTab , getTabColor , setShowLoader ,  } = (0,_BrandController__WEBPACK_IMPORTED_MODULE_2__["default"])();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                className: "relative pt-20 overflow-hidden bg-primary white-all pb-20",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex justify-center items-center flex-wrap",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "container",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex justify-center flex-wrap items-center sm:max-w-[700px] mx-auto",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "sm:mb-2 lg:mb-1 sm:border-r lg:pr-1 pl-1 lg:max-w-[340px] w-full grow text-sub-title",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        children: "Better Brand Inventory, Easier Customization, and Superior Branded Results"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "lg:ml-5 lg:max-w-[340px] ml-2 w-full text-default-text",
                                    children: "Your top-name, brand-favorites, customized with your brand logo and text. Customization for every occasion: corporate apparel, promotional products, company clothing, and corporate gifts."
                                })
                            ]
                        })
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                className: "relative pt-20",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "overflow-x-hidden",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "mb-3 text-center",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "material-icons text-[40px] text-primary",
                                    children: "local_offer"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "my-3 text-title text-center",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                    children: "Shop Your Favorite Brands by Category"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    "x-data": "{activeTab:01, activeClass: 'tab py-2 mr-1 px-2 block hover:text-[#006CD1] focus:outline-none text-[#006CD1] border-b-2 font-medium border-[#006CD1]', inactiveClass : 'tab text-gray-600 py-2 px-2 block hover:text-[#006CD1] focus:outline-none mr-1 rounded-sm font-medium border-slate-300 hover:border-[#006CD1]' }",
                                    className: "w-full",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                            className: "w-full flex justify-center max-w-4xl mx-auto flex-wrap",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                className: "",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    className: `bg-[${getTabColor()}] h-2 w-24 my-2 inline-block`
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                            className: "w-full flex justify-center max-w-4xl mx-auto flex-wrap",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                    className: "mr-0.5 md:mr-0 font-semibold",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        className: `tab py-2 mr-1 px-2 block font-medium${currentTab === 0 ? " border-b-2 font-medium border-[#006CD1]" : ""}`,
                                                        onClick: ()=>setCurrentTab(0),
                                                        children: "Featured"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                    className: "mr-0.5 md:mr-0 font-semibold",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        className: `tab py-2 mr-1 px-2 block font-medium${currentTab === 1 ? " border-b-2 font-medium border-[#006CD1]" : ""}`,
                                                        onClick: ()=>setCurrentTab(1),
                                                        children: "Outerwear"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                    className: "mr-0.5 md:mr-0 font-semibold",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        className: `tab py-2 mr-1 px-2 block font-medium${currentTab === 2 ? " border-b-2 font-medium border-[#006CD1]" : ""}`,
                                                        onClick: ()=>setCurrentTab(2),
                                                        children: "Golf"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                    className: "mr-0.5 md:mr-0 font-semibold",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        className: `tab py-2 mr-1 px-2 block font-medium${currentTab === 3 ? " border-b-2 font-medium border-[#006CD1]" : ""}`,
                                                        onClick: ()=>setCurrentTab(3),
                                                        children: "Sporting Goods"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                    className: "mr-0.5 md:mr-0 font-semibold",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        className: `tab py-2 mr-1 px-2 block font-medium${currentTab === 4 ? " border-b-2 font-medium border-[#006CD1]" : ""}`,
                                                        onClick: ()=>setCurrentTab(4),
                                                        children: "Accessories"
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "container mx-auto",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "w-full text-center mx-auto max-w-6xl py-10",
                                                    children: [
                                                        currentTab === 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            "x-show": "activeTab === 01",
                                                            className: "panel-01 tab-content",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: " w-full",
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "flex flex-wrap -mx-3 gap-y-6",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#ffa400] hover:bg-[#f18a00] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/patagonia.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/patagonia.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#ffa400] hover:bg-[#f18a00] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/nike.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/nike.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#ffa400] hover:bg-[#f18a00] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/peter-millar.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/peter-millar.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#ffa400] hover:bg-[#f18a00] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/yeti.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/yeti.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#ffa400] hover:bg-[#f18a00] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/the-north-face.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/the-north-face.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#ffa400] hover:bg-[#f18a00] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/helly-hansen.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/HH.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#ffa400] hover:bg-[#f18a00] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/southern-tide.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/sourthen-tide.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#ffa400] hover:bg-[#f18a00] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/johnnie-o.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/johnnie-o.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        }),
                                                        currentTab === 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            "x-show": "activeTab === 02",
                                                            className: "panel-01 tab-content",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: " w-full",
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "flex flex-wrap -mx-3 gap-y-6",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#00ce7c] hover:bg-[#00a98f] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/stio.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/stio.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#00ce7c] hover:bg-[#00a98f] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/carhartt.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/carhartt.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#00ce7c] hover:bg-[#00a98f] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/marine-layer.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/marine-layer.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#00ce7c] hover:bg-[#00a98f] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/columbia.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/columbia.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#00ce7c] hover:bg-[#00a98f] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/marmot.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/marmot.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#00ce7c] hover:bg-[#00a98f] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/charles-river-apparel.html?sort=",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/charles-river.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#00ce7c] hover:bg-[#00a98f] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/berne-apparel.html?sort=high&v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/berne.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#00ce7c] hover:bg-[#00a98f] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/eddie-bauer.html?v=brand-product-list ",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/eddie-bauer.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        }),
                                                        currentTab === 2 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            "x-show": "activeTab === 03",
                                                            className: "panel-01 tab-content",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: " w-full",
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "flex flex-wrap -mx-3 gap-y-6",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#00b2e3] hover:bg-[#4197cb] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/footjoy.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/fj.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#00b2e3] hover:bg-[#4197cb] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/titleist.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/titleist.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#00b2e3] hover:bg-[#4197cb] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/galvin-green.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/galvin-green.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#00b2e3] hover:bg-[#4197cb] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/callaway-golf.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/callaway.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#00b2e3] hover:bg-[#4197cb] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/fairway-greene.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/fairway-greene.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#00b2e3] hover:bg-[#4197cb] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/taylormade.html?sort=high&v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/taylor-made.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#00b2e3] hover:bg-[#4197cb] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/zero-restriction.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/zero-restriction.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#00b2e3] hover:bg-[#4197cb] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/travis-mathew.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/travis-mathes.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        }),
                                                        currentTab === 3 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            "x-show": "activeTab === 04",
                                                            className: "panel-01 tab-content",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: " w-full",
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "flex flex-wrap -mx-3 gap-y-6",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#003a70] hover:bg-[#19355e] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/adidas.html?sort=&v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/adidas.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#003a70] hover:bg-[#19355e] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/lacoste.html?sort=",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/lacoste.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#003a70] hover:bg-[#19355e] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/under-armour.html?sort=&v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/under-armour.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#003a70] hover:bg-[#19355e] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/bauer.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/bauer.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#003a70] hover:bg-[#19355e] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/next-level.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/next-level.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#003a70] hover:bg-[#19355e] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/sport-tek.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/sport-tek.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#003a70] hover:bg-[#19355e] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/new-era.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/new-era.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#003a70] hover:bg-[#19355e] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/puma.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/puma.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        }),
                                                        currentTab === 4 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            "x-show": "activeTab === 05",
                                                            className: "panel-01 tab-content",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: " w-full",
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "flex flex-wrap -mx-3 gap-y-6",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#0a2240] hover:bg-[#09172d] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/tile.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/tile.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#0a2240] hover:bg-[#09172d] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/knack.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/knack.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#0a2240] hover:bg-[#09172d] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/bose.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/bose.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#0a2240] hover:bg-[#09172d] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/ember.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/ember.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#0a2240] hover:bg-[#09172d] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/moleskine.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/moleskine.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#0a2240] hover:bg-[#09172d] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/swell.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/swell.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#0a2240] hover:bg-[#09172d] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/cross.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/cross.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "w-full lg:w-1/4 px-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                className: "border border-gray-50 bg-[#0a2240] hover:bg-[#09172d] relative",
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                                    className: "flex justify-center items-center",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                                        title: "",
                                                                                        target: "",
                                                                                        href: "https://www.corporategear.com/spyder.html?v=brand-product-list",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                            className: "w-full mx-auto",
                                                                                            src: "images/brands-img/spyder.png",
                                                                                            alt: "",
                                                                                            title: ""
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "text-default-text text-center max-w-3xl mx-auto",
                                                    children: "Jumpstart your creativity and shop by brand category. Browse your favorite brands for corporate apparel and gear. From company jackets, polos, custom longsleeve shirts to brand logo t-shirts, you'll find it here. Or, customize tumblers, hats, backpacks, coolers, and electronics on premium, popular brands."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                            className: "w-full flex justify-center flex-wrap mt-10",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                    className: "lg:w-1/5 w-full",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        "data-bg": "#ffa400",
                                                        className: "bg-[#ffa400] hover:bg-[#f18a00] block py-4 px-10 text-center font-semibold hover:text-[#000000]",
                                                        children: "Featured"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                    className: "lg:w-1/5 w-full",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        "data-bg": "#00ce7c",
                                                        className: "bg-[#00ce7c] hover:bg-[#00a98f] block py-4 px-10 text-center font-semibold hover:text-[#000000]",
                                                        children: "Outerwear"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                    className: "lg:w-1/5 w-full",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        "data-bg": "#00b2e3",
                                                        className: "bg-[#00b2e3] hover:bg-[#4197cb] block py-4 px-10 text-center font-semibold hover:text-[#000000]",
                                                        children: "Golf"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                    className: "lg:w-1/5 w-full",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        "data-bg": "#003a70",
                                                        className: "bg-[#003a70] hover:bg-[#19355e] block py-4 px-10 text-center text-white font-semibold hover:text-[#ffffff]",
                                                        children: "Sporting Goods"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                    className: "lg:w-1/5 w-full",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        "data-bg": "#0a2240",
                                                        className: "bg-[#0a2240] hover:bg-[#09172d] block py-4 px-10 text-center text-white font-semibold hover:text-[#ffffff]",
                                                        children: "Accessories"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                className: "relative pt-20",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "px-4 mx-auto container",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full flex flex-wrap gap-y-8",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "lg:w-2/12 W-full",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "sm:sticky sm:top-32",
                                    id: "list-id",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "text-title pb-8",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "relative pb-4 after:contents[' '] after:bottom-0 after:left-0 after:absolute after:w-[60px] after:h-[6px] after:bg-black",
                                                children: "Brands"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex flex-wrap gap-2 gap-x-5",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    title: "##",
                                                    className: "text-sub-title border-b border-white hover:text-primary hover:border-primary opacity-50 cursor-not-allowed",
                                                    children: "#"
                                                }),
                                                alphabts.map((str, index)=>{
                                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        title: "#D",
                                                        className: `text-sub-title border-b border-white hover:text-primary hover:border-primary${alphabets.includes(str) ? "" : " opacity-50 cursor-not-allowed"}`,
                                                        children: str.toUpperCase()
                                                    }, index);
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "lg:w-8/12 W-full",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex flex-wrap lg:mx-10 bg-gray-100 py-10 lg:px-6 gap-y-10",
                                    children: alphabts.map((str)=>{
                                        const brandFiltered = brands.filter((brand)=>brand.brandName[0].toLowerCase() === str);
                                        return brandFiltered.length > 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "w-full px-3",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "text-sub-title mb-2",
                                                    id: "A",
                                                    children: str.toUpperCase()
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "flex flex-wrap gap-x-5 gap-y-2",
                                                    children: brandFiltered.map((brand, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                                title: brand.brandName,
                                                                className: "text-anchor hover:text-anchor-hover",
                                                                href: `/${brand.seName}.html`,
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                    onClick: ()=>setShowLoader(true),
                                                                    children: brand.brandName
                                                                })
                                                            })
                                                        }, index))
                                                })
                                            ]
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "lg:w-2/12 W-full pt-10",
                                children: "\xa0"
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                className: "relative pt-20 overflow-hidden",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "images/brands-img/faq-bg.png",
                        alt: "",
                        className: "w-full"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex justify-center items-center flex-wrap",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "container",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "absolute top-[40%] left-0 right-0 text-center",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex justify-center items-center max-w-4xl mx-auto",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "text-title",
                                        children: "Brand FAQ"
                                    })
                                })
                            })
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Stroe1LayouBrand);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;