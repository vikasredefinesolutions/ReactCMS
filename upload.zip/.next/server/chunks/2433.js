"use strict";
exports.id = 2433;
exports.ids = [2433];
exports.modules = {

/***/ 2433:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ie": () => (/* binding */ FetchProductSEOtags),
/* harmony export */   "_7": () => (/* binding */ FetchFiltersJsonByBrand),
/* harmony export */   "eB": () => (/* binding */ FetchSizeChartById),
/* harmony export */   "e_": () => (/* binding */ FetchDiscountTablePrices),
/* harmony export */   "f": () => (/* binding */ FetchProductById),
/* harmony export */   "jW": () => (/* binding */ FetchColors),
/* harmony export */   "lA": () => (/* binding */ FetchSimilartProducts),
/* harmony export */   "oe": () => (/* binding */ FetchInventoryById),
/* harmony export */   "rX": () => (/* binding */ FetchProductsBySKUs),
/* harmony export */   "wJ": () => (/* binding */ FetchBrandProductList)
/* harmony export */ });
/* unused harmony exports FetchReviewsById, fetchProductList */
/* harmony import */ var helpers_global_console__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3650);
/* harmony import */ var show_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2118);
/* harmony import */ var _utils_axios_util__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(795);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([helpers_global_console__WEBPACK_IMPORTED_MODULE_0__, _utils_axios_util__WEBPACK_IMPORTED_MODULE_2__]);
([helpers_global_console__WEBPACK_IMPORTED_MODULE_0__, _utils_axios_util__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* eslint-disable no-unused-vars */ 


const FetchProductsBySKUs = async (payload)=>{
    const url = `StoreProduct/getstoreproductbyskus/${payload.SKUs}/${payload.storeId}.json`;
    try {
        const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_2__/* .SendAsyncV2 */ .y)({
            url: url,
            method: "POST",
            data: payload
        });
        (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_0__/* .conditionalLog */ .wH)({
            data: res.data,
            name: "FetchProductsBySKUs",
            type: "API",
            show: res.data === null || res.data.length === 0
        });
        return res.data;
    } catch (error) {
        (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_0__/* .conditionalLog */ .wH)({
            data: error,
            name: "FetchProductsBySKUs",
            type: "API",
            show: show_config__WEBPACK_IMPORTED_MODULE_1__/* ._showConsoles.services.compareProducts */ .YH.services.compareProducts,
            error: true
        });
        return null;
    }
};
const FetchProductById = async (payload)=>{
    const url = `StoreProduct/getstoreproductbysename/${payload.seName}/${payload.storeId}/${payload.productId}.json`;
    try {
        const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_2__/* .SendAsyncV2 */ .y)({
            url: url,
            method: "GET"
        });
        if (res.data === null) {
            (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_0__/* .conditionalLog */ .wH)({
                // @ts-ignore: Unreachable code error
                data: res.otherData,
                name: "FetchProductById",
                type: "API",
                show: res.data === null
            });
            // @ts-ignore: Unreachable code error
            return {
                id: null,
                productDoNotExist: res.otherData
            };
        }
        return res.data;
    } catch (error) {
        (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_0__/* .conditionalLog */ .wH)({
            data: error,
            name: "FetchProductById",
            type: "API",
            show: show_config__WEBPACK_IMPORTED_MODULE_1__/* ._showConsoles.services.productDetails */ .YH.services.productDetails,
            error: true
        });
        return null;
    }
};
const FetchReviewsById = async (payload)=>{
    const url = "/reviews";
    // const res: AxiosResponse = await SendAsyncV2<AxiosRequestConfig>({
    //   url: url,
    //   method: "GET",
    // });
    let res = {};
    return res;
};
const FetchSizeChartById = async (payload)=>{
    const url = `StoreProduct/getsizechartbyproductid/${payload}.json`;
    try {
        var ref;
        const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_2__/* .SendAsyncV2 */ .y)({
            url: url,
            method: "GET"
        });
        (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_0__/* .conditionalLog */ .wH)({
            data: res.data,
            name: "FetchSizeChartById",
            type: "API",
            show: res.data === null
        });
        const sizeChart = JSON.parse((ref = res.data) === null || ref === void 0 ? void 0 : ref.sizeChartView);
        const transformedData = {
            ...res.data,
            sizeChartRange: res.data.sizeChartRange.split(","),
            sizeChartView: sizeChart[0],
            measurements: res.data.measurements.split(",")
        };
        return transformedData;
    } catch (error) {
        (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_0__/* .conditionalLog */ .wH)({
            data: error,
            name: "FetchSizeChartById",
            type: "API",
            show: show_config__WEBPACK_IMPORTED_MODULE_1__/* ._showConsoles.services.productDetails */ .YH.services.productDetails,
            error: true
        });
        return null;
    }
};
const FetchInventoryById = async (payload)=>{
    const url = `StoreProduct/getproductattributesizes.json`;
    function removeDuplicates(arr) {
        return arr.filter((item, index)=>arr.indexOf(item) === index);
    }
    try {
        const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_2__/* .SendAsyncV2 */ .y)({
            url: url,
            method: "POST",
            data: payload
        });
        (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_0__/* .conditionalLog */ .wH)({
            data: res.data,
            name: "FetchInventoryById",
            type: "API",
            show: res.data === null || res.data.length === 0
        });
        const sizes = payload.attributeOptionId.map((id)=>{
            const repeatedSizes = res.data.map((int)=>{
                if (int.colorAttributeOptionId === id) {
                    return int.name;
                }
                return "";
            }).filter(Boolean);
            return {
                colorAttributeOptionId: id,
                sizeArr: removeDuplicates(repeatedSizes)
            };
        });
        const transformedData = {
            inventory: res.data,
            sizes: sizes
        };
        return transformedData;
    } catch (error) {
        (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_0__/* .conditionalLog */ .wH)({
            data: error,
            name: "FetchInventoryById",
            type: "API",
            show: show_config__WEBPACK_IMPORTED_MODULE_1__/* ._showConsoles.services.productDetails */ .YH.services.productDetails,
            error: true
        });
        return null;
    }
};
const FetchColors = async ({ productId , storeId , isAttributeSaparateProduct  })=>{
    let url = "";
    if (isAttributeSaparateProduct === true) {
        url = `https://redefine-front-staging.azurewebsites.net/StoreProduct/getproductattributecolorbyseparation/${productId}/${storeId}.json`;
    } else {
        url = `StoreProduct/getproductattributecolor/${productId}.json`;
    }
    try {
        const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_2__/* .SendAsyncV2 */ .y)({
            url: url,
            method: "POST"
        });
        (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_0__/* .conditionalLog */ .wH)({
            data: res.data,
            name: "FetchColors",
            type: "API",
            show: res.data === null || res.data.length === 0
        });
        return res.data;
    } catch (error) {
        (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_0__/* .conditionalLog */ .wH)({
            data: error,
            name: "FetchColors",
            type: "API",
            show: show_config__WEBPACK_IMPORTED_MODULE_1__/* ._showConsoles.services.productDetails */ .YH.services.productDetails,
            error: true
        });
        return null;
    }
};
const FetchFiltersJsonByBrand = async (filterRequest)=>{
    const url = `/StoreProductFilter/GetFilterByBrand.json`;
    const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_2__/* .SendAsyncV2 */ .y)({
        url: url,
        method: "POST",
        data: filterRequest
    });
    return res.data;
};
const FetchDiscountTablePrices = async (payload)=>{
    const url = `StoreProduct/getproductquantitydiscounttabledetail.json`;
    try {
        const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_2__/* .SendAsyncV2 */ .y)({
            url: url,
            method: "POST",
            data: payload
        });
        (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_0__/* .conditionalLog */ .wH)({
            data: res.data,
            name: "FetchDiscountTablePrices",
            type: "API",
            show: res.data === null
        });
        return res.data;
    } catch (error) {
        (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_0__/* .conditionalLog */ .wH)({
            data: error,
            name: "FetchDiscountTablePrices",
            type: "API",
            show: show_config__WEBPACK_IMPORTED_MODULE_1__/* ._showConsoles.services.productDetails */ .YH.services.productDetails,
            error: true
        });
        return null;
    }
};
const FetchSimilartProducts = async (payload)=>{
    const url = `StoreProduct/getyoumaylikeproducts/${payload.productId}/${payload.storeId}.json`;
    try {
        const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_2__/* .SendAsyncV2 */ .y)({
            url: url,
            method: "POST",
            data: payload
        });
        (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_0__/* .conditionalLog */ .wH)({
            data: res.data,
            name: "FetchSimilartProducts",
            type: "API",
            show: res.data === null || res.data.length === 0
        });
        return res.data;
    } catch (error) {
        (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_0__/* .conditionalLog */ .wH)({
            data: error,
            name: "FetchSimilartProducts",
            type: "API",
            show: show_config__WEBPACK_IMPORTED_MODULE_1__/* ._showConsoles.services.productDetails */ .YH.services.productDetails,
            error: true
        });
        return null;
    }
};
const fetchProductList = async (storeId)=>{
    const url = "/StoreProduct/list.json";
    const res = await SendAsyncV2({
        url: url,
        method: "POST",
        data: {
            args: {
                pageIndex: 0,
                pageSize: 6,
                pagingStrategy: 0,
                sortingOptions: [
                    {
                        field: "string",
                        direction: 0,
                        priority: 0
                    }, 
                ],
                filteringOptions: [
                    {
                        field: "string",
                        operator: 0,
                        value: "string"
                    }, 
                ]
            },
            storeId: storeId
        }
    });
    return res;
};
const FetchProductSEOtags = async ({ storeId , seName  })=>{
    const url = `StoreProductSeo/GetDetails/${storeId}/${seName}.json`;
    try {
        const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_2__/* .SendAsyncV2 */ .y)({
            url: url,
            method: "GET"
        });
        (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_0__/* .conditionalLog */ .wH)({
            data: res.data,
            name: "FetchProductSEOtags",
            type: "API",
            show: res.data === null
        });
        return res.data;
    } catch (error) {
        (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_0__/* .conditionalLog */ .wH)({
            data: error,
            name: "FetchProductSEOtags",
            type: "API",
            show: show_config__WEBPACK_IMPORTED_MODULE_1__/* ._showConsoles.services.productDetails */ .YH.services.productDetails,
            error: true
        });
        return null;
    }
};
const FetchBrandProductList = async ({ storeId , seName  })=>{
    const url = `Brand/getbrandseodetails/${storeId}/${seName}.json`;
    const res = await (0,_utils_axios_util__WEBPACK_IMPORTED_MODULE_2__/* .SendAsyncV2 */ .y)({
        url: url,
        method: "GET"
    });
    (0,helpers_global_console__WEBPACK_IMPORTED_MODULE_0__/* .conditionalLog */ .wH)({
        data: res.data,
        name: "FetchProductSEOtags",
        type: "API",
        show: res.data === null
    });
    return res.data;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;