"use strict";
exports.id = 1054;
exports.ids = [1054];
exports.modules = {

/***/ 1054:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Components_UserManagement)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./src/constants/validationMessages.ts
var validationMessages = __webpack_require__(4108);
// EXTERNAL MODULE: external "formik"
var external_formik_ = __webpack_require__(2296);
// EXTERNAL MODULE: external "yup"
var external_yup_ = __webpack_require__(5609);
;// CONCATENATED MODULE: ./src/appComponents/modals/AddUserModal.tsx




const AddUserModal = ({ submitHandler , closeModal  })=>{
    const initialValues = {
        firstName: "",
        lastName: "",
        email: "",
        role: ""
    };
    const validationSchema = external_yup_.object().shape({
        firstName: external_yup_.string().required(validationMessages/* addUserMessages.firstName.required */.$y.firstName.required),
        lastName: external_yup_.string().required(validationMessages/* addUserMessages.lastName.required */.$y.lastName.required),
        email: external_yup_.string().required(validationMessages/* addUserMessages.email.required */.$y.email.required),
        role: external_yup_.string().required(validationMessages/* addUserMessages.role.required */.$y.role.required)
    });
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        id: "adduserModal",
        "aria-hidden": "true",
        className: "overflow-y-auto overflow-x-hidden fixed z-50 justify-center items-center h-modal h-full inset-0",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "w-full h-full bg-black bg-opacity-50 flex items-center justify-center",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "relative px-4 w-full max-w-2xl h-fullborder border-neutral-200 inline-block h-auto",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "relative bg-white rounded-lg shadow dark:bg-gray-700 max-h-screen overflow-y-auto",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex justify-between items-center p-5 rounded-t border-b dark:border-gray-600 sticky top-0 left-0 bg-white",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "text-xl font-semibold text-gray-900 lg:text-2xl login-top-title dark:text-white",
                                    children: "Add User"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "flex items-center gap-x-2",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        onClick: closeModal,
                                        className: "text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center dark:hover:bg-gray-600 dark:hover:text-white",
                                        "data-modal-toggle": "adduserModal",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                            className: "w-5 h-5",
                                            fill: "currentColor",
                                            viewBox: "0 0 20 20",
                                            xmlns: "http://www.w3.org/2000/svg",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                fillRule: "evenodd",
                                                d: "M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z",
                                                clipRule: "evenodd"
                                            })
                                        })
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(external_formik_.Formik, {
                            onSubmit: submitHandler,
                            validationSchema: validationSchema,
                            initialValues: initialValues,
                            children: ({ touched , errors , handleChange , handleBlur , handleSubmit ,  })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                    onSubmit: handleSubmit,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "p-6",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex flex-wrap -mx-3 gap-y-6",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "w-full lg:w-1/2 px-3",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                                htmlFor: "First Name",
                                                                className: "block text-base font-medium text-gray-700",
                                                                children: "First Name"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "mt-2",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                    type: "text",
                                                                    id: "First Name",
                                                                    name: "firstName",
                                                                    autoComplete: "First Name",
                                                                    placeholder: "First Name",
                                                                    className: "form-input",
                                                                    onChange: handleChange,
                                                                    onBlur: handleBlur
                                                                })
                                                            }),
                                                            touched.firstName && errors.firstName && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                className: "text-red-500 text-xs mt-1",
                                                                children: errors.firstName
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "w-full lg:w-1/2 px-3",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                                htmlFor: "Last Name",
                                                                className: "block text-base font-medium text-gray-700",
                                                                children: "Last Name"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "mt-2",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                    type: "text",
                                                                    id: "Last Name",
                                                                    name: "lastName",
                                                                    autoComplete: "Last Name",
                                                                    placeholder: "Last Name",
                                                                    className: "form-input",
                                                                    onChange: handleChange,
                                                                    onBlur: handleBlur
                                                                })
                                                            }),
                                                            touched.lastName && errors.lastName && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                className: "text-red-500 text-xs mt-1",
                                                                children: errors.lastName
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "w-full lg:w-1/2 px-3",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                                htmlFor: "email-address",
                                                                className: "block text-base font-medium text-gray-700",
                                                                children: "Email Address"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "mt-2",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                                    type: "email",
                                                                    id: "email-address",
                                                                    name: "email",
                                                                    autoComplete: "email",
                                                                    placeholder: "Email Address",
                                                                    className: "form-input",
                                                                    onChange: handleChange,
                                                                    onBlur: handleBlur
                                                                })
                                                            }),
                                                            touched.email && errors.email && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                className: "text-red-500 text-xs mt-1",
                                                                children: errors.email
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "w-full lg:w-1/2 px-3",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                                htmlFor: "state",
                                                                className: "block text-base font-medium text-gray-700",
                                                                children: "Role"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "mt-2",
                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("select", {
                                                                    className: "form-input",
                                                                    name: "role",
                                                                    onChange: handleChange,
                                                                    onBlur: handleBlur,
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                            value: "",
                                                                            disabled: true,
                                                                            children: "Select Role"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                            value: "administrator",
                                                                            children: "Administrator"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                                            value: "user",
                                                                            children: "User"
                                                                        })
                                                                    ]
                                                                })
                                                            }),
                                                            touched.role && errors.role && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                className: "text-red-500 text-xs mt-1",
                                                                children: errors.role
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "flex items-center justify-end p-6 space-x-2 rounded-b border-t border-gray-200 dark:border-gray-600",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                "data-modal-toggle": "adduserModal",
                                                type: "submit",
                                                className: "btn btn-primary",
                                                children: "Save"
                                            })
                                        })
                                    ]
                                })
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const modals_AddUserModal = (AddUserModal);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./src/pages/MyAccount/Components/UserManagement.tsx



const UserManagement = ()=>{
    const currentUser = {
        firstName: "Hetal",
        lastName: "Patel",
        email: "hetal.patel@gmail.com",
        createdDate: new Date("2020-05-16"),
        role: "administrator",
        lastLoggedIn: new Date()
    };
    const { 0: userList , 1: setUserList  } = (0,external_react_.useState)([
        currentUser
    ]);
    const { 0: showAddUserModal , 1: setShowAddUserModal  } = (0,external_react_.useState)(false);
    const closeModal = ()=>{
        setShowAddUserModal(false);
    };
    const submitHandler = (values)=>{
        userList.push({
            ...values,
            createdDate: new Date(),
            lastLoggedIn: new Date()
        });
        setUserList(userList);
        closeModal();
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: "container mx-auto bg-gray-100 px-6 py-6 mt-5 mb-5",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "mx-auto space-y-10 sm:px-4 lg:px-0 pb-2",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "bg-white border-t border-b border-gray-200 sm:border",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex items-center p-4 border-b border-gray-200 sm:p-6 sm:grid sm:grid-cols-4 sm:gap-x-6 bg-gray-50",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "flex-1 grid grid-cols-2 gap-x-6 text-sm sm:col-span-4 sm:grid-cols-4 lg:col-span-2"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "hidden lg:col-span-2 lg:flex lg:items-center lg:justify-end lg:space-x-4",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                "data-modal-toggle": "adduserModal",
                                                className: "btn btn-primary",
                                                onClick: ()=>setShowAddUserModal(true),
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "Add User"
                                                })
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    role: "list",
                                    className: "divide-y divide-gray-200 ",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "p-4 sm:p-6",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex flex-wrap",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "w-full lg:w-1/3",
                                                        children: [
                                                            currentUser.firstName,
                                                            " ",
                                                            currentUser.lastName
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "w-full lg:w-1/3",
                                                        children: [
                                                            "Created on: ",
                                                            currentUser.createdDate.toLocaleDateString()
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "w-full lg:w-1/3",
                                                        children: currentUser.role === "administrator" ? "You have admin acceess" : "You are a User"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "p-4 sm:p-6",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex flex-wrap",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "w-full lg:w-1/3",
                                                        children: currentUser.email
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "w-full lg:w-1/3",
                                                        children: [
                                                            "Last log on: ",
                                                            currentUser.lastLoggedIn.toLocaleDateString()
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "w-full lg:w-1/3",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            href: "index.html",
                                                            children: "Logout"
                                                        })
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "bg-white border-t border-b border-gray-200 sm:border overflow-auto",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("table", {
                                className: "table w-full border",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("thead", {
                                        className: "border-b-2 divide-gray-300",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                            className: "divide-x divide-gray-300 text-left",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    className: "p-2",
                                                    children: "Username"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    className: "p-2",
                                                    children: "Role"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    className: "p-2",
                                                    children: "Email Address"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    className: "p-2",
                                                    children: "Created date"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                    className: "p-2",
                                                    children: "Action"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("tbody", {
                                        className: "divide-y divide-gray-300",
                                        children: userList.map((user, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                className: "divide-x divide-gray-300",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("td", {
                                                        className: "p-2",
                                                        children: [
                                                            user.firstName,
                                                            " ",
                                                            user.lastName
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                        className: "p-2",
                                                        children: user.role
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                        className: "p-2",
                                                        children: user.email
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                        className: "p-2",
                                                        children: user.createdDate.toLocaleDateString()
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                        className: "p-2"
                                                    })
                                                ]
                                            }, index))
                                    })
                                ]
                            })
                        })
                    ]
                })
            }),
            showAddUserModal && /*#__PURE__*/ jsx_runtime_.jsx(modals_AddUserModal, {
                submitHandler: submitHandler,
                closeModal: closeModal
            })
        ]
    });
};
/* harmony default export */ const Components_UserManagement = (UserManagement);


/***/ })

};
;